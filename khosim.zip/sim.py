﻿from __future__ import annotations

import copy
import sys
import math
import time
import traceback
import csv
import io
import uuid
from datetime import datetime, timedelta, date
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request
import json
import re
import unicodedata
from typing import List, Any, Callable, Optional

import pandas as pd
pd.set_option("future.no_silent_downcasting", True)
from PySide6.QtCore import (
    Qt,
    QAbstractTableModel,
    QModelIndex,
    QItemSelectionModel,
    QItemSelection,
    QTimer,
    QEvent,
    QDate,
    QTime,
    QRect,
    QPoint,
    QPointF,
    QSize,
)
from PySide6.QtGui import QColor, QFont, QFontMetrics, QGuiApplication, QPainter, QPalette, QCursor, QIcon, QPixmap, QBrush
from PySide6.QtWidgets import (
    QApplication,
    QLayout,
    QGridLayout,
    QFileDialog,
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTableView,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QTabWidget,
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QMenu,
    QInputDialog,
    QHeaderView,
    QScrollArea,
    QFrame,
    QCheckBox,
    QSizePolicy,
    QCalendarWidget,
    QDateEdit,
    QTimeEdit,
    QListWidget,
    QListWidgetItem,
    QStyle,
    QStyleOptionHeader,
    QStyleOptionViewItem,
    QToolButton,
    QLineEdit,
    QAbstractScrollArea,
    QToolTip,
    QStatusBar,
    QTextEdit,
    QDialogButtonBox,
    QColorDialog,
    QGraphicsSimpleTextItem,
    QStyledItemDelegate,
    QSpinBox,
)
from PySide6.QtCharts import (
    QChart,
    QChartView,
    QBarSeries,
    QBarSet,
    QStackedBarSeries,
    QBarCategoryAxis,
    QValueAxis,
    QLegend,
)
from PySide6.QtGui import QKeySequence, QShortcut

BASE_DIR = Path(__file__).parent
EXCEL_PATH = BASE_DIR / "tonkho.xlsx"
# Đọc header ngay dòng đầu tiên của file Excel
HEADER_ROW = 1  # 1-based
DATA_START_ROW = 2  # 1-based
# Không giới hạn cột trên UI; số cột sẽ trùng với Excel
DATA_DIR = BASE_DIR / "data"
DATA_FILE = DATA_DIR / "data.json"
STATE_FILE = DATA_DIR / "state.json"
HISTORY_DIR = DATA_DIR / "history"
DEFAULT_ALERT_OPS = [
    ("empty", "Trống"),
    ("in_list", "Thuộc danh sách"),
    ("not_empty", "Không trống"),
    ("lt", "<"),
    ("gt", ">"),
    ("eq", "= (số)"),
    ("contains", "Chứa"),
    ("equals", "Văn bản chính xác"),
    ("not_contains", "Không chứa"),
    ("startswith", "Bắt đầu bằng"),
    ("endswith", "Kết thúc bằng"),
    ("notequals", "Không bằng"),
    ("gte", "≥"),
    ("lte", "≤"),
    ("neq", "≠ (số)"),
    ("between", "Giữa"),
    ("not_between", "Ngoài khoảng"),
    ("date_is", "Ngày ="),
    ("date_before", "Ngày <"),
    ("date_after", "Ngày >"),
    ("days_equal", "Cách trước/sau = (ngày)"),
    ("days_before_eq", "Cách trước = (ngày)"),
    ("days_after_eq", "Cách sau = (ngày)"),
    ("days_equal_pivot", "Cách ±x ngày so mốc +y ngày"),
    ("days_before_pivot", "Cách trước x ngày so mốc +y ngày"),
    ("days_after_pivot", "Cách sau x ngày so mốc +y ngày"),
    ("month_is", "Tháng ="),
    ("year_is", "Năm ="),
    ("month_current", "Tháng này"),
    ("year_current", "Năm nay"),
    ("custom", "Công thức tùy chỉnh"),
]
THEMES = {
    "Sáng": """
        QWidget { background: #f7f9fb; color: #111; }
        QHeaderView::section { background: #e6ebf2; padding: 2px 8px; border: 1px solid #cfd8e3; font-weight: 600; }
        QTableView { gridline-color: #cfd8e3; selection-background-color: #dbeafe; selection-color: #111; }
        QTableView::item { border-right: 1px solid #cfd8e3; border-bottom: 1px solid #cfd8e3; }
        QTableCornerButton::section { background: #e6ebf2; border: 1px solid #cfd8e3; }
        QPushButton { background: #e6ebf2; border: 1px solid #cfd8e3; padding: 6px 10px; border-radius: 4px; font-weight: 600; }
        QPushButton:hover { background: #dbeafe; }
        QComboBox, QLineEdit { background: #fff; border: 1px solid #cfd8e3; padding: 4px; }
        QTabWidget::pane { border: 1px solid #cfd8e3; background: #f7f9fb; }
        QTabBar::tab { background: #e6ebf2; color: #1f2937; padding: 6px 14px; border: 1px solid #cfd8e3; border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px; font-weight: 600; }
        QTabBar::tab:selected { background: #ffffff; color: #0f172a; border-bottom: 3px solid #3b82f6; }
        QTabBar::tab:hover { background: #eef2f7; }
    """,
    "Tối": """
        QWidget { background: #151821; color: #e5e7eb; }
        QHeaderView::section { background: #1f2430; padding: 2px 8px; border: 1px solid #2d3344; color: #e5e7eb; font-weight: 600; }
        QTableView { gridline-color: #2d3344; selection-background-color: #374151; selection-color: #e5e7eb; alternate-background-color: #1c2130; }
        QTableView::item { border-right: 1px solid #2d3344; border-bottom: 1px solid #2d3344; }
        QTableCornerButton::section { background: #1f2430; border: 1px solid #2d3344; }
        QPushButton { background: #1f2430; border: 1px solid #2d3344; padding: 6px 10px; border-radius: 4px; color: #e5e7eb; font-weight: 600; }
        QPushButton:hover { background: #273042; }
        QPushButton:disabled { background: #1b1f2a; color: #6b7280; border: 1px solid #252b3a; }
        QComboBox, QLineEdit { background: #1f2430; border: 1px solid #2d3344; padding: 4px; color: #e5e7eb; selection-background-color: #374151; }
        QScrollBar:vertical { background: #1f2430; width: 12px; }
        QTabWidget::pane { border: 1px solid #2d3344; background: #151821; }
        QTabBar::tab { background: #1f2430; color: #cbd5f5; padding: 6px 14px; border: 1px solid #2d3344; border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px; font-weight: 600; }
        QTabBar::tab:selected { background: #151821; color: #ffffff; border-bottom: 3px solid #8b5cf6; }
        QTabBar::tab:hover { background: #273042; }
        QTabBar::tab:!selected { margin-top: 2px; }
    """,
    "Xanh bạc hà": """
        QWidget { background: #f4fffb; color: #0f172a; }
        QHeaderView::section { background: #d4f5ea; padding: 2px 8px; border: 1px solid #a7ddc8; color: #0f172a; font-weight: 600; }
        QTableView { gridline-color: #a7ddc8; selection-background-color: #c7f0df; selection-color: #0f172a; }
        QTableView::item { border-right: 1px solid #a7ddc8; border-bottom: 1px solid #a7ddc8; }
        QTableCornerButton::section { background: #d4f5ea; border: 1px solid #a7ddc8; }
        QPushButton { background: #d4f5ea; border: 1px solid #a7ddc8; padding: 6px 10px; border-radius: 4px; font-weight: 600; }
        QPushButton:hover { background: #c7f0df; }
        QComboBox, QLineEdit { background: #fff; border: 1px solid #a7ddc8; padding: 4px; }
        QTabBar::tab { font-weight: 600; }
        QTabWidget::pane { border: 1px solid #a7ddc8; background: #f4fffb; }
        QTabBar::tab { background: #d4f5ea; color: #0f172a; padding: 6px 14px; border: 1px solid #a7ddc8; border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px; font-weight: 600; }
        QTabBar::tab:selected { background: #ffffff; color: #0f172a; border-bottom: 3px solid #10b981; }
        QTabBar::tab:hover { background: #c7f0df; }
    """,
}


def load_table_data(path: Path, sheet_name: Optional[str] = None):
    if not path.exists():
        raise FileNotFoundError(f"Không tìm thấy file: {path}")
    xls = pd.ExcelFile(path)
    used_sheet = sheet_name or (xls.sheet_names[0] if xls.sheet_names else 0)
    # Đọc header dòng đầu tiên, giữ nguyên định dạng chuỗi (tránh mất 0.00)
    df = pd.read_excel(xls, sheet_name=used_sheet, header=0, dtype=str, keep_default_na=False)
    headers = [str(c).strip() for c in df.columns]
    data = df.fillna("").astype(str)
    rows = data.values.tolist()
    return headers, rows, str(used_sheet)


def parse_datetime_string(text: str, include_time: bool = False) -> Optional[datetime]:
    clean = text.strip()
    if not clean:
        return None
    candidates: List[str] = []
    # luôn hỗ trợ cả định dạng có thời gian để lọc theo ngày (bỏ phần giờ)
    candidates += [
        "%H:%M:%S %d/%m/%Y",
        "%H:%M %d/%m/%Y",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%H:%M %Y-%m-%d",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
    ]
    if not include_time:
        # thêm mẫu chỉ ngày
        candidates += ["%d/%m/%Y", "%Y-%m-%d", "%Y/%m/%d"]
    else:
        # ưu tiên mẫu thời gian đầy đủ trước
        candidates = candidates
    for fmt in candidates:
        try:
            return datetime.strptime(clean, fmt)
        except ValueError:
            continue
    try:
        return datetime.fromisoformat(clean)
    except ValueError:
        return None


def col_letter(idx: int) -> str:
    """0-based -> Excel-like letters."""
    result = ""
    n = idx
    while True:
        n, rem = divmod(n, 26)
        result = chr(ord("A") + rem) + result
        if n == 0:
            break
        n -= 1
    return result


class InventoryModel(QAbstractTableModel):
    def __init__(
        self,
        headers: List[str],
        rows: List[List[Any]],
        alignment_map: dict[str, int],
        column_formats: dict[str, str],
        cell_styles: dict[str, dict],
        on_edit: Optional[Callable[[int, int, Any], None]] = None,
        alert_highlighter: Optional[Callable[[int, int, Any], Optional[QColor]]] = None,
        parent=None,
        include_index: bool = False,
        index_header: str = "STT",
    ) -> None:
        super().__init__(parent)
        self.headers = headers
        self.rows = rows
        self.alignment_map = alignment_map
        self.column_formats = column_formats
        self.cell_styles = cell_styles
        self.on_edit = on_edit
        self.alert_highlighter = alert_highlighter
        self.include_index = include_index
        self.index_header = index_header

    def rowCount(self, parent=QModelIndex()) -> int:
        return len(self.rows)

    def columnCount(self, parent=QModelIndex()) -> int:
        extra = 1 if self.include_index else 0
        return len(self.headers) + extra

    def _is_status_column(self, actual_col: int) -> bool:
        if actual_col < 0 or actual_col >= len(self.headers):
            return False
        name = str(self.headers[actual_col] or "")
        norm = unicodedata.normalize("NFD", name.strip().lower())
        norm = "".join(ch for ch in norm if unicodedata.category(ch) != "Mn")
        norm = re.sub(r"[^0-9a-z]", "", norm)
        return any(tag in norm for tag in ("trangthai", "tinhtrang", "khoa"))

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid():
            return None
        row = index.row()
        col = index.column()
        g_row = self._row_index_from_view(row) if hasattr(self, "_row_index_from_view") else row
        if self.include_index and col == 0:
            return str(row + 1) if role == Qt.DisplayRole else None
        actual_col = col - 1 if self.include_index else col
        if actual_col < 0 or actual_col >= len(self.headers):
            return None
        val = self.rows[row][actual_col]
        style_key = f"{g_row}_{actual_col}"
        style = self.cell_styles.get(style_key) if hasattr(self, "cell_styles") else None

        if role == Qt.DisplayRole:
            return self._format_display_value(val, actual_col)
        if role == Qt.EditRole:
            return "" if pd.isna(val) else str(val)

        if role == Qt.BackgroundRole:
            if style and style.get("bg"):
                return QColor(style["bg"])
            if self.alert_highlighter:
                res = self.alert_highlighter(row, actual_col, val)
                if isinstance(res, dict):
                    return res.get("bg")
                return res
            return None

        if role == Qt.ForegroundRole:
            if style and style.get("color"):
                return QColor(style["color"])
            txt = "" if pd.isna(val) else str(val)
            if txt.strip().lower() in ("khóa", "khoa"):
                return QColor("#ff4d4f")
            if self.alert_highlighter:
                res = self.alert_highlighter(row, actual_col, val)
                if isinstance(res, dict) and res.get("fg"):
                    return res.get("fg")
            return None

        if role == Qt.FontRole:
            font = QFont()
            has = False
            if style:
                if style.get("bold"):
                    font.setBold(True); has = True
                if style.get("italic"):
                    font.setItalic(True); has = True
                if style.get("underline"):
                    font.setUnderline(True); has = True
            if self.alert_highlighter:
                res = self.alert_highlighter(row, actual_col, val)
                if isinstance(res, dict):
                    if res.get("bold"):
                        font.setBold(True); has = True
                    if res.get("italic"):
                        font.setItalic(True); has = True
            return font if has else None
        if role == Qt.TextAlignmentRole:
            col = index.column()
            target = col - 1 if self.include_index else col
            align = self.alignment_map.get(str(target))
            if align is not None:
                return align
            return Qt.AlignLeft | Qt.AlignVCenter
        if role == Qt.ToolTipRole:
            col = index.column()
            if self.include_index and col == 0:
                return self.index_header
            actual_col = col - 1 if self.include_index else col
            if actual_col < 0 or actual_col >= len(self.headers):
                return ""
            val = self.rows[index.row()][actual_col]
            # Địa chỉ ô
            def col_to_addr(c: int) -> str:
                name = ""
                c0 = c
                while c0 >= 0:
                    name = chr(c0 % 26 + ord("A")) + name
                    c0 = c0 // 26 - 1
                return name
            addr = f"{col_to_addr(actual_col)}{index.row() + 1}"
            # Kiểu định dạng cột
            fmt = ""
            if hasattr(self, "column_formats"):
                fmt = str(self.column_formats.get(str(actual_col), "")) or ""
            label = fmt if fmt else (self.headers[actual_col] if 0 <= actual_col < len(self.headers) else "Giá trị")
            return f"{label}\n{addr}"
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if orientation == Qt.Horizontal:
            if role == Qt.DisplayRole:
                display = self._render_header(section)
                return display
            if role == Qt.ToolTipRole:
                if self.include_index and section == 0:
                    return self.index_header
                idx = section - (1 if self.include_index else 0)
                return self.headers[idx] if 0 <= idx < len(self.headers) else ""
        if orientation == Qt.Vertical and role == Qt.DisplayRole:
            return str(section + 1)
        return super().headerData(section, orientation, role)

    def flags(self, index: QModelIndex) -> Qt.ItemFlags:
        base = super().flags(index)
        if index.isValid():
            if self.include_index and index.column() == 0:
                return base & ~Qt.ItemIsEditable
            actual_col = index.column() - (1 if self.include_index else 0)
            if 0 <= actual_col < len(self.headers) and self.headers[actual_col] in ("Nguồn", "Thay đổi lúc"):
                return base & ~Qt.ItemIsEditable
            base |= Qt.ItemIsEditable
        return base

    def setData(self, index: QModelIndex, value, role: int = Qt.EditRole):
        if not index.isValid() or role != Qt.EditRole:
            return False
        r, c = index.row(), index.column()
        if self.include_index:
            if c == 0:
                return False
            actual_col = c - 1
        else:
            actual_col = c
        if r >= len(self.rows) or actual_col >= len(self.headers):
            return False
        if self.headers[actual_col] == "Nguồn":
            return False
        if self.headers[actual_col] == "Thay đổi lúc":
            return False
        col_fmt = self.column_formats.get(str(actual_col))
        if col_fmt in {"Số", "Số có dấu", "Tiền"}:
            clean = self._normalize_number_string(str(value))
            self.rows[r][actual_col] = clean
        else:
            self.rows[r][actual_col] = value
        if self.on_edit:
            self.on_edit(r, c, value)
        self.dataChanged.emit(index, index, [Qt.DisplayRole, Qt.EditRole])
        return True

    def _render_header(self, section: int) -> str:
        if self.include_index and section == 0:
            return self.index_header
        idx = section - (1 if self.include_index else 0)
        base = self.headers[idx] if 0 <= idx < len(self.headers) else ""
        return base

    def _format_display_value(self, val: Any, column_idx: int) -> str:
        text = "" if pd.isna(val) else str(val)
        fmt = self.column_formats.get(str(column_idx))
        if fmt == "Số có dấu":
            formatted = self._format_with_thousands(text)
            return formatted
        if fmt == "Tiền":
            formatted = self._format_with_thousands(text)
            if formatted:
                return f"{formatted} ₫"
            return formatted
        if fmt == "Ngày":
            parsed = parse_datetime_string(text, include_time=False)
            if parsed:
                return parsed.strftime("%d/%m/%Y")
            return text
        if fmt == "Thời gian":
            parsed = parse_datetime_string(text, include_time=True)
            if parsed:
                return parsed.strftime("%H:%M %d/%m/%Y")
            return text
        if fmt == "Số điện thoại":
            formatted = self._format_phone(text)
            return formatted
        return text

    def _format_with_thousands(self, text: str) -> str:
        clean = text.strip()
        if not clean:
            return ""
        sign = ""
        if clean.startswith("-"):
            sign = "-"
            clean = clean[1:]
        clean = clean.replace(",", "").replace(" ", "")
        if not re.match(r"^\d+(\.\d+)?$", clean):
            return text
        parts = clean.split(".", 1)
        int_part = parts[0]
        dec_part = parts[1] if len(parts) > 1 else None
        try:
            formatted_int = f"{int(int_part):,}"
        except ValueError:
            return text
        if dec_part is not None:
            return f"{sign}{formatted_int}.{dec_part}"
        return f"{sign}{formatted_int}"

    def _format_phone(self, text: str) -> str:
        raw = str(text or "")
        had_dots = "." in raw
        segment_lengths = [len(s) for s in raw.split(".")] if had_dots else []
        digits = re.sub(r"\D", "", raw)
        if not digits:
            return raw
        prefix_added = False
        # chuẩn hóa: 84xxxxxxxxx -> 0xxxxxxxxx ; 9 số không 0 -> thêm 0
        if digits.startswith("84") and len(digits) >= 10:
            digits = "0" + digits[2:]
        elif len(digits) == 9 and not digits.startswith("0"):
            digits = "0" + digits
            prefix_added = True
        if had_dots:
            total_len = sum(segment_lengths)
            if len(digits) == total_len:
                parts = []
                idx = 0
                for ln in segment_lengths:
                    parts.append(digits[idx : idx + ln])
                    idx += ln
                return ".".join(parts)
            if prefix_added and len(digits) == total_len + 1 and segment_lengths:
                # thêm 0 vào đầu nhưng giữ nguyên pattern dấu chấm
                core = digits[-total_len:]
                parts = []
                idx = 0
                for ln in segment_lengths:
                    parts.append(core[idx : idx + ln])
                    idx += ln
                return "0" + ".".join(parts)
            # fallback nếu lệch khó xử lý: vẫn trả về digits (chuẩn hóa) để không mất số
        return digits

    def _normalize_number_string(self, text: str) -> str:
        clean = str(text or "").strip()
        if not clean:
            return ""
        sign = ""
        if clean.startswith("-"):
            sign = "-"
            clean = clean[1:]
        clean = clean.replace(" ", "").replace(",", "")
        parts = clean.split(".")
        if len(parts) > 2:
            dec = parts[-1]
            int_part = "".join(parts[:-1])
            clean = int_part + "." + dec
        return sign + clean


class InventoryItemDelegate(QStyledItemDelegate):
    """Custom delegate to guarantee BackgroundRole colors are painted even under app-wide stylesheets.

    Qt stylesheets can cause QTableView items to ignore `Qt.BackgroundRole`. We paint the background
    ourselves and then draw the text using the initialized style option.

    Also auto-adjusts foreground color for readability when a cell has a custom background but no
    explicit foreground color.
    """

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

    def _as_brush(self, val) -> Optional[QBrush]:
        if val is None:
            return None
        if isinstance(val, QBrush):
            return val
        if isinstance(val, QColor):
            return QBrush(val)
        try:
            c = QColor(val)
            return QBrush(c) if c.isValid() else None
        except Exception:
            return None

    @staticmethod
    def _srgb_to_linear(u: float) -> float:
        if u <= 0.04045:
            return u / 12.92
        return ((u + 0.055) / 1.055) ** 2.4

    @classmethod
    def _relative_luminance(cls, c: QColor) -> float:
        r = cls._srgb_to_linear(c.redF())
        g = cls._srgb_to_linear(c.greenF())
        b = cls._srgb_to_linear(c.blueF())
        return 0.2126 * r + 0.7152 * g + 0.0722 * b

    @classmethod
    def _contrast_ratio(cls, fg: QColor, bg: QColor) -> float:
        l1 = cls._relative_luminance(fg)
        l2 = cls._relative_luminance(bg)
        hi, lo = (l1, l2) if l1 >= l2 else (l2, l1)
        return (hi + 0.05) / (lo + 0.05)

    @classmethod
    def _auto_text_color(cls, bg: QColor) -> QColor:
        dark = QColor("#111111")
        light = QColor("#f5f7fb")
        return dark if cls._contrast_ratio(dark, bg) >= cls._contrast_ratio(light, bg) else light

    def paint(self, painter, option, index):
        opt = QStyleOptionViewItem(option)
        self.initStyleOption(opt, index)
        selected = bool(opt.state & QStyle.State_Selected)

        # Keep default rendering for selection state.
        if selected:
            return super().paint(painter, option, index)

        bg_val = index.data(Qt.BackgroundRole)
        brush = self._as_brush(bg_val)
        if brush is None:
            is_alt = bool(opt.features & QStyleOptionViewItem.Alternate)
            pal_role = QPalette.AlternateBase if is_alt else QPalette.Base
            brush = opt.palette.brush(pal_role)

        painter.save()
        painter.fillRect(opt.rect, brush)
        painter.restore()

        # Draw text (and keep font) without relying on the style engine for background.
        painter.save()
        painter.setFont(opt.font)
        fg_val = index.data(Qt.ForegroundRole)
        fg_color: Optional[QColor] = None
        if isinstance(fg_val, QBrush):
            fg_color = fg_val.color()
        elif isinstance(fg_val, QColor) and fg_val.isValid():
            fg_color = fg_val
        if fg_color is None:
            if bg_val is not None and isinstance(brush, QBrush):
                bg_color = brush.color()
                if bg_color.isValid():
                    fg_color = self._auto_text_color(bg_color)
        if fg_color is None:
            fg_color = opt.palette.color(QPalette.Text)
        painter.setPen(fg_color)
        text_rect = opt.rect.adjusted(4, 0, -4, 0)
        flags = int(opt.displayAlignment) | int(Qt.TextWordWrap)
        painter.drawText(text_rect, flags, opt.text)
        painter.restore()


class ColumnHeader(QHeaderView):
    def __init__(self, orientation, parent, select_callback, rename_callback, sort_callback=None, height_changed=None):
        super().__init__(orientation, parent)
        self.select_callback = select_callback
        self.rename_callback = rename_callback
        self.sort_callback = sort_callback
        self.height_changed = height_changed
        self.setSectionsClickable(True)
        self._resizing = False
        self._start_y = 0
        self._start_h = 0
        self._resize_margin = 6  # px
        self._drag_indicator: QFrame | None = None
        self._table_view = parent

    def mousePressEvent(self, event):
        # Resize height if click near bottom edge
        if abs(event.position().y() - self.height()) <= self._resize_margin:
            self._resizing = True
            self._start_y = event.position().y()
            self._start_h = self.height()
            event.accept()
            return
        logical = self.logicalIndexAt(event.position().toPoint())
        if logical >= 0:
            sel_columns = set()
            if self._table_view:
                sel_model = self._table_view.selectionModel()
                if sel_model:
                    sel_columns = set(idx.column() for idx in sel_model.selectedColumns())
            add = bool(event.modifiers() & Qt.ControlModifier)
            should_select = not (event.button() == Qt.RightButton and logical in sel_columns)
            if should_select:
                self.select_callback(logical, add)
                if add:
                    # tránh cho super() xóa selection khi Ctrl đang giữ
                    event.accept()
                    return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resizing:
            delta = event.position().y() - self._start_y
            new_h = max(20, int(self._start_h + delta))
            self.setFixedHeight(new_h)
            event.accept()
            return
        # nếu trỏ gần mép dưới thì hiển thị cursor kéo dọc, ngược lại để header xử lý mặc định (kéo rộng cột)
        if abs(event.position().y() - self.height()) <= self._resize_margin:
            self.setCursor(Qt.SizeVerCursor)
        else:
            self.unsetCursor()
            # hiển thị vị trí thả khi đang kéo cột
            if event.buttons() & Qt.LeftButton:
                self._show_drag_indicator(event.position().toPoint())
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._resizing:
            self._resizing = False
            if self.height_changed:
                self.height_changed(self.height())
            event.accept()
            return
        self._hide_drag_indicator()
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        logical = self.logicalIndexAt(event.position().toPoint())
        if logical >= 0 and self.sort_callback:
            self.sort_callback(logical)
        super().mouseDoubleClickEvent(event)

    def _show_drag_indicator(self, pos):
        logical = self.logicalIndexAt(pos)
        if logical < 0:
            self._hide_drag_indicator()
            return
        x = self.sectionViewportPosition(logical)
        # nếu kéo sang phải quá nửa section, đặt vạch ở sau section
        if pos.x() > x + self.sectionSize(logical) // 2:
            x += self.sectionSize(logical)
        if not self._drag_indicator:
            self._drag_indicator = QFrame(self.viewport())
            self._drag_indicator.setFrameShape(QFrame.VLine)
            self._drag_indicator.setLineWidth(2)
            self._drag_indicator.setStyleSheet("color: #4a90e2;")
        self._drag_indicator.setGeometry(x, 0, 2, self.height())
        self._drag_indicator.show()

    def _hide_drag_indicator(self):
        if self._drag_indicator:
            self._drag_indicator.hide()


class RowHeaderView(QHeaderView):
    def __init__(self, table: QTableView) -> None:
        super().__init__(Qt.Vertical, table)
        self.table = table
        self._selection_model = None
        self._selected_rows: set[int] = set()
        self.setHighlightSections(False)

    def bind_selection_model(self) -> None:
        sm = self.table.selectionModel()
        if sm is None or sm is self._selection_model:
            return
        if self._selection_model:
            try:
                self._selection_model.selectionChanged.disconnect(self._on_selection_changed)
            except Exception:
                pass
        self._selection_model = sm
        self._selection_model.selectionChanged.connect(self._on_selection_changed)
        self._on_selection_changed()

    def _on_selection_changed(self, selected=None, deselected=None) -> None:
        if not self._selection_model:
            return
        rows = {idx.row() for idx in self._selection_model.selectedIndexes()}
        if rows != self._selected_rows:
            self._selected_rows = rows
            self.viewport().update()

    def paintSection(self, painter, rect, logicalIndex) -> None:
        option = QStyleOptionHeader()
        self.initStyleOption(option)
        option.rect = rect
        option.section = logicalIndex
        model = self.model()
        header_text = None
        if model:
            header_text = model.headerData(logicalIndex, Qt.Vertical, Qt.DisplayRole)
        text = str(header_text) if header_text is not None else str(logicalIndex + 1)
        option.text = ""
        painter.save()
        self.style().drawControl(QStyle.CE_Header, option, painter, self)
        painter.restore()
        painter.save()
        font = QFont(self.font())
        font.setBold(logicalIndex in self._selected_rows)
        painter.setFont(font)
        painter.setPen(QColor("#00f2ff") if logicalIndex in self._selected_rows else QColor("#d1d5db"))
        painter.drawText(rect, Qt.AlignCenter, text)
        painter.restore()


class FilterLineEdit(QLineEdit):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Hiện nút xóa nhanh ngay trong ô lọc
        self.setClearButtonEnabled(True)

    def mouseDoubleClickEvent(self, event):
        super().mouseDoubleClickEvent(event)
        self.returnPressed.emit()


class FlowLayout(QLayout):
    """Flow layout (xếp hàng tự xuống dòng) lấy từ ví dụ Qt."""

    def __init__(self, parent=None, margin=0, hspacing=8, vspacing=6):
        super().__init__(parent)
        self.itemList = []
        self.setContentsMargins(margin, margin, margin, margin)
        self._hspacing = hspacing
        self._vspacing = vspacing

    def addItem(self, item):
        self.itemList.append(item)

    def count(self):
        return len(self.itemList)

    def itemAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList[index]
        return None

    def takeAt(self, index):
        if 0 <= index < len(self.itemList):
            return self.itemList.pop(index)
        return None

    def expandingDirections(self):
        return Qt.Orientations(Qt.Horizontal)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        height = self.doLayout(QRect(0, 0, width, 0), True)
        return height

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self.doLayout(rect, False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        left, top, right, bottom = self.getContentsMargins()
        return QSize(left + right, top + bottom)

    def doLayout(self, rect, testOnly):
        x = rect.x()
        y = rect.y()
        lineHeight = 0

        for item in self.itemList:
            wid = item.widget()
            spaceX = self._hspacing
            spaceY = self._vspacing
            nextX = x + item.sizeHint().width() + spaceX
            if nextX - spaceX > rect.right() and lineHeight > 0:
                x = rect.x()
                y = y + lineHeight + spaceY
                nextX = x + item.sizeHint().width() + spaceX
                lineHeight = 0
            if not testOnly:
                item.setGeometry(QRect(QPoint(x, y), item.sizeHint()))
            x = nextX
            lineHeight = max(lineHeight, item.sizeHint().height())
        return y + lineHeight - rect.y()


class FlowWidget(QWidget):
    """Widget bọc flow layout để hỗ trợ heightForWidth -> tự xuống dòng."""

    def hasHeightForWidth(self):
        l = self.layout()
        return l.hasHeightForWidth() if l else False

    def heightForWidth(self, w: int) -> int:
        l = self.layout()
        if l and l.hasHeightForWidth():
            return l.heightForWidth(w)
        return super().heightForWidth(w)

    def sizeHint(self):
        l = self.layout()
        return l.sizeHint() if l else super().sizeHint()

    def minimumSizeHint(self):
        l = self.layout()
        return l.minimumSize() if l else super().minimumSizeHint()

class StatsDateEdit(QDateEdit):
    """DateEdit cho tab Thống kê: mũi tên mở dialog chọn ngày nhanh giống tab dữ liệu."""

    def __init__(self, parent=None):
        super().__init__(parent)
        # đặt chiều cao khớp với combo Vị trí/Lô (khoảng 25-26px)
        target_h = 26
        self.setMinimumHeight(target_h)
        self.setFixedHeight(target_h)
        self.setCalendarPopup(True)
        self.setDisplayFormat("dd/MM/yyyy")
        self.setSpecialValueText("--")
        min_dt = QDate(1900, 1, 1)
        self.setMinimumDate(min_dt)
        self.setDate(min_dt)
        # Nút clear để xóa nhanh giá trị ngày (custom, tránh bị che bởi mũi tên)
        self._drop_down_width = 18
        self._clear_btn = QToolButton(self)
        self._clear_btn.setText("x")
        self._clear_btn.setCursor(Qt.PointingHandCursor)
        self._clear_btn.setVisible(False)
        self._clear_btn.clicked.connect(self._clear_date)
        le = self.lineEdit()
        if le:
            try:
                le.setClearButtonEnabled(False)
            except Exception:
                pass
            le.setAlignment(Qt.AlignCenter)
            # Chỉ hiện nút clear khi có giá trị
            def _toggle_clear(txt: str):
                if self._clear_btn:
                    self._clear_btn.setVisible(bool(txt.strip() and txt.strip() != "--"))
            le.textChanged.connect(_toggle_clear)
            _toggle_clear(le.text())
        # Style: nền xám đen, chữ sáng, mũi tên trắng, bỏ nền trắng mặc định
        self.setStyleSheet(
            """
            QDateEdit {
                background: #1f2430;
                border: 1px solid #3a425a;
                color: #e5e7eb;
                padding: 2px 26px 2px 6px;
                border-radius: 3px;
                qproperty-alignment: AlignCenter;
            }
            QDateEdit::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 18px;
                border: none;
                background: transparent;
            }
            QDateEdit::down-arrow {
                width: 0;
                height: 0;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 7px solid #e5e7eb;
                margin-right: 6px;
            }
            QDateEdit::down-arrow:disabled {
                border-top: 7px solid #6f768a;
            }
            """
        )
        self._clear_btn.setStyleSheet(
            """
            QToolButton {
                background: transparent;
                color: #e5e7eb;
                border: none;
                padding: 0px;
                font-size: 10px;
            }
            QToolButton:hover {
                color: #ffffff;
            }
            """
        )

    def mousePressEvent(self, event):
        # nếu đang hiển thị "--", click để nhập sẽ xóa placeholder
        if self.text().strip() == "--":
            le = self.lineEdit()
            if le:
                le.clear()
        if event.button() == Qt.LeftButton:
            self._open_quick_picker()
            event.accept()
            return
        super().mousePressEvent(event)

    def focusInEvent(self, event):
        # Khi click/đặt focus, nếu đang hiển thị "--" thì xóa để gõ dễ
        if self.text().strip() == "--":
            le = self.lineEdit()
            if le:
                le.clear()
        super().focusInEvent(event)

    def focusOutEvent(self, event):
        # Khôi phục placeholder nếu trống
        if not self.text().strip():
            self.setDate(self.minimumDate())
        super().focusOutEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # đặt nút clear bên trái mũi tên lịch
        if self._clear_btn:
            btn_w = 12
            btn_h = 12
            x = self.width() - self._drop_down_width - btn_w - 6
            y = (self.height() - btn_h) // 2
            self._clear_btn.setGeometry(x, y, btn_w, btn_h)

    def _clear_date(self):
        self.setDate(self.minimumDate())
        le = self.lineEdit()
        if le:
            le.clear()
        if self._clear_btn:
            self._clear_btn.setVisible(False)

    def _open_quick_picker(self):
        dialog = QuickDateTimeDialog(self, self.text(), include_time=False)
        if dialog.exec() == QDialog.Accepted:
            val = dialog.value()
            if val:
                dt = parse_datetime_string(val, include_time=False)
                if dt:
                    self.setDate(QDate(dt.year, dt.month, dt.day))
                    return
            # nếu rỗng, coi như clear
        self.setDate(self.minimumDate())


class StatsHeader(QHeaderView):
    """
    Header 2 dòng cho bảng thống kê: dòng trên = tháng, dòng dưới = ngưỡng (< / >).
    Không gộp ô; chỉ vẽ một đường ngang ngăn cách giữa 2 dòng.
    """

    def __init__(self, parent=None):
        super().__init__(Qt.Horizontal, parent)
        self.setDefaultAlignment(Qt.AlignCenter)
        self.setSectionsClickable(True)
        self.setHighlightSections(True)
        self._base_height = 44

    def sizeHint(self):
        sz = super().sizeHint()
        sz.setHeight(self._base_height)
        return sz

    def paintSection(self, painter, rect, logicalIndex):
        if not rect.isValid():
            return

        # Lấy text header, tách 2 dòng bằng ký tự xuống dòng
        raw = self.model().headerData(logicalIndex, Qt.Horizontal, Qt.DisplayRole)
        text = "" if raw is None else str(raw)
        parts = text.split("\\n", 1)
        top = parts[0]
        bottom = parts[1] if len(parts) > 1 else ""

        painter.save()

        # Vẽ nền + viền theo style mặc định để khớp theme
        opt = QStyleOptionHeader()
        self.initStyleOption(opt)
        opt.text = ""
        opt.rect = rect
        opt.section = logicalIndex
        self.style().drawControl(QStyle.CE_HeaderSection, opt, painter, self)

        font_top = QFont(self.font())
        font_top.setBold(True)
        font_bottom = QFont(self.font())
        fm_top = QFontMetrics(font_top)
        fm_bottom = QFontMetrics(font_bottom)
        margin = 4

        pen_text = self.palette().color(QPalette.ButtonText)
        pen_line = pen_text

        if bottom:
            total_h = fm_top.height() + fm_bottom.height() + margin
            y_top = rect.y() + max(0, (rect.height() - total_h) // 2)

            painter.setFont(font_top)
            painter.setPen(pen_text)
            top_rect = QRect(rect)
            top_rect.setY(y_top)
            top_rect.setHeight(fm_top.height())
            painter.drawText(top_rect, Qt.AlignHCenter | Qt.AlignTop, top)

            y_line = y_top + fm_top.height() + margin // 2
            painter.setPen(pen_line)
            painter.drawLine(rect.left() + 1, y_line, rect.right() - 1, y_line)

            painter.setFont(font_bottom)
            painter.setPen(pen_text)
            bottom_rect = QRect(rect)
            bottom_rect.setY(y_line + margin // 2)
            bottom_rect.setHeight(fm_bottom.height())
            painter.drawText(bottom_rect, Qt.AlignHCenter | Qt.AlignTop, bottom)
        else:
            painter.setFont(font_top)
            painter.setPen(pen_text)
            painter.drawText(rect.adjusted(2, 0, -2, 0), Qt.AlignCenter, top)

        painter.restore()

class PhoneFilterButton(QToolButton):
    """Nút lọc danh sách SĐT: click mở dialog, double-click xóa lọc."""

    def __init__(self, col_idx: int, on_click, on_double, parent=None):
        super().__init__(parent)
        self.col_idx = col_idx
        self.on_click = on_click
        self.on_double = on_double
        self._click_timer = QTimer(self)
        self._click_timer.setSingleShot(True)
        self._click_timer.timeout.connect(self._fire_click)

    def _fire_click(self):
        if callable(self.on_click):
            self.on_click(self.col_idx)

    def mouseDoubleClickEvent(self, event):
        # hủy click đơn, thực hiện xóa lọc
        if self._click_timer.isActive():
            self._click_timer.stop()
        if callable(self.on_double):
            self.on_double(self.col_idx)
        event.accept()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            # chờ xem có double click không (timeout ngắn)
            self._click_timer.start(200)
            event.accept()
            return
        super().mouseReleaseEvent(event)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("APP kho sim miễn phí MXHSHOP 0779.10.7999")
        self.resize(1300, 750)
        self.current_path = EXCEL_PATH
        self.current_theme = "Sáng"
        self.headers: List[str] = []
        self.rows_all: List[List[Any]] = []  # dữ liệu gốc
        self.rows: List[List[Any]] = []  # dữ liệu đang hiển thị (sau lọc)
        self.row_histories: List[List[str]] = []  # log thay đổi từng hàng
        self.cell_styles: dict[str, dict] = {}  # style theo ô
        self.row_histories: List[List[str]] = []  # lịch sử thời gian chỉnh sửa mỗi dòng
        self.saved_column_widths = {}
        self._last_width_info: Optional[tuple[str, int]] = None
        self.hidden_columns: set[int] = set()
        self.letter_visible_pref: bool = True
        self.phone_list_filter: Optional[set[str]] = None
        self.alignment_map: dict[str, int] = {}
        self.filter_inputs: List[QLineEdit] = []
        self.filter_letter_labels: List[QLabel] = []
        self.filter_clear_buttons: List[QToolButton] = []
        self.filter_extra_buttons: List[QToolButton] = []
        self.filter_quick_buttons: List[Optional[QToolButton]] = []
        self.filter_nav_buttons: List[QToolButton] = []
        self._selection_model = None
        self.filter_values: dict[int, str] = {}
        self.source_headers: List[str] = []
        self.current_sheet: Optional[str] = None
        self.saved_header_height: Optional[int] = None
        self.history_countdown_label: Optional[QLabel] = None
        self.templates: List[dict] = []
        self.active_template: Optional[str] = None
        self.autosave_timer = QTimer(self)
        self.autosave_timer.setSingleShot(False)
        self.autosave_timer.timeout.connect(self._write_excel)
        self.autosave_interval_ms = 60000  # mặc định 1 phút
        self.autosave_enabled = True
        self._shrink_target_width: Optional[int] = None
        self.column_formats: dict[str, str] = {}
        self.sort_orders: dict[int, bool] = {}
        self.show_index_column = False
        self.session_history: List[dict] = []
        self.alert_templates: List[dict] = []
        self.history_timer = QTimer(self)
        self.history_timer.setInterval(30 * 60 * 1000)
        self.history_timer.timeout.connect(lambda: self._record_session(force=True))
        self._history_selected_snapshot: Optional[str] = None
        self._history_next_due: Optional[datetime] = None
        self.history_countdown_timer = QTimer(self)
        self.history_countdown_timer.setInterval(1000)
        self.history_countdown_timer.timeout.connect(self._update_history_countdown)
        self.history_enabled = False
        self.undo_stack: List[dict] = []
        self.redo_stack: List[dict] = []
        self._undoing = False
        self._last_state_snapshot: Optional[dict] = None
        self._migr_status_yellow_removed_ver: int = 0
        self._stats_lineedits: set[QLineEdit] = set()
        self.row_height = 20
        self.saved_tab_index: int = 0
        self.saved_stats_template: Optional[str] = None
        self.stats_nm_widths: dict[str, int] = {}
        self.stats_tk_threshold: int = 250
        # Cảnh báo (Data tab)
        self.alert_rules: List[dict] = []
        self.alert_send_enabled: bool = False
        # Telegram credentials are configured in the Settings tab and persisted in state.json
        self.alert_bot_token: str = ""
        self.alert_chat_id: str = ""
        self.alert_sent_map: dict[str, str] = {}
        self.alert_ops_order: List[str] = []
        self.alert_ops_hidden: set[str] = set()
        # throttle retry when Telegram fails (avoid retrying too often)
        self.alert_try_map: dict[str, float] = {}
        self._telegram_last_error: str = ""
        self._telegram_missing_creds_warned: bool = False
        self._load_state()
        self._seed_default_alert_templates()
        self._load_cached_data()
        self._ensure_alert_rule_ids()
        self._ensure_source_column()
        self._ensure_change_column()
        self._ensure_row_histories()
        self._apply_autosave_setting()
        self.history_timer.start()
        self._reset_history_countdown()
        self.history_countdown_timer.start()
        self._state_save_timer = QTimer(self)
        self._state_save_timer.setSingleShot(True)
        self._state_save_timer.timeout.connect(self._save_state)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_data_tab(), "Dữ liệu")
        self.tabs.addTab(self._build_stats_tab(), "Thống kê")
        self.tabs.addTab(self._build_settings_tab(), "Cài đặt")
        self.tabs.currentChanged.connect(lambda _: self._save_state())
        ver_label = QLabel("Phiên bản hiện tại 1.0")
        ver_label.setStyleSheet("color:#9ca3af; padding:4px 10px 4px 6px; font-weight:600;")
        self.tabs.setCornerWidget(ver_label, Qt.TopRightCorner)
        self.setCentralWidget(self.tabs)
        # Khôi phục tab trước đó nếu có (sau khi tabs sẵn sàng)
        def _restore_tab():
            try:
                idx = max(0, min(self.saved_tab_index, self.tabs.count() - 1))
                self.tabs.setCurrentIndex(idx)
            except Exception:
                pass
        QTimer.singleShot(0, _restore_tab)
        self._hide_qt_status_bar()
        self._migrate_remove_status_yellow()

        # nếu không có data cache thì đọc từ file gốc
        if not self.headers:
            self.reload()
        else:
            self._apply_default_alignment()
            self._set_model(self.headers, self.rows)
            self._refresh_source_labels()
            self._refresh_stats()
        self.apply_theme(self.current_theme)

        # Quét cảnh báo định kỳ để gửi Telegram (không phụ thuộc repaint của bảng)
        self._alert_scan_timer = QTimer(self)
        self._alert_scan_timer.setInterval(60_000)  # 60s
        self._alert_scan_timer.timeout.connect(self._scan_alerts_and_send)
        self._alert_scan_timer.start()
        QTimer.singleShot(1500, self._scan_alerts_and_send)

    def reload(self) -> None:
        self._release_shrink()
        self.table.setMaximumWidth(16777215)
        self.table.setMinimumWidth(0)
        self.filter_area.setMaximumWidth(16777215)
        self.filter_area.setMinimumWidth(0)
        try:
            headers_file, rows_file, sheet_name = load_table_data(self.current_path)
        except Exception as exc:
            QMessageBox.critical(self, "Lỗi đọc file", str(exc))
            return
        self.current_sheet = sheet_name
        headers_file = list(headers_file)
        headers_file, rows_file = self._apply_template_to_import(headers_file, rows_file)
        if self.active_template:
            self.headers = headers_file.copy()
            self.source_headers = headers_file.copy()
        elif not self.headers:
            self.headers = headers_file.copy()
            self.source_headers = headers_file.copy()
        else:
            new_len = len(headers_file)
            while len(self.headers) < new_len:
                self.headers.append("")
            while len(self.source_headers) < new_len:
                self.source_headers.append("")
            for idx, file_header in enumerate(headers_file):
                prev_source = self.source_headers[idx] if idx < len(self.source_headers) else ""
                current = self.headers[idx]
                if not prev_source or current == prev_source:
                    self.headers[idx] = file_header
                self.source_headers[idx] = file_header
            self._trim_columns_to(new_len)
        self._ensure_source_column()
        self._ensure_change_column()
        target_len = len(self.headers)
        rows_norm = self._normalize_rows(rows_file, target_len)
        self._apply_source_column(rows_norm, self.current_sheet)
        self.rows_all = rows_norm
        self._auto_detect_formats()
        self._apply_default_alignment()
        self._apply_fixed_width_rules()
        self._ensure_row_histories()
        self.sort_orders.clear()
        self._force_autoresize = True
        self._apply_filters()
        self._persist_now()
        self._refresh_source_labels()
        self._refresh_stats()

    def add_file(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Thêm file Excel",
            str(self.current_path.parent),
            "Excel Files (*.xlsx *.xls)",
        )
        if not file_path:
            return
        path = Path(file_path)
        sheet_name = self._select_sheet_for_add(path)
        if sheet_name is None:
            return
        if sheet_name == "__ALL__":
            self._append_all_sheets(path)
        else:
            self._append_from_file(path, sheet_name)

    def apply_theme(self, theme_name: str) -> None:
        """Áp dụng stylesheet cho toàn app."""
        app = QApplication.instance()
        style = THEMES.get(theme_name, "")
        if app:
            app.setStyleSheet(style)
        self.current_theme = theme_name
        if self.theme_combo.currentText() != theme_name:
            self.theme_combo.setCurrentText(theme_name)
        self._save_state()

    def _build_data_tab(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.main_layout = layout
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(-2)

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(3, 8, 0, 0)
        top_bar.setSpacing(4)
        self.template_combo = QComboBox()
        self.template_combo.setFixedSize(150, 28)
        self.template_combo.currentIndexChanged.connect(self._on_template_changed)
        self.template_combo.view().installEventFilter(self)
        self.template_combo.setStyleSheet(
            "QComboBox { font-weight: 600; } QAbstractItemView { font-weight: 600; }"
        )
        self.template_combo.setToolTip("Chọn / đổi mẫu trang")
        btn_template_save = QPushButton("💾 Lưu")
        btn_template_save.setFixedSize(70, 30)
        btn_template_save.clicked.connect(self._save_template)
        btn_template_save.setToolTip("Lưu trang hiện tại thành mẫu")
        btn_template_add = QPushButton("➕ Thêm trang")
        btn_template_add.setFixedSize(115, 30)
        btn_template_add.clicked.connect(self._add_template)
        btn_template_add.setToolTip("Tạo trang trống mới")
        btn_clear_table = QPushButton("🗑️ Xóa bảng")
        btn_clear_table.setFixedSize(100, 30)
        btn_clear_table.clicked.connect(self._clear_table_data)
        btn_clear_table.setToolTip("Xóa dữ liệu đang hiển thị (giữ nguyên header)")
        btn_alert = QPushButton("🚨 Cảnh báo")
        btn_alert.setFixedSize(105, 30)
        btn_alert.clicked.connect(self._open_alert_manager)
        btn_alert.setToolTip("Thiết lập cảnh báo & gửi Telegram (token/chat lấy từ tab Cài đặt)")
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        btn_shrink = QPushButton("↔ Thu gọn")
        btn_shrink.setFixedSize(85, 30)
        btn_shrink.clicked.connect(self._shrink_right_edge)
        btn_shrink.setToolTip("Thu gọn chiều ngang bảng sát cột cuối")
        btn_choose = QPushButton("📂 Thêm file...")
        btn_choose.setFixedSize(114, 30)
        btn_choose.clicked.connect(self.add_file)
        btn_choose.setToolTip("Nạp thêm file Excel vào bảng")
        self.btn_history = QPushButton("🕘 Lịch sử phiên")
        self.btn_export = QPushButton("📤 Xuất file")
        self.btn_export.setFixedSize(100, 30)
        self.btn_export.clicked.connect(self._export_file)
        self.btn_export.setToolTip("Xuất dữ liệu ra Excel/CSV")
        self.btn_history.setFixedSize(125, 30)
        self.btn_history.clicked.connect(self._show_history)
        self.btn_history.setToolTip("Xem và khôi phục lịch sử phiên")
        self._style_action_button(btn_template_save, "#22c55e", "#16a34a")
        self._style_action_button(btn_template_add, "#0ea5e9", "#0284c7")
        self._style_action_button(btn_clear_table, "#ef4444", "#dc2626")
        self._style_action_button(btn_alert, "#f97316", "#ea580c")
        self._style_action_button(btn_choose, "#6366f1", "#4f46e5")
        self._style_action_button(btn_shrink, "#f59e0b", "#d97706")
        self._style_action_button(self.btn_export, "#10b981", "#059669")
        self._style_action_button(self.btn_history, "#8b5cf6", "#7c3aed")
        top_bar.addWidget(self.template_combo)
        top_bar.addWidget(btn_template_save)
        top_bar.addWidget(btn_template_add)
        top_bar.addWidget(btn_clear_table)
        top_bar.addWidget(btn_alert)
        top_bar.addWidget(spacer)
        for btn in (btn_choose, btn_shrink, self.btn_export, self.btn_history):
            top_bar.addWidget(btn)
        layout.addLayout(top_bar)

        # Hàng lọc (trong scroll area để sync ngang với bảng)
        self.filter_bar = QWidget()
        self.filter_bar.setMinimumHeight(41)
        self.filter_bar.setContentsMargins(0, 0, 0, 0)
        self.filter_area = QScrollArea()
        self.filter_area.setWidgetResizable(True)
        self.filter_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.filter_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.filter_area.setFrameShape(QFrame.NoFrame)
        self.filter_area.installEventFilter(self)
        self.filter_area.setContentsMargins(0, 0, 0, 0)
        self.filter_area.setWidget(self.filter_bar)
        self.filter_area.setFixedHeight(self.filter_bar.minimumHeight())

        self.corner_label = QLabel("", self)
        self.corner_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.corner_label.setMargin(4)
        self.table = QTableView()
        header_view = ColumnHeader(
            Qt.Horizontal,
            self.table,
            select_callback=self._select_column_from_header,
            rename_callback=self._rename_header,
            sort_callback=self._sort_column,
            height_changed=self._on_header_height_changed,
        )
        header_height = self.saved_header_height
        if header_height is None:
            header_height = max(20, header_view.sizeHint().height() + 7)
        header_view.setFixedHeight(int(header_height))
        header_view.setSectionsMovable(True)
        header_view.setDefaultAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        header_view.setDefaultSectionSize(140)
        self.table.setHorizontalHeader(header_view)
        self.table.horizontalHeader().setStretchLastSection(False)
        self.row_header = RowHeaderView(self.table)
        self.table.setVerticalHeader(self.row_header)
        vh = self.table.verticalHeader()
        vh.setVisible(True)
        vh.setSectionResizeMode(QHeaderView.Fixed)
        vh.setSectionsClickable(True)
        vh.setMinimumSectionSize(20)
        vh.setDefaultSectionSize(20)
        vh.setContextMenuPolicy(Qt.CustomContextMenu)
        vh.customContextMenuRequested.connect(self._show_row_header_menu)
        vh.setStyleSheet(
            """
            QHeaderView::section:selected {
                background-color: #00f2ff;
                color: #020202;
            }
            QHeaderView::section {
                background-color: transparent;
                border: none;
            }
        """
        )
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(True)
        self.table.setSelectionBehavior(QTableView.SelectItems)
        self.table.setSelectionMode(QTableView.ExtendedSelection)
        self.table.setShowGrid(True)
        self.table.setEditTriggers(
            QTableView.DoubleClicked
            | QTableView.SelectedClicked
            | QTableView.EditKeyPressed
            | QTableView.AnyKeyPressed
        )
        self.table.setGridStyle(Qt.SolidLine)
        self.table.setHorizontalScrollMode(QTableView.ScrollPerPixel)
        self.table.setVerticalScrollMode(QTableView.ScrollPerPixel)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.table.horizontalHeader().setDefaultAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setSizeAdjustPolicy(QAbstractScrollArea.AdjustIgnored)
        # tinh chỉnh bước cuộn để thanh trượt ngang mượt hơn
        hbar = self.table.horizontalScrollBar()
        hbar.setSingleStep(5)
        hbar.setPageStep(max(80, self.table.viewport().width() // 3))
        self.table.installEventFilter(self)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.horizontalHeader().setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.horizontalHeader().customContextMenuRequested.connect(self._show_header_menu)
        self.table.customContextMenuRequested.connect(self._show_table_context_menu)
        self.table.horizontalHeader().sectionResized.connect(self._sync_filter_widths)
        self.table.horizontalHeader().sectionResized.connect(self._schedule_state_save)
        self.table.horizontalHeader().sectionResized.connect(self._on_column_resized)
        self.table.horizontalHeader().sectionMoved.connect(self._sync_filter_widths)
        self.table.setCornerWidget(self.corner_label)
        self.table.doubleClicked.connect(self._on_table_double_clicked)
        layout.addWidget(self.filter_area)
        layout.addWidget(self.table, stretch=1)
        self.letter_bar = QWidget()
        self.letter_bar.setMinimumHeight(16)
        self.letter_bar.setMaximumHeight(16)
        self.letter_bar.setContentsMargins(0, 0, 0, 0)
        self.letter_toggle = QToolButton()
        self.letter_toggle.setText("▾")
        self.letter_toggle.setCheckable(True)
        self.letter_toggle.setChecked(True)
        self.letter_toggle.setFixedSize(20, 16)
        self.letter_toggle.setStyleSheet(
            "QToolButton { border: none; color: #f59e0b; font-weight: 700; }"
        )
        self.letter_toggle.setToolTip("Ẩn/hiện hàng chỉ thị A,B,C...")
        self.letter_toggle.toggled.connect(self._toggle_letter_bar)
        self.letter_wrap = QWidget()
        self.letter_wrap.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        lw_layout = QHBoxLayout(self.letter_wrap)
        lw_layout.setContentsMargins(0, 0, 0, 0)
        lw_layout.setSpacing(4)
        lw_layout.addWidget(self.letter_toggle, 0, Qt.AlignLeft | Qt.AlignVCenter)
        lw_layout.addWidget(self.letter_bar, 1)
        self.letter_wrap.setFixedHeight(20)
        layout.addWidget(self.letter_wrap)
        # Thanh trạng thái
        self.status_bar = QLabel("Tổng: 0 | Dòng: 0 | Không trống: 0/0", self)
        self.status_bar.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.status_bar.setContentsMargins(6, 0, 6, 0)
        self.status_bar.setStyleSheet("color: #9ba0b5;")
        self.status_bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        layout.addWidget(self.status_bar)
        # áp dụng trạng thái ẩn/hiện đã lưu
        self.letter_toggle.blockSignals(True)
        self.letter_toggle.setChecked(self.letter_visible_pref)
        self.letter_toggle.blockSignals(False)
        self._toggle_letter_bar(self.letter_visible_pref)

        # Sync horizontal scroll giữa bảng và hàng lọc
        self.table.horizontalScrollBar().valueChanged.connect(self._on_horizontal_scroll)

        self._update_history_countdown()
        return page

    def _style_action_button(self, button: QPushButton, base: str, hover: str) -> None:
        button.setStyleSheet(
            f"""
            QPushButton {{
                background: {base};
                color: #ffffff;
                border: 1px solid {base};
                border-radius: 6px;
                padding: 4px 10px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background: {hover};
                border: 1px solid {hover};
            }}
            QPushButton:pressed {{
                background: {hover};
            }}
            """
        )

    def _shrink_right_edge(self) -> None:
        """Thu hẹp chiều ngang để mép phải sát cột cuối."""
        # Không ép kích thước cửa sổ; chỉ cuộn đến cuối bảng
        self._shrink_target_width = None
        hbar = self.table.horizontalScrollBar()
        hbar.setValue(hbar.maximum())
        self._sync_filter_widths()

    def _release_shrink(self) -> None:
        if self._shrink_target_width is None:
            return
        self._shrink_target_width = None
        self.table.setMinimumWidth(0)
        self.table.setMaximumWidth(16777215)
        self.filter_area.setMinimumWidth(0)
        self.filter_area.setMaximumWidth(16777215)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        if self._shrink_target_width is not None and self.width() > self._shrink_target_width + 20:
            self._release_shrink()
            self._sync_filter_widths()

    def _on_horizontal_scroll(self, value: int) -> None:
        self.filter_area.horizontalScrollBar().setValue(value)
        self._sync_letter_labels()

    def _build_settings_tab(self) -> QWidget:
        page = QWidget()
        form = QFormLayout(page)
        page.setMaximumWidth(420)
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(THEMES.keys())
        self.theme_combo.setCurrentText(self.current_theme)
        self.theme_combo.currentTextChanged.connect(self.apply_theme)
        form.addRow("Theme giao diện:", self.theme_combo)

        # Auto save Excel theo số + đơn vị
        self.autosave_input = QLineEdit()
        self.autosave_unit = QComboBox()
        self.autosave_unit.addItems(["giây", "phút"])
        # đặt giá trị theo state
        if self.autosave_interval_ms >= 60000 and self.autosave_interval_ms % 60000 == 0:
            val = max(1, self.autosave_interval_ms // 60000)
            self.autosave_input.setText(str(val))
            self.autosave_unit.setCurrentText("phút")
        else:
            val = max(1, self.autosave_interval_ms // 1000) if self.autosave_interval_ms > 0 else 60
            self.autosave_input.setText(str(val))
            self.autosave_unit.setCurrentText("giây")
        self.autosave_input.editingFinished.connect(self._update_autosave_from_inputs)
        self.autosave_unit.currentTextChanged.connect(lambda _: self._update_autosave_from_inputs())
        autosave_row = QHBoxLayout()
        autosave_row.setContentsMargins(0, 0, 0, 0)
        autosave_row.addWidget(self.autosave_input)
        autosave_row.addWidget(self.autosave_unit)
        self.autosave_toggle = QCheckBox("Bật")
        self.autosave_toggle.setChecked(self.autosave_enabled)
        self.autosave_toggle.toggled.connect(self._set_autosave_enabled)
        autosave_row.addWidget(self.autosave_toggle)
        autosave_row_widget = QWidget()
        autosave_row_widget.setLayout(autosave_row)
        form.addRow("Tự động lưu Excel:", autosave_row_widget)

        # Set row height
        row_height_layout = QHBoxLayout()
        row_height_layout.setContentsMargins(0, 0, 0, 0)
        self.row_height_input = QLineEdit(str(self.row_height))
        self.row_height_input.setFixedWidth(80)
        btn_row_height = QPushButton("Áp dụng")
        btn_row_height.setFixedWidth(80)
        btn_row_height.clicked.connect(self._apply_row_height_setting)
        row_height_layout.addWidget(self.row_height_input)
        row_height_layout.addWidget(btn_row_height)
        rh_widget = QWidget()
        rh_widget.setLayout(row_height_layout)
        form.addRow("Set cao dòng:", rh_widget)

        # Telegram settings (token + pick chat_id from getUpdates)
        tg_title = QLabel("Telegram")
        tg_title.setStyleSheet("font-weight:700; margin-top:10px;")
        form.addRow(tg_title)

        self.tg_token_input = QLineEdit()
        self.tg_token_input.setPlaceholderText("123456:ABCDEF...")
        self.tg_token_input.setText(str(getattr(self, "alert_bot_token", "") or ""))

        def _apply_token():
            token = self.tg_token_input.text().strip()
            if token != (self.alert_bot_token or ""):
                self.alert_bot_token = token
                self._telegram_last_error = ""
                self.alert_sent_map.clear()
                self.alert_try_map.clear()
                self._save_state()
                QTimer.singleShot(300, self._scan_alerts_and_send)

        self.tg_token_input.editingFinished.connect(_apply_token)
        form.addRow("Token Bot:", self.tg_token_input)

        chat_row = QHBoxLayout()
        chat_row.setContentsMargins(0, 0, 0, 0)
        self.tg_chat_id_input = QLineEdit()
        self.tg_chat_id_input.setReadOnly(True)
        self.tg_chat_id_input.setText(str(getattr(self, "alert_chat_id", "") or ""))
        btn_pick_chat = QPushButton("Chọn chatID")
        btn_pick_chat.setToolTip("Load getUpdates để liệt kê chat (user/nhóm) rồi chọn chat_id dùng để thông báo")
        btn_test_tg = QPushButton("Test")
        btn_test_tg.setToolTip("Gửi thử 1 tin nhắn Telegram")
        chat_row.addWidget(self.tg_chat_id_input, 1)
        chat_row.addWidget(btn_pick_chat)
        chat_row.addWidget(btn_test_tg)
        chat_widget = QWidget()
        chat_widget.setLayout(chat_row)
        form.addRow("Chat ID:", chat_widget)

        hint = QLabel("Gợi ý: hãy nhắn /start cho bot hoặc gửi 1 tin trong nhóm có bot, rồi bấm 'Chọn chatID' để thấy chat xuất hiện.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#9ca3af;")
        form.addRow(hint)

        def _apply_chat_id(chat_id: str):
            chat_id = str(chat_id or "").strip()
            if chat_id != (self.alert_chat_id or ""):
                self.alert_chat_id = chat_id
                self.tg_chat_id_input.setText(chat_id)
                self._telegram_last_error = ""
                self.alert_sent_map.clear()
                self.alert_try_map.clear()
                self._save_state()
                QTimer.singleShot(300, self._scan_alerts_and_send)

        def do_pick_chat():
            _apply_token()
            token = (self.alert_bot_token or "").strip()
            chat = self._pick_telegram_chat_from_updates(token)
            if chat and chat.get("id"):
                _apply_chat_id(chat["id"])

        def do_test():
            _apply_token()
            ok, err = self._telegram_send_message(f"MXHsim test: {datetime.now().strftime('%H:%M:%S %d/%m/%Y')}")
            if ok:
                QMessageBox.information(self, "Telegram", "Đã gửi tin nhắn test.")
            else:
                QMessageBox.warning(self, "Telegram", f"Không gửi được Telegram:\n{err}")

        btn_pick_chat.clicked.connect(do_pick_chat)
        btn_test_tg.clicked.connect(do_test)
        return page

    # ============ Stats tab ============ #
    def _build_stats_tab(self) -> QWidget:
        page = QWidget()
        main_layout = QVBoxLayout(page)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Nội dung chính đặt trong scroll để không bị che khuất khi thêm biểu đồ
        content = QWidget()
        layout = QVBoxLayout(content)
        # tăng lề trên để tránh bị che bởi thanh tab
        layout.setContentsMargins(6, 12, 0, 6)
        layout.setSpacing(4)

        # Bộ lọc chung (xếp 2 hàng cố định để không bị che; không dùng scrollbar)
        filter_grid = QGridLayout()
        filter_grid.setContentsMargins(0, 0, 0, 0)
        filter_grid.setHorizontalSpacing(8)
        def make_label(text: str) -> QLabel:
            lbl = QLabel(text)
            lbl.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            return lbl

        # Bộ lọc chung: một hàng, có thanh cuộn ngang khi hẹp
        filter_row = QHBoxLayout()
        filter_row.setContentsMargins(0, 0, 0, 0)
        filter_row.setSpacing(8)

        self.stats_template = QComboBox()
        self.stats_template.setToolTip("Chọn mẫu dữ liệu để thống kê")
        self._refresh_stats_template_combo()
        def _on_stats_tpl_changed():
            idx = self.stats_template.currentIndex()
            self.saved_stats_template = self.stats_template.currentText() if idx > 0 else None
            self._refresh_stats()
        self.stats_template.currentIndexChanged.connect(lambda _: _on_stats_tpl_changed())
        if self.saved_stats_template:
            idx_saved = self.stats_template.findText(self.saved_stats_template)
            if idx_saved >= 0:
                self.stats_template.setCurrentIndex(idx_saved)

        self.stats_pos_input = QComboBox()
        self.stats_pos_input.setEditable(True)
        self.stats_pos_input.setInsertPolicy(QComboBox.NoInsert)
        self.stats_pos_input.lineEdit().setPlaceholderText("Tất cả")
        self._wire_stats_lineedit(self.stats_pos_input)
        self.stats_pos_input.currentIndexChanged.connect(lambda _: self._refresh_stats())

        self.stats_nm_input = QComboBox()
        self.stats_nm_input.setEditable(True)
        self.stats_nm_input.setInsertPolicy(QComboBox.NoInsert)
        self.stats_nm_input.setFixedWidth(100)
        self.stats_nm_input.lineEdit().setPlaceholderText("Tất cả")
        self._wire_stats_lineedit(self.stats_nm_input)
        self.stats_nm_input.currentIndexChanged.connect(lambda _: self._refresh_stats())

        self.stats_lo_input = QComboBox()
        self.stats_lo_input.setEditable(True)
        self.stats_lo_input.setInsertPolicy(QComboBox.NoInsert)
        self.stats_lo_input.setFixedWidth(100)
        self.stats_lo_input.lineEdit().setPlaceholderText("Tất cả")
        self._wire_stats_lineedit(self.stats_lo_input)
        self.stats_lo_input.currentIndexChanged.connect(lambda _: self._refresh_stats())

        self.stats_state_input = QComboBox()
        self.stats_state_input.setEditable(True)
        self.stats_state_input.setInsertPolicy(QComboBox.NoInsert)
        self.stats_state_input.lineEdit().setPlaceholderText("Tất cả")
        self._wire_stats_lineedit(self.stats_state_input)
        self.stats_state_input.currentIndexChanged.connect(lambda _: self._refresh_stats())

        def build_num_filter():
            op = QComboBox()
            op.addItems(["=", ">", "<", "≥", "≤", "Giữa"])
            v1 = QComboBox()
            v1.setEditable(True)
            v1.setInsertPolicy(QComboBox.NoInsert)
            v1.lineEdit().setPlaceholderText("Giá trị")
            v2 = QComboBox()
            v2.setEditable(True)
            v2.setInsertPolicy(QComboBox.NoInsert)
            v2.lineEdit().setPlaceholderText("Giá trị 2")
            def toggle_v2():
                between = op.currentText() == "Giữa"
                v2.setVisible(between)
                v2.setEnabled(between)
                self._refresh_stats()
            op.currentIndexChanged.connect(lambda _: toggle_v2())
            v1.currentIndexChanged.connect(lambda _: self._refresh_stats())
            v2.currentIndexChanged.connect(lambda _: self._refresh_stats())
            self._wire_stats_lineedit(v1)
            self._wire_stats_lineedit(v2)
            toggle_v2()
            return op, v1, v2

        self.stats_tkc_op, self.stats_tkc_v1, self.stats_tkc_v2 = build_num_filter()
        self.stats_tkkm_op, self.stats_tkkm_v1, self.stats_tkkm_v2 = build_num_filter()

        self.stats_tk_threshold_input = QLineEdit(str(self.stats_tk_threshold))
        self.stats_tk_threshold_input.setFixedWidth(50)
        self.stats_tk_threshold_input.setAlignment(Qt.AlignCenter)
        def _update_tk_threshold():
            text = self.stats_tk_threshold_input.text().strip()
            try:
                val = int(float(text))
            except Exception:
                val = self.stats_tk_threshold or 250
            if val <= 0:
                val = 250
            self.stats_tk_threshold = val
            self.stats_tk_threshold_input.setText(str(val))
            self._refresh_stats_headers()
            self._refresh_stats()
        self.stats_tk_threshold_input.editingFinished.connect(_update_tk_threshold)

        self.btn_stats_export = QPushButton("Xuất Excel")
        self.btn_stats_export.setFixedHeight(28)
        self.btn_stats_export.setCursor(Qt.PointingHandCursor)
        self.btn_stats_export.setToolTip("Xuất danh sách dòng dữ liệu theo các bộ lọc thống kê hiện tại")
        self._style_action_button(self.btn_stats_export, "#10b981", "#059669")
        self.btn_stats_export.clicked.connect(self._export_stats_filtered)

        # xếp tất cả vào một hàng
        filter_row.addWidget(make_label("Mẫu:"))
        filter_row.addWidget(self.stats_template)
        filter_row.addWidget(make_label("Vị trí:"))
        filter_row.addWidget(self.stats_pos_input)
        filter_row.addWidget(make_label("Nhà mạng:"))
        filter_row.addWidget(self.stats_nm_input)
        filter_row.addWidget(make_label("Lô sim:"))
        filter_row.addWidget(self.stats_lo_input)
        filter_row.addWidget(make_label("Trạng thái:"))
        filter_row.addWidget(self.stats_state_input)
        filter_row.addWidget(make_label("TKC:"))
        filter_row.addWidget(self.stats_tkc_op)
        filter_row.addWidget(self.stats_tkc_v1)
        filter_row.addWidget(self.stats_tkc_v2)
        filter_row.addWidget(make_label("TKKM:"))
        filter_row.addWidget(self.stats_tkkm_op)
        filter_row.addWidget(self.stats_tkkm_v1)
        filter_row.addWidget(self.stats_tkkm_v2)
        # nhóm ngưỡng + export
        filter_row.addWidget(make_label("Ngưỡng TK:"))
        filter_row.addWidget(self.stats_tk_threshold_input)
        filter_row.addWidget(self.btn_stats_export)
        filter_row.addStretch()

        filter_row_widget = QWidget()
        filter_row_widget.setLayout(filter_row)
        filter_row_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        filter_scroll = QScrollArea()
        filter_scroll.setWidgetResizable(True)
        filter_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        filter_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        filter_scroll.setFrameShape(QFrame.NoFrame)
        filter_scroll.setContentsMargins(0, 0, 0, 0)
        filter_scroll.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        filter_scroll.setWidget(filter_row_widget)
        hbar = filter_scroll.horizontalScrollBar()
        h_hint = hbar.sizeHint().height() if hbar.sizeHint().isValid() else 12
        filter_scroll.setFixedHeight(filter_row_widget.sizeHint().height() + h_hint + 6)

        bar_wrap = QHBoxLayout()
        bar_wrap.setContentsMargins(0, 0, 0, 0)
        bar_wrap.setSpacing(0)
        bar_wrap.addWidget(filter_scroll)
        layout.addLayout(bar_wrap)
        layout.addSpacing(10)

        # Chi tiết lọc nâng cao
        detail_layout = QFormLayout()
        detail_layout.setLabelAlignment(Qt.AlignLeft)
        detail_layout.setFormAlignment(Qt.AlignLeft)
        detail_layout.setHorizontalSpacing(6)
        detail_layout.setVerticalSpacing(2)

        def build_date_filter(tag: str):
            row = QHBoxLayout()
            month_cb = QComboBox()
            month_cb.addItems(
                [
                    "Tất cả",
                    "Hôm nay",
                    "Hôm qua",
                    "Ngày mai",
                    "Tuần này",
                    "Tuần sau",
                    "Tuần trước",
                    "30 ngày gần đây",
                    "Tháng này",
                ]
                + [f"Tháng {m:02d}" for m in range(1, 13)]
            )
            de_from = StatsDateEdit()
            de_to = StatsDateEdit()
            for de in (de_from, de_to):
                de.dateChanged.connect(lambda _: self._refresh_stats())
            def apply_month_choice():
                text = month_cb.currentText()
                today = QDate.currentDate()
                min_dt = QDate(1900, 1, 1)
                if text == "Tất cả":
                    de_from.setDate(min_dt)
                    de_to.setDate(min_dt)
                elif text == "Hôm nay":
                    de_from.setDate(today)
                    de_to.setDate(today)
                elif text == "Hôm qua":
                    day = today.addDays(-1)
                    de_from.setDate(day)
                    de_to.setDate(day)
                elif text == "Ngày mai":
                    day = today.addDays(1)
                    de_from.setDate(day)
                    de_to.setDate(day)
                elif text == "Tuần này":
                    start = today.addDays(-(today.dayOfWeek() - 1))
                    end = start.addDays(6)
                    de_from.setDate(start)
                    de_to.setDate(end)
                elif text == "Tuần sau":
                    start = today.addDays(7 - (today.dayOfWeek() - 1))
                    end = start.addDays(6)
                    de_from.setDate(start)
                    de_to.setDate(end)
                elif text == "Tuần trước":
                    start = today.addDays(-7 - (today.dayOfWeek() - 1))
                    end = start.addDays(6)
                    de_from.setDate(start)
                    de_to.setDate(end)
                elif text == "30 ngày gần đây":
                    start = today.addDays(-29)
                    de_from.setDate(start)
                    de_to.setDate(today)
                else:
                    if text == "Tháng này":
                        month = today.month()
                        year = today.year()
                    else:
                        try:
                            month = int(text.split()[1])
                            year = today.year()
                        except Exception:
                            month = today.month()
                            year = today.year()
                    start_dt = QDate(year, month, 1)
                    end_dt = start_dt.addMonths(1).addDays(-1)
                    de_from.setDate(start_dt)
                    de_to.setDate(end_dt)
                self._refresh_stats()
            month_cb.currentIndexChanged.connect(lambda _: apply_month_choice())
            row.addWidget(month_cb)
            row.addWidget(QLabel("Từ"))
            row.addWidget(de_from)
            row.addWidget(QLabel("Đến"))
            row.addWidget(de_to)
            row.addStretch()
            return month_cb, de_from, de_to, row

        self.stats_hsd_month, self.stats_hsd_from, self.stats_hsd_to, hsd_row = build_date_filter("hsd")
        self.stats_nhap_month, self.stats_nhap_from, self.stats_nhap_to, nhap_row = build_date_filter("nhap")
        self.stats_psc_month, self.stats_psc_from, self.stats_psc_to, psc_row = build_date_filter("psc")
        dates_row = QHBoxLayout()
        dates_row.setContentsMargins(0, 4, 0, 4)
        dates_row.setSpacing(8)
        dates_row.addWidget(QLabel("HSD:"))
        dates_row.addLayout(hsd_row)
        dates_row.addSpacing(12)
        dates_row.addWidget(QLabel("Ngày nhập:"))
        dates_row.addLayout(nhap_row)
        dates_row.addSpacing(12)
        dates_row.addWidget(QLabel("Ngày PSC:"))
        dates_row.addLayout(psc_row)
        dates_row.addStretch()
        detail_layout.addRow(dates_row)
        # mặc định HSD = Tất cả (bảng thống kê không lọc HSD)
        self.stats_hsd_month.setCurrentText("Tất cả")

        detail_widget = QWidget()
        detail_widget.setLayout(detail_layout)
        detail_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        layout.addWidget(detail_widget)

        self._refresh_stats_headers()
        self.stats_nm_table.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.stats_nm_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.stats_nm_table.installEventFilter(self)
        self.stats_nm_table.setMouseTracking(True)
        self.stats_nm_table.entered.connect(self._on_stats_cell_entered)
        self.stats_nm_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.stats_nm_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        hh = self.stats_nm_table.horizontalHeader()
        hh.setDefaultAlignment(Qt.AlignCenter)
        hh.setStretchLastSection(False)
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.sectionResized.connect(lambda idx, _, __: self._remember_stats_nm_widths())
        # Cho phép thu/phóng cột và cuộn ngang khi thu nhỏ
        self.stats_nm_table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        # nếu đã có width lưu sẵn thì bỏ autosize ban đầu
        self._stats_nm_autosized = bool(self.stats_nm_widths)
        stats_block = QVBoxLayout()
        stats_block.setContentsMargins(0, 4, 0, 0)
        stats_block.setSpacing(2)
        stats_block.addWidget(self.stats_nm_table)
        # Bộ lọc riêng cho biểu đồ HSD
        chart_filter_row = QHBoxLayout()
        chart_filter_row.setContentsMargins(4, 0, 4, 0)
        chart_filter_row.setSpacing(8)
        self.chart_hsd_month = QComboBox()
        self.chart_hsd_month.addItems(
            [
                "Tất cả",
                "Hôm nay",
                "Hôm qua",
                "Ngày mai",
                "Tuần này",
                "Tuần sau",
                "Tuần trước",
                "30 ngày gần đây",
                "Tháng này",
            ]
            + [f"Tháng {m:02d}" for m in range(1, 13)]
        )
        self.chart_hsd_from = StatsDateEdit()
        self.chart_hsd_to = StatsDateEdit()
        self.chart_hsd_nm = QComboBox()
        self.chart_hsd_nm.setEditable(True)
        self.chart_hsd_nm.setInsertPolicy(QComboBox.NoInsert)
        self.chart_hsd_nm.setFixedWidth(140)
        self.chart_hsd_nm.lineEdit().setPlaceholderText("Tất cả")
        self._wire_stats_lineedit(self.chart_hsd_nm)
        def _apply_chart_month():
            text = self.chart_hsd_month.currentText()
            today = QDate.currentDate()
            min_dt = QDate(1900, 1, 1)
            if text == "Tất cả":
                self.chart_hsd_from.setDate(min_dt)
                self.chart_hsd_to.setDate(min_dt)
            elif text == "Hôm nay":
                self.chart_hsd_from.setDate(today)
                self.chart_hsd_to.setDate(today)
            elif text == "Hôm qua":
                day = today.addDays(-1)
                self.chart_hsd_from.setDate(day)
                self.chart_hsd_to.setDate(day)
            elif text == "Ngày mai":
                day = today.addDays(1)
                self.chart_hsd_from.setDate(day)
                self.chart_hsd_to.setDate(day)
            elif text == "Tuần này":
                start = today.addDays(-(today.dayOfWeek() - 1))
                end = start.addDays(6)
                self.chart_hsd_from.setDate(start)
                self.chart_hsd_to.setDate(end)
            elif text == "Tuần sau":
                start = today.addDays(7 - (today.dayOfWeek() - 1))
                end = start.addDays(6)
                self.chart_hsd_from.setDate(start)
                self.chart_hsd_to.setDate(end)
            elif text == "Tuần trước":
                start = today.addDays(-7 - (today.dayOfWeek() - 1))
                end = start.addDays(6)
                self.chart_hsd_from.setDate(start)
                self.chart_hsd_to.setDate(end)
            elif text == "30 ngày gần đây":
                start = today.addDays(-29)
                self.chart_hsd_from.setDate(start)
                self.chart_hsd_to.setDate(today)
            else:
                if text == "Tháng này":
                    month = today.month()
                    year = today.year()
                else:
                    try:
                        month = int(text.split()[1])
                        year = today.year()
                    except Exception:
                        month = today.month()
                        year = today.year()
                start_dt = QDate(year, month, 1)
                end_dt = start_dt.addMonths(1).addDays(-1)
                self.chart_hsd_from.setDate(start_dt)
                self.chart_hsd_to.setDate(end_dt)
            self._refresh_hsd_chart_cached()
        self.chart_hsd_month.currentIndexChanged.connect(lambda _: _apply_chart_month())
        self.chart_hsd_from.dateChanged.connect(lambda _: self._refresh_hsd_chart_cached())
        self.chart_hsd_to.dateChanged.connect(lambda _: self._refresh_hsd_chart_cached())
        self.chart_hsd_nm.currentIndexChanged.connect(lambda _: self._refresh_hsd_chart_cached())
        self.chart_hsd_month.setCurrentText("Tháng này")
        _apply_chart_month()
        chart_filter_row.addWidget(QLabel("Biểu đồ HSD:"))
        chart_filter_row.addWidget(self.chart_hsd_month)
        chart_filter_row.addWidget(QLabel("Từ"))
        chart_filter_row.addWidget(self.chart_hsd_from)
        chart_filter_row.addWidget(QLabel("Đến"))
        chart_filter_row.addWidget(self.chart_hsd_to)
        chart_filter_row.addWidget(QLabel("Nhà mạng:"))
        chart_filter_row.addWidget(self.chart_hsd_nm)
        # Nút bật/tắt biểu đồ để tránh lag khi không cần xem
        self.hsd_chart_enabled = getattr(self, "hsd_chart_enabled", True)
        self.chart_hsd_toggle_btn = QPushButton("Tắt biểu đồ")
        self.chart_hsd_toggle_btn.setCheckable(True)
        self.chart_hsd_toggle_btn.setStyleSheet(
            "QPushButton { background:#1e2230; color:#f5f7fb; border:1px solid #3a425a; padding:4px 10px; border-radius:4px; }"
            "QPushButton:hover { background:#2b3144; }"
        )
        self.chart_hsd_toggle_btn.clicked.connect(self._toggle_hsd_chart)
        chart_filter_row.addWidget(self.chart_hsd_toggle_btn)
        chart_filter_row.addStretch()
        chart_filter_widget = QWidget()
        chart_filter_widget.setLayout(chart_filter_row)
        stats_block.addWidget(chart_filter_widget)

        # Biểu đồ HSD theo ngày
        self.hsd_chart_view = QChartView()
        self.hsd_chart_view.setRenderHint(QPainter.Antialiasing)
        self.hsd_chart_view.setMinimumHeight(260)
        self.hsd_chart_view.setMouseTracking(True)
        self.hsd_chart_view.viewport().setMouseTracking(True)
        self.hsd_chart_view.viewport().installEventFilter(self)
        # Tooltip tùy chỉnh (giữ khi rê, chỉ đổi khi rê tiếp)
        self.hsd_tip = QLabel("", self.hsd_chart_view)
        self.hsd_tip.setWindowFlags(Qt.ToolTip)
        self.hsd_tip.setStyleSheet(
            "QLabel { background: #111827; color: #e5e7eb; border: 1px solid #374151; padding: 4px 6px; }"
        )
        self.hsd_tip.hide()
        stats_block.addWidget(self.hsd_chart_view, 1)
        # áp trạng thái bật/tắt biểu đồ theo state đã lưu
        self._apply_hsd_chart_state(apply_refresh=False)
        layout.addLayout(stats_block, 1)

        # Bọc nội dung trong scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(content)
        main_layout.addWidget(scroll)

        return page

    def _refresh_stats_headers(self) -> None:
        # Header 2 dòng: "Tháng m" trên, "<... / >..." dưới (mỗi cột vẫn riêng, không gộp)
        current_m = QDate.currentDate().month()
        month_order = list(range(current_m, 13)) + list(range(1, current_m))
        threshold = self.stats_tk_threshold or 250
        stats_headers = ["Nhà mạng", "Tổng", "Bình thường", "Nguyên kit", "Khóa", "Chặn", "Chặn 2 chiều"]
        for m in month_order:
            stats_headers.append(f"Tháng {m}\n< {threshold}")
            stats_headers.append(f"Tháng {m}\n> {threshold}")
        stats_headers += [f"Tổng\n< {threshold}", f"Tổng\n> {threshold}"]
        self.stats_month_order = [m - 1 for m in month_order]  # 0-based
        if not hasattr(self, "stats_nm_table"):
            self.stats_nm_table = QTableWidget(0, len(stats_headers))
        self.stats_nm_table.setColumnCount(len(stats_headers))
        self.stats_nm_table.setHorizontalHeaderLabels(stats_headers)
        # header 2 dòng custom
        if not hasattr(self, "_stats_header"):
            self._stats_header = StatsHeader(self.stats_nm_table)
            self.stats_nm_table.setHorizontalHeader(self._stats_header)
        else:
            self.stats_nm_table.setHorizontalHeader(self._stats_header)
        hh = self.stats_nm_table.horizontalHeader()
        hh.setDefaultAlignment(Qt.AlignCenter)
        hh.setSectionResizeMode(QHeaderView.Interactive)
        hh.setStretchLastSection(False)
        self.stats_nm_table.horizontalHeader().update()

    def _apply_stats_nm_widths(self) -> None:
        if not hasattr(self, "stats_nm_table") or not self.stats_nm_widths:
            return
        try:
            for k, v in self.stats_nm_widths.items():
                c = int(k)
                if 0 <= c < self.stats_nm_table.columnCount() and v > 0:
                    self.stats_nm_table.setColumnWidth(c, v)
        except Exception:
            pass

    def _remember_stats_nm_widths(self) -> None:
        if not hasattr(self, "stats_nm_table"):
            return
        try:
            widths = {}
            for c in range(self.stats_nm_table.columnCount()):
                widths[str(c)] = self.stats_nm_table.columnWidth(c)
            self.stats_nm_widths = widths
            self._save_state()
        except Exception:
            pass

    def _set_model(self, headers: List[str], rows: List[List[Any]], auto_resize: bool = False) -> None:
        self._ensure_change_column()
        self._ensure_row_histories()
        model = InventoryModel(
            headers,
            rows,
            self.alignment_map,
            self.column_formats,
            self.cell_styles,
            on_edit=self._on_cell_edited,
            alert_highlighter=lambda r, c, v: self._alert_color(r, c, v),
            parent=self,
            include_index=self.show_index_column,
        )
        # Cho model biết cách map view row -> rows_all index để lấy style chuẩn
        model._row_index_from_view = self._row_index_from_view
        self.table.setModel(model)
        # Custom delegate paints BackgroundRole explicitly (some stylesheets can override it)
        self.table.setItemDelegate(InventoryItemDelegate(self.table))
        # bỏ event filter/ delegate cho chức năng chèn địa chỉ công thức
        self.table.verticalHeader().setModel(model)
        self.row_header.bind_selection_model()
        vh = self.table.verticalHeader()
        vh.setSectionResizeMode(QHeaderView.Fixed)
        vh.setMinimumSectionSize(max(16, self.row_height))
        vh.setDefaultSectionSize(self.row_height)
        self._enforce_row_height(self.row_height)
        for col in range(model.columnCount()):
            if auto_resize:
                continue
            width = self.saved_column_widths.get(str(col), 140)
            self.table.setColumnWidth(col, width)
        self._apply_hidden_columns()
        # auto fit width (khi được yêu cầu hoặc chưa có width lưu)
        if auto_resize or not self.saved_column_widths:
            self._auto_resize_columns()
        # tooltip header hiển thị nội dung gốc/đã tách
        for col in range(model.columnCount()):
            actual = self._view_to_data_column(col)
            tooltip = "STT" if actual is None else (self.headers[actual] if 0 <= actual < len(self.headers) else "")
            self.table.model().setHeaderData(col, Qt.Horizontal, tooltip, Qt.ToolTipRole)
        self._build_filter_row()
        self._sync_filter_widths()
        QTimer.singleShot(0, self._sync_filter_widths)
        self._update_corner_label()
        self._update_row_header_width()
        self._bind_selection_changed()
        self._refresh_template_combo()
        self._update_status_bar()
        if self._last_state_snapshot is None:
            self._last_state_snapshot = self._create_state_snapshot()

    def _is_index_column(self, col: int) -> bool:
        return self.show_index_column and col == 0

    def _view_to_data_column(self, col: int) -> Optional[int]:
        if not self.show_index_column:
            return col
        if col == 0:
            return None
        return col - 1

    def _view_columns_to_data(self, columns: set[int]) -> set[int]:
        result: set[int] = set()
        for col in columns:
            actual = self._view_to_data_column(col)
            if actual is not None:
                result.add(actual)
        return result

    def _display_headers(self) -> List[str]:
        if not self.show_index_column:
            return self.headers
        return ["STT"] + self.headers

    def _selected_row_count(self) -> int:
        sel = self.table.selectionModel() if hasattr(self, "table") else None
        if not sel:
            return 0
        rows = {idx.row() for idx in sel.selectedIndexes()}
        return len(rows)

    def _update_status_bar(self) -> None:
        if not hasattr(self, "status_bar"):
            return
        total = self.table.model().rowCount() if self.table.model() else len(self.rows)
        selected = self._selected_row_count()
        sel_cells, non_empty, sum_val = self._selection_stats()
        sum_txt = ""
        if sel_cells > 0 and math.isfinite(sum_val):
            sum_display = self._format_sum_value(sum_val)
            sum_txt = f" | Tổng giá trị: {sum_display}"
        width_txt = ""
        if self._last_width_info:
            col_name, px = self._last_width_info
            label = col_name or "Cột"
            width_txt = f" | {label}: {px}px"
        self.status_bar.setText(
            f"Tổng: {total} | Dòng: {selected} | Không trống: {non_empty}/{sel_cells}{sum_txt}{width_txt}"
        )
        # đảm bảo status bar nằm đúng vị trí khi layout thay đổi
        self._attach_status_bar(compact=not getattr(self, "letter_toggle", None) or not self.letter_toggle.isChecked())

    def _selection_stats(self) -> tuple[int, int, float]:
        """Trả về (số ô chọn, ô không trống, tổng số các ô số)."""
        sel = self.table.selectionModel() if hasattr(self, "table") else None
        model = self.table.model() if hasattr(self, "table") else None
        if not sel or not model:
            return 0, 0, 0.0
        indexes = sel.selectedIndexes()
        if not indexes:
            return 0, 0, 0.0
        total_cells = len(indexes)
        non_empty = 0
        sum_val = 0.0
        for idx in indexes:
            actual_col = self._view_to_data_column(idx.column())
            if actual_col is None:
                continue
            val = ""
            if idx.row() < len(self.rows) and actual_col < len(self.rows[idx.row()]):
                val = self.rows[idx.row()][actual_col]
            text = "" if pd.isna(val) else str(val)
            if text.strip():
                non_empty += 1
            fmt = self.column_formats.get(str(actual_col), "")
            if fmt == "Số điện thoại":
                continue
            num = self._parse_number(text)
            if num is None or not math.isfinite(num):
                continue
            sum_val += num
        return total_cells, non_empty, sum_val

    def _format_sum_value(self, value: float) -> str:
        if abs(value - int(value)) < 1e-9:
            return f"{int(value):,}"
        s = f"{value:,.3f}"
        s = s.rstrip("0").rstrip(".")
        return s

    def _parse_number(self, text: str) -> Optional[float]:
        clean = text.replace(" ", "").replace(",", "")
        # bỏ dấu chấm ngăn cách nghìn nếu có, nhưng giữ dấu chấm thập phân cuối cùng
        # nếu có nhiều dấu chấm, coi mọi dấu chấm là phân cách nghìn trừ dấu chấm cuối
        parts = clean.split(".")
        if len(parts) > 2:
            dec = parts[-1]
            int_part = "".join(parts[:-1])
            clean = int_part + "." + dec
        try:
            return float(clean)
        except Exception:
            return None

    def _attach_status_bar(self, compact: bool) -> None:
        # compatibility shim
        self._reparent_status_bar(compact)

    def _reparent_status_bar(self, compact: bool) -> None:
        """Khi compact, đưa status bar lên cùng hàng nút; khi không, đặt ở dòng riêng."""
        if not hasattr(self, "status_bar") or not hasattr(self, "letter_wrap") or not hasattr(self, "main_layout"):
            return
        lw_layout = self.letter_wrap.layout()
        if not lw_layout:
            return
        # remove from both layouts first
        lw_layout.removeWidget(self.status_bar)
        self.main_layout.removeWidget(self.status_bar)
        if compact:
            if lw_layout.indexOf(self.status_bar) == -1:
                lw_layout.addWidget(self.status_bar, 1)
            self.letter_wrap.setFixedHeight(20)
        else:
            idx = self.main_layout.indexOf(self.letter_wrap)
            if idx == -1:
                self.main_layout.addWidget(self.status_bar)
            else:
                self.main_layout.insertWidget(idx + 1, self.status_bar)
            self.letter_wrap.setFixedHeight(20)
        self.status_bar.setVisible(True)

    def _hide_qt_status_bar(self) -> None:
        # Ẩn status bar mặc định của QMainWindow (dòng px)
        try:
            sb = self.statusBar()
            if sb:
                sb.hide()
                sb.setSizeGripEnabled(False)
                sb.setStyleSheet("border: none; padding: 0; margin: 0; min-height: 0; max-height: 0;")
        except Exception:
            pass

    def _show_error_popup(self, title: str, detail: str) -> None:
        msg = QMessageBox(self)
        msg.setWindowTitle(title)
        msg.setIcon(QMessageBox.Critical)
        msg.setText("Đã xảy ra lỗi. Vui lòng copy thông tin và gửi cho dev.")
        msg.setDetailedText(detail)
        btn_copy = msg.addButton("Copy", QMessageBox.ActionRole)
        msg.addButton(QMessageBox.Close)
        msg.exec()
        if msg.clickedButton() == btn_copy:
            QGuiApplication.clipboard().setText(detail)

    def _update_corner_label(self) -> None:
        if self.table.model():
            count = self.table.model().rowCount()
            self.corner_label.setText(f"Tổng: {count}")
        else:
            self.corner_label.setText("Tổng: 0")
        self._update_status_bar()

    def _on_column_resized(self, logical: int, old: int, new: int) -> None:
        self.saved_column_widths[str(logical)] = new
        try:
            header_text = str(self.table.model().headerData(logical, Qt.Horizontal, Qt.DisplayRole) or "")
        except Exception:
            header_text = ""
        count = self.table.model().rowCount() if self.table.model() else 0
        base = f"Tổng: {count}"
        extra = f" | {header_text}: {new}px" if header_text else f" | {new}px"
        self.corner_label.setText(base + extra)
        self._last_width_info = (header_text, new)
        self._update_status_bar()

    def _update_row_header_width(self) -> None:
        vh = self.table.verticalHeader()
        if vh is None:
            return
        row_count = self.table.model().rowCount() if self.table.model() else len(self.rows)
        digits = len(str(max(row_count, 1)))
        fm = QFontMetrics(vh.font())
        width = fm.horizontalAdvance("9" * digits) + 16
        width = max(width, 28)
        vh.setFixedWidth(width)
        self._update_status_bar()

    def _hide_columns(self, columns: set[int]) -> None:
        data_cols = self._view_columns_to_data(columns)
        for c in data_cols:
            if 0 <= c < len(self.headers):
                self.hidden_columns.add(c)
        self._apply_hidden_columns()
        self._persist_now()

    def _apply_hidden_columns(self) -> None:
        self._cleanup_hidden_columns()
        model = self.table.model()
        if not model:
            return
        for data_col in range(len(self.headers)):
            view_col = data_col + (1 if self.show_index_column else 0)
            hide = data_col in self.hidden_columns
            self.table.setColumnHidden(view_col, hide)
        self._sync_filter_widths()

    def _cleanup_hidden_columns(self) -> None:
        self.hidden_columns = {c for c in self.hidden_columns if 0 <= c < len(self.headers)}

    def _show_hidden_columns_dialog(self) -> None:
        self._cleanup_hidden_columns()
        dialog = QDialog(self)
        dialog.setWindowTitle("Hiển thị/Ẩn cột")
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget()
        for idx, name in enumerate(self.headers):
            item = QListWidgetItem(name or f"Cột {idx+1}")
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            checked = Qt.Unchecked if idx in self.hidden_columns else Qt.Checked
            item.setCheckState(checked)
            list_widget.addItem(item)
        layout.addWidget(list_widget)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() == QDialog.Accepted:
            new_hidden = set()
            for i in range(list_widget.count()):
                item = list_widget.item(i)
                if item.checkState() == Qt.Unchecked:
                    new_hidden.add(i)
            self.hidden_columns = new_hidden
            self._apply_hidden_columns()
            self._persist_now()

    def _enforce_row_height(self, height: int) -> None:
        model = self.table.model()
        if not model:
            return
        for r in range(model.rowCount()):
            self.table.setRowHeight(r, height)

    def _reset_history_countdown(self, base: Optional[datetime] = None) -> None:
        interval_ms = self.history_timer.interval()
        if interval_ms <= 0:
            return
        now = base if base else datetime.now()
        self._history_next_due = now + timedelta(milliseconds=interval_ms)
        self._update_history_countdown()

    def _update_history_countdown(self) -> None:
        if not self._history_next_due:
            return
        remaining = self._history_next_due - datetime.now()
        total_seconds = max(0, int(remaining.total_seconds()))
        minutes, seconds = divmod(total_seconds, 60)
        text = f"{minutes:02d}:{seconds:02d}"
        label = getattr(self, "history_countdown_label", None)
        if label is not None:
            label.setText(text)

    def _schedule_state_save(self) -> None:
        if getattr(self, "_state_save_timer", None) is None:
            return
        self._state_save_timer.start(400)

    def _on_header_height_changed(self, height: int) -> None:
        if height <= 0:
            return
        self.saved_header_height = int(height)
        self._schedule_state_save()

    def _refresh_template_combo(self) -> None:
        if not hasattr(self, "template_combo"):
            return
        self.template_combo.blockSignals(True)
        self.template_combo.clear()
        self.template_combo.addItem("Không dùng mẫu")
        for tpl in self.templates:
            name = str(tpl.get("name", "")).strip()
            if name:
                self.template_combo.addItem(name)
        if self.active_template:
            idx = self.template_combo.findText(self.active_template)
            if idx >= 0:
                self.template_combo.setCurrentIndex(idx)
            else:
                self.active_template = None
                self.template_combo.setCurrentIndex(0)
        else:
            self.template_combo.setCurrentIndex(0)
        self.template_combo.blockSignals(False)
        self._refresh_stats_template_combo()

    def _refresh_stats_template_combo(self) -> None:
        if not hasattr(self, "stats_template"):
            return
        current = self.stats_template.currentText() if self.stats_template.count() else "Chưa chọn"
        if (not current or current == "Chưa chọn") and self.saved_stats_template:
            current = self.saved_stats_template
        self.stats_template.blockSignals(True)
        self.stats_template.clear()
        self.stats_template.addItem("Chưa chọn")
        for tpl in self.templates:
            name = str(tpl.get("name", "")).strip()
            if name:
                self.stats_template.addItem(name)
        idx = self.stats_template.findText(current)
        self.stats_template.setCurrentIndex(idx if idx >= 0 else 0)
        self.stats_template.blockSignals(False)

    def _wire_stats_lineedit(self, combo: QComboBox) -> None:
        """Cho phép lọc khi nhấn Enter/dblclick; không auto khi đang gõ."""
        if combo is None or not combo.isEditable():
            return
        le = combo.lineEdit()
        if not le:
            return
        # bật nút clear (dấu x) để xóa nhanh giá trị lọc
        le.setClearButtonEnabled(True)
        # đảm bảo không nhiều lần connect
        try:
            le.returnPressed.disconnect()
        except Exception:
            pass
        try:
            le.editingFinished.disconnect()
        except Exception:
            pass
        le.returnPressed.connect(self._refresh_stats)
        le.editingFinished.connect(self._refresh_stats)
        # Nếu người dùng bấm nút x để xóa hết thì tự refresh ngay
        def _refresh_on_clear(text: str) -> None:
            if text == "":
                self._refresh_stats()
        le.textChanged.connect(_refresh_on_clear)
        le.installEventFilter(self)
        self._stats_lineedits.add(le)

    def _show_template_menu(self, pos) -> None:
        idx = self.template_combo.view().indexAt(pos)
        row = idx.row() if idx.isValid() else -1
        if row <= 0:
            return
        name = self.template_combo.itemText(row).strip()
        if not name:
            return
        menu = QMenu(self)
        act_delete = menu.addAction("Xóa")
        action = menu.exec(self.template_combo.view().mapToGlobal(pos))
        if action == act_delete:
            self._delete_template(name)

    def eventFilter(self, obj, event):
        # Cho phép click phải trên menu mẫu cảnh báo để xóa nhanh mẫu đang hover
        try:
            tpl_menu = getattr(self, "_alert_tpl_menu", None)
            if obj is tpl_menu and event.type() in (QEvent.ContextMenu, QEvent.MouseButtonPress):
                if event.type() == QEvent.MouseButtonPress and getattr(event, "button", lambda: None)() != Qt.RightButton:
                    return False
                action = tpl_menu.actionAt(event.pos())
                if action and action.data():
                    name = str(action.data())
                    confirm = QMessageBox.question(
                        tpl_menu,
                        "Xóa mẫu cảnh báo",
                        f"Xóa mẫu '{name}'?",
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.No,
                    )
                    if confirm == QMessageBox.Yes:
                        self._delete_template(name)
                    return True
        except Exception:
            pass
        return super().eventFilter(obj, event)

    def _build_letter_row(self) -> None:
        for lbl in self.filter_letter_labels:
            lbl.deleteLater()
        self.filter_letter_labels = []
        for idx in range(len(self._display_headers())):
            letter_label = QLabel(col_letter(idx), self.letter_bar)
            letter_label.setAlignment(Qt.AlignCenter)
            letter_label.setFixedHeight(16)
            letter_label.setStyleSheet("color: #9ba0b5; font-weight: normal;")
            letter_label.show()
            self.filter_letter_labels.append(letter_label)

    def _toggle_letter_bar(self, checked: bool) -> None:
        show = checked
        self.letter_bar.setVisible(show)
        if show:
            self.letter_bar.setMaximumHeight(16)
            self.letter_bar.setMinimumHeight(16)
            self.letter_toggle.setText("▾")
        else:
            self.letter_bar.setMaximumHeight(0)
            self.letter_bar.setMinimumHeight(0)
            self.letter_toggle.setText("▸")
        self.letter_visible_pref = show
        self._save_state()
        self._reparent_status_bar(compact=not show)
        self._sync_letter_labels()
        self._update_status_bar()

    def _sync_letter_labels(self) -> None:
        if not self.filter_letter_labels or not self.letter_bar.isVisible():
            return
        header = self.table.horizontalHeader()
        vh_width = self.table.verticalHeader().width()
        frame = self.table.frameWidth()
        offset = vh_width + frame
        total_width = offset
        for idx, label in enumerate(self.filter_letter_labels):
            try:
                w = header.sectionSize(idx)
                x = header.sectionViewportPosition(idx)
            except Exception:
                w = 100
                x = 0
            label.setFixedWidth(w)
            label.move(offset + x, 0)
            total_width = max(total_width, offset + x + w)
        # không đẩy min width của cửa sổ
        self.letter_bar.setMinimumWidth(0)

    def _bind_selection_changed(self) -> None:
        sm = self.table.selectionModel()
        if sm is None or sm is self._selection_model:
            return
        if self._selection_model:
            try:
                self._selection_model.selectionChanged.disconnect(self._on_table_selection_changed)
            except Exception:
                pass
        self._selection_model = sm
        self._selection_model.selectionChanged.connect(self._on_table_selection_changed)
        self._on_table_selection_changed()

    def _on_table_selection_changed(self, selected=None, deselected=None) -> None:
        self._update_filter_letter_styles()
        self._update_status_bar()

    def _activate_history(self) -> None:
        if self.history_enabled:
            return
        self.history_enabled = True
        self.history_timer.start()
        self.history_countdown_timer.start()

    def _load_cached_data(self) -> None:
        try:
            if DATA_FILE.exists():
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.headers = list(data.get("headers", []))
                self.source_headers = list(data.get("source_headers", []))
                self.rows_all = data.get("rows", [])
                self.rows = list(self.rows_all)
                self.row_histories = data.get("row_histories", [])
        except Exception:
            self.headers = []
            self.source_headers = []
            self.rows_all = []
            self.rows = []
            self.row_histories = []

    def _save_cached_data(self) -> None:
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            payload = {
                "headers": self.headers,
                "source_headers": self.source_headers,
                "rows": self.rows_all,
                "row_histories": self.row_histories,
            }
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_state(self) -> None:
        try:
            if STATE_FILE.exists():
                with open(STATE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                theme = data.get("theme")
                if theme in THEMES:
                    self.current_theme = theme
                path = data.get("path")
                if path:
                    self.current_path = Path(path)
                geometry = data.get("geometry")
                if geometry and isinstance(geometry, list) and len(geometry) == 2:
                    w, h = geometry
                    self.resize(int(w), int(h))
                widths = data.get("column_widths", {})
                if isinstance(widths, dict):
                    self.saved_column_widths = widths
                header_h = data.get("header_height")
                if header_h is not None:
                    try:
                        self.saved_header_height = int(header_h)
                    except Exception:
                        self.saved_header_height = None
                aligns = data.get("column_align", {})
                if isinstance(aligns, dict):
                    self.alignment_map = {k: int(v) for k, v in aligns.items()}
                self.filter_values = {int(k): str(v) for k, v in data.get("filters", {}).items()} if isinstance(data.get("filters", {}), dict) else {}
                self.autosave_interval_ms = int(data.get("autosave_ms", 0))
                self.autosave_enabled = bool(data.get("autosave_enabled", True))
                history = data.get("session_history", [])
                if isinstance(history, list):
                    self.session_history = [h for h in history if isinstance(h, dict)]
                formats = data.get("column_formats", {})
                if isinstance(formats, dict):
                    self.column_formats = {str(k): str(v) for k, v in formats.items()}
                hidden = data.get("hidden_columns")
                if isinstance(hidden, list):
                    self.hidden_columns = {int(x) for x in hidden}
                lv = data.get("letter_visible")
                if isinstance(lv, bool):
                    self.letter_visible_pref = lv
                plf = data.get("phone_list_filter")
                if isinstance(plf, list):
                    normalized_set = {self._normalize_phone_value(x) for x in plf if self._normalize_phone_value(x)}
                    self.phone_list_filter = normalized_set if normalized_set else None
                rh = data.get("row_histories", [])
                if isinstance(rh, list):
                    self.row_histories = rh
                if "row_height" in data:
                    try:
                        self.row_height = int(data.get("row_height", 20))
                    except Exception:
                        self.row_height = 20
                if "hsd_chart_enabled" in data:
                    self.hsd_chart_enabled = bool(data.get("hsd_chart_enabled", True))
                styles = data.get("cell_styles", {})
                if isinstance(styles, dict):
                    self.cell_styles = {str(k): v for k, v in styles.items()}
                ver = data.get("migr_status_yellow_removed_ver")
                if isinstance(ver, int):
                    self._migr_status_yellow_removed_ver = int(ver)
                else:
                    self._migr_status_yellow_removed_ver = 1 if bool(data.get("migr_status_yellow_removed", False)) else 0
            tab_idx = data.get("active_tab")
            if isinstance(tab_idx, int) and tab_idx >= 0:
                self.saved_tab_index = tab_idx
            st_tpl = data.get("stats_template")
            if isinstance(st_tpl, str) and st_tpl.strip():
                self.saved_stats_template = st_tpl.strip()
            stats_w = data.get("stats_nm_widths", {})
            if isinstance(stats_w, dict):
                try:
                    self.stats_nm_widths = {str(k): int(v) for k, v in stats_w.items()}
                except Exception:
                    self.stats_nm_widths = {}
            tk_th = data.get("stats_tk_threshold")
            if isinstance(tk_th, (int, float, str)):
                try:
                    self.stats_tk_threshold = int(float(tk_th))
                except Exception:
                    self.stats_tk_threshold = 250
            templates = data.get("templates", [])
            if isinstance(templates, list):
                cleaned = []
                for tpl in templates:
                    if not isinstance(tpl, dict):
                        continue
                    name = str(tpl.get("name", "")).strip()
                    headers = tpl.get("headers", [])
                    if not name or not isinstance(headers, list):
                        continue
                    cleaned_tpl = {
                        "name": name,
                        "headers": [str(h) for h in headers],
                    }
                    if isinstance(tpl.get("source_headers"), list):
                        cleaned_tpl["source_headers"] = [str(h) for h in tpl["source_headers"]]
                    if isinstance(tpl.get("rows"), list):
                        cleaned_tpl["rows"] = tpl["rows"]
                    if isinstance(tpl.get("column_formats"), dict):
                        cleaned_tpl["column_formats"] = {str(k): str(v) for k, v in tpl["column_formats"].items()}
                    if isinstance(tpl.get("column_widths"), dict):
                        cleaned_tpl["column_widths"] = {str(k): int(v) for k, v in tpl["column_widths"].items()}
                    if isinstance(tpl.get("alignment"), dict):
                        cleaned_tpl["alignment"] = {str(k): int(v) for k, v in tpl["alignment"].items()}
                    if isinstance(tpl.get("filters"), dict):
                        cleaned_tpl["filters"] = {int(k): str(v) for k, v in tpl["filters"].items()}
                    if isinstance(tpl.get("row_histories"), list):
                        cleaned_tpl["row_histories"] = tpl["row_histories"]
                    if isinstance(tpl.get("alert_rules"), list):
                        cleaned_tpl["alert_rules"] = tpl["alert_rules"]
                    if isinstance(tpl.get("alert_send_enabled"), bool):
                        cleaned_tpl["alert_send_enabled"] = tpl["alert_send_enabled"]
                    cleaned.append(cleaned_tpl)
                self.templates = cleaned
            active = data.get("active_template")
            if isinstance(active, str) and active:
                self.active_template = active
            # alert root-level (fallback khi không theo template)
            if isinstance(data.get("alert_rules"), list):
                self.alert_rules = data["alert_rules"]
            if isinstance(data.get("alert_send_enabled"), bool):
                self.alert_send_enabled = data["alert_send_enabled"]
            token = data.get("alert_bot_token")
            if isinstance(token, str):
                self.alert_bot_token = token
            chat_id = data.get("alert_chat_id")
            if isinstance(chat_id, (str, int)):
                self.alert_chat_id = str(chat_id).strip()
            tpl_alerts = data.get("alert_templates")
            if isinstance(tpl_alerts, list):
                self.alert_templates = [t for t in tpl_alerts if isinstance(t, dict) and t.get("name") and isinstance(t.get("rules"), list)]
            ops_order = data.get("alert_ops_order")
            if isinstance(ops_order, list):
                self.alert_ops_order = [str(k) for k in ops_order]
            ops_hidden = data.get("alert_ops_hidden")
            if isinstance(ops_hidden, list):
                self.alert_ops_hidden = {str(k) for k in ops_hidden}
            # nếu có template đang active và chứa alert riêng -> ưu tiên
            if self.active_template:
                tpl = next((t for t in self.templates if t.get("name") == self.active_template), None)
                if tpl:
                    if isinstance(tpl.get("alert_rules"), list):
                        self.alert_rules = tpl["alert_rules"]
                    if isinstance(tpl.get("alert_send_enabled"), bool):
                        self.alert_send_enabled = tpl["alert_send_enabled"]
            sent = data.get("alert_sent_map")
            if isinstance(sent, dict):
                self.alert_sent_map = sent
            self._sanitize_alert_ops()
            self._ensure_alert_rule_ids()
        except Exception:
            pass

    def _migrate_remove_status_yellow(self) -> None:
        """One-time cleanup: older builds auto-colored the 'Trạng thái' column yellow via cell_styles.

        Remove that legacy yellow background so the column returns to normal theme colors.
        """
        if int(getattr(self, "_migr_status_yellow_removed_ver", 0)) >= 2:
            return
        status_idx = self._status_column_index()
        self._migr_status_yellow_removed_ver = 2
        if status_idx is None or not self.cell_styles:
            self._save_state()
            return
        legacy_yellows = {"#fff59d", "#fff2cc", "#ffe066", "#facc15"}
        changed = False
        for key in list(self.cell_styles.keys()):
            parts = str(key).split("_")
            if len(parts) != 2:
                continue
            try:
                col_idx = int(parts[1])
            except Exception:
                continue
            if col_idx != status_idx:
                continue
            style = self.cell_styles.get(key)
            if not isinstance(style, dict):
                continue
            bg = style.get("bg")
            if not isinstance(bg, str):
                continue
            if bg.strip().lower() not in legacy_yellows:
                continue
            style2 = dict(style)
            style2.pop("bg", None)
            if not style2:
                self.cell_styles.pop(key, None)
            else:
                self.cell_styles[key] = style2
            changed = True
        if changed:
            self._save_state()
        else:
            # still persist the migration flag
            self._save_state()

    def _save_state(self) -> None:
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            data = {
                "theme": self.current_theme,
                "path": str(self.current_path),
                "geometry": [self.width(), self.height()],
            }
            ver = int(getattr(self, "_migr_status_yellow_removed_ver", 0))
            data["migr_status_yellow_removed_ver"] = ver
            data["migr_status_yellow_removed"] = bool(ver >= 1)
            # Lưu width cột
            if self.table.model():
                widths = {}
                for col in range(self.table.model().columnCount()):
                    widths[str(col)] = self.table.columnWidth(col)
                data["column_widths"] = widths
                data["column_align"] = {k: int(v) for k, v in self.alignment_map.items()}
                if self.filter_values:
                    data["filters"] = {str(k): v for k, v in self.filter_values.items()}
                data["autosave_ms"] = self.autosave_interval_ms
                data["autosave_enabled"] = self.autosave_enabled
                data["alert_rules"] = self.alert_rules
                data["alert_send_enabled"] = self.alert_send_enabled
                if self.alert_sent_map:
                    data["alert_sent_map"] = self.alert_sent_map
                if self.alert_ops_order:
                    data["alert_ops_order"] = self.alert_ops_order
                if self.alert_ops_hidden:
                    data["alert_ops_hidden"] = list(self.alert_ops_hidden)
                if self.alert_templates:
                    data["alert_templates"] = self.alert_templates
                if self.column_formats:
                    data["column_formats"] = self.column_formats
                if self.session_history:
                    data["session_history"] = self.session_history[:20]
                if self.row_histories:
                    data["row_histories"] = self.row_histories
                if self.hidden_columns:
                    data["hidden_columns"] = list(self.hidden_columns)
                if self.cell_styles:
                    data["cell_styles"] = self.cell_styles
                data["letter_visible"] = bool(self.letter_toggle.isChecked()) if hasattr(self, "letter_toggle") else True
            # Telegram credential (persist even when model isn't ready)
            data["alert_bot_token"] = str(getattr(self, "alert_bot_token", "") or "")
            data["alert_chat_id"] = str(getattr(self, "alert_chat_id", "") or "")
            if self.phone_list_filter:
                data["phone_list_filter"] = list(self.phone_list_filter)
            if self.templates:
                data["templates"] = self.templates
            if self.active_template:
                data["active_template"] = self.active_template
            if self.saved_header_height:
                data["header_height"] = self.saved_header_height
            data["row_height"] = self.row_height
            if hasattr(self, "tabs"):
                self.saved_tab_index = max(0, self.tabs.currentIndex())
                data["active_tab"] = self.saved_tab_index
            if hasattr(self, "stats_template") and self.stats_template.count() > 0:
                cur_idx = self.stats_template.currentIndex()
                if cur_idx > 0:
                    self.saved_stats_template = self.stats_template.currentText()
                    data["stats_template"] = self.saved_stats_template
                else:
                    self.saved_stats_template = None
            if hasattr(self, "stats_nm_table") and self.stats_nm_table.columnCount() > 0:
                widths = {}
                for c in range(self.stats_nm_table.columnCount()):
                    widths[str(c)] = self.stats_nm_table.columnWidth(c)
                data["stats_nm_widths"] = widths
            data["stats_tk_threshold"] = self.stats_tk_threshold
            data["hsd_chart_enabled"] = bool(getattr(self, "hsd_chart_enabled", True))
            with open(STATE_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _persist_now(self) -> None:
        self._ensure_alert_rule_ids()
        self._update_active_template_snapshot()
        self._save_cached_data()
        self._save_state()
        current_state = self._create_state_snapshot()
        if not self._undoing and self._last_state_snapshot:
            if self.undo_stack and self.undo_stack[-1] == self._last_state_snapshot:
                pass
            else:
                self.undo_stack.append(self._last_state_snapshot)
                if len(self.undo_stack) > 20:
                    self.undo_stack.pop(0)
                self.redo_stack.clear()
        self._last_state_snapshot = current_state
        self._refresh_stats()

    def _create_state_snapshot(self) -> dict:
        return {
            "headers": list(self.headers),
            "rows": copy.deepcopy(self.rows_all),
            "source_headers": list(self.source_headers),
            "row_histories": copy.deepcopy(self.row_histories),
            "cell_styles": copy.deepcopy(self.cell_styles),
            "row_height": self.row_height,
            "hidden_columns": list(self.hidden_columns),
        }

    def _default_alert_ops(self) -> list[tuple[str, str]]:
        return list(DEFAULT_ALERT_OPS)

    def _ensure_alert_rule_ids(self) -> None:
        """Gắn id cố định cho mỗi rule để tính tần suất không phụ thuộc vị trí/đảo thứ tự."""
        def _assign(rule: dict):
            if isinstance(rule, dict) and not rule.get("id"):
                rule["id"] = uuid.uuid4().hex
        for rule in self.alert_rules:
            _assign(rule)
            extras = rule.get("extras")
            if isinstance(extras, list):
                for ex in extras:
                    _assign(ex)

    def _seed_default_alert_templates(self) -> None:
        """Thêm sẵn một số mẫu cảnh báo phổ biến nếu chưa có."""
        presets = [
            {
                "name": "Sim khóa",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "Trạng thái",
                        "op": "contains",
                        "value": "Khóa",
                        "value2": "",
                        "color": "#ec4899",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": True,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [],
                    }
                ],
            },
            {
                "name": "Gia hạn VNMB",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "HSD",
                        "op": "days_before_pivot",
                        "value": "5",
                        "value2": "45",
                        "color": "#facc15",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": False,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [
                            {"col": "Nhà mạng", "op": "contains", "value": "VNMB", "value2": ""},
                        ],
                    }
                ],
            },
            {
                "name": "Gia hạn Gmobile <250",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "HSD",
                        "op": "days_before_pivot",
                        "value": "5",
                        "value2": "30",
                        "color": "#f97316",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": False,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [
                            {"col": "TKC", "op": "lt", "value": "250", "value2": ""},
                            {"col": "Nhà mạng", "op": "in_list", "value": "GMOBILE", "value2": ""},
                        ],
                    }
                ],
            },
            {
                "name": "Gia hạn Gmobile >250",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "HSD",
                        "op": "days_before_pivot",
                        "value": "5",
                        "value2": "30",
                        "color": "#22c55e",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": False,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [
                            {"col": "TKC", "op": "gte", "value": "250", "value2": ""},
                            {"col": "Nhà mạng", "op": "in_list", "value": "GMOBILE", "value2": ""},
                        ],
                    }
                ],
            },
            {
                "name": "Gia hạn Local/Sky <250",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "HSD",
                        "op": "days_before_pivot",
                        "value": "5",
                        "value2": "30",
                        "color": "#f97316",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": False,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [
                            {"col": "TKC", "op": "lt", "value": "250", "value2": ""},
                            {"col": "Nhà mạng", "op": "in_list", "value": "LOCAL, SKY", "value2": ""},
                        ],
                    }
                ],
            },
            {
                "name": "Gia hạn Local/Sky >250",
                "send_enabled": True,
                "rules": [
                    {
                        "col": "HSD",
                        "op": "days_before_pivot",
                        "value": "5",
                        "value2": "30",
                        "color": "#22c55e",
                        "notify": True,
                        "notify_file": True,
                        "notify_file_type": "csv",
                        "bold": False,
                        "italic": False,
                        "freq_value": 1,
                        "freq_unit": "day",
                        "freq_limit": 1,
                        "extras": [
                            {"col": "TKC", "op": "gte", "value": "250", "value2": ""},
                            {"col": "Nhà mạng", "op": "in_list", "value": "LOCAL, SKY", "value2": ""},
                        ],
                    }
                ],
            },
        ]
        existing = {str(t.get("name", "")).lower() for t in self.alert_templates}
        added = False
        for tpl in presets:
            if tpl["name"].lower() not in existing:
                self.alert_templates.append(tpl)
                added = True
        if added:
            self._save_state()

    def _sanitize_alert_ops(self) -> None:
        valid = {k for k, _ in DEFAULT_ALERT_OPS}
        self.alert_ops_order = [k for k in self.alert_ops_order if k in valid]
        self.alert_ops_hidden = {k for k in self.alert_ops_hidden if k in valid}

    def _alert_ops_full(self) -> list[tuple[str, str, bool]]:
        self._sanitize_alert_ops()
        base_map = {k: lbl for k, lbl in self._default_alert_ops()}
        order = [k for k in self.alert_ops_order if k in base_map]
        for k in base_map.keys():
            if k not in order:
                order.append(k)
        result = []
        for k in order:
            result.append((k, base_map.get(k, k), k in self.alert_ops_hidden))
        return result

    def _alert_ops_ordered(self) -> list[tuple[str, str]]:
        return [(k, lbl) for k, lbl, hidden in self._alert_ops_full() if not hidden]

    def _update_active_template_snapshot(self) -> None:
        """Nếu đang ở một mẫu, ghi đè snapshot của mẫu bằng dữ liệu hiện tại để khi chuyển đi/đến mẫu khác không mất thay đổi."""
        if not self.active_template:
            return
        snapshot = {
            "name": self.active_template,
            "headers": [h for h in self.headers],
            "source_headers": [h for h in self.source_headers],
            "rows": copy.deepcopy(self.rows_all),
            "column_formats": dict(self.column_formats),
            "column_widths": dict(self.saved_column_widths),
            "alignment": dict(self.alignment_map),
            "filters": dict(self.filter_values),
            "alert_rules": copy.deepcopy(self.alert_rules),
            "alert_send_enabled": bool(self.alert_send_enabled),
        }
        updated = False
        for tpl in self.templates:
            if tpl.get("name") == self.active_template:
                tpl.update(snapshot)
                updated = True
                break
        if not updated:
            self.templates.append(snapshot)

    def _summarize_alert_rule(self, rule: dict, include_extras: bool = True, include_meta: bool = True) -> str:
        op = rule.get("op", "contains")
        val = rule.get("value", "")
        val2 = rule.get("value2", "")
        col = rule.get("col", "")
        op_label = {
            "empty": "trống",
            "not_empty": "không trống",
            "contains": "chứa",
            "not_contains": "không chứa",
            "startswith": "bắt đầu",
            "endswith": "kết thúc",
            "equals": "=",
            "notequals": "≠",
            "gt": ">",
            "gte": "≥",
            "lt": "<",
            "lte": "≤",
            "eq": "=",
            "neq": "≠",
            "in_list": "thuộc danh sách",
            "between": "trong khoảng",
            "not_between": "ngoài khoảng",
            "date_is": "= ngày",
            "date_before": "< ngày",
            "date_after": "> ngày",
            "days_equal": "cách ± ngày",
            "days_before_eq": "cách trước = ngày",
            "days_after_eq": "cách sau = ngày",
            "days_equal_pivot": "cách ±x ngày mốc+y",
            "days_before_pivot": "cách trước x ngày mốc+y",
            "days_after_pivot": "cách sau x ngày mốc+y",
            "month_is": "tháng =",
            "year_is": "năm =",
            "month_current": "tháng này",
            "year_current": "năm nay",
            "custom": "công thức",
        }.get(op, op)
        if op in {"between", "not_between"}:
            txt = f"{col} {op_label} [{val}..{val2}]"
        elif op in {"date_is", "date_before", "date_after", "days_equal", "days_before_eq", "days_after_eq", "month_is", "year_is"}:
            txt = f"{col} {op_label} {val}"
        elif op in {"days_equal_pivot", "days_before_pivot", "days_after_pivot"}:
            if op == "days_equal_pivot":
                txt = f"{col} cách ±{val} ngày mốc +{val2}"
            elif op == "days_before_pivot":
                txt = f"{col} cách trước {val} ngày mốc +{val2}"
            else:
                txt = f"{col} cách sau {val} ngày mốc +{val2}"
        elif op in {"empty", "not_empty", "month_current", "year_current"}:
            txt = f"{col} {op_label}"
        elif op == "custom":
            txt = f"{col} {op_label}: {val}"
        else:
            txt = f"{col} {op_label} {val}"

        extras = rule.get("extras") or []
        if not include_extras:
            return txt

        conds = ["(" + txt + ")"]
        for ex in extras:
            conds.append("(" + self._summarize_alert_rule(ex, include_extras=False) + ")")
        cond_part = "x".join(conds)

        if not include_meta:
            return cond_part

        meta: list[str] = []
        if rule.get("notify"):
            meta.append("(TG)")
        if rule.get("notify_file"):
            ftype = str(rule.get("notify_file_type") or "csv").lower()
            meta.append("(FILE " + ("TXT" if ftype.startswith("t") else "CSV") + ")")
        flags = []
        if rule.get("bold"):
            flags.append("B")
        if rule.get("italic"):
            flags.append("I")
        if flags:
            meta.append("(" + "".join(flags) + ")")
        try:
            freq_v = int(rule.get("freq_value", 1))
        except Exception:
            freq_v = 1
        try:
            freq_lim = int(rule.get("freq_limit", 1))
        except Exception:
            freq_lim = 1
        unit = str(rule.get("freq_unit", "day"))
        unit_label = "d" if unit.startswith("day") or unit.startswith("ng") else ("h" if unit.startswith("h") or unit.startswith("gi") else "m")
        if freq_v <= 0:
            freq_v = 1
        if freq_lim <= 0:
            freq_lim = 1
        meta.append(f"({freq_v}{unit_label} x {freq_lim})")

        out = cond_part + (" -> " + " ".join(meta) if meta else "")
        color_hex = str(rule.get("color") or "").strip()
        if color_hex:
            out += f" [{color_hex}]"
        return out

    def _open_alert_manager(self) -> None:
        from PySide6.QtWidgets import QListWidget, QListWidgetItem

        dlg = QDialog(self)
        dlg.setWindowTitle("Cảnh báo (Dữ liệu)")
        dlg.setMinimumWidth(760)
        dlg.resize(820, 580)
        vbox = QVBoxLayout(dlg)

        top_row = QHBoxLayout()
        btn_help = QPushButton("Hướng dẫn sử dụng")
        btn_help.setCursor(Qt.PointingHandCursor)

        def _show_alert_help():
            help_dlg = QDialog(dlg)
            help_dlg.setWindowTitle("Hướng dẫn cảnh báo")
            lay = QVBoxLayout(help_dlg)
            txt = QTextEdit()
            txt.setReadOnly(True)
            txt.setMinimumSize(680, 420)
            txt.setText(
                "Cách dùng cảnh báo:\n"
                "- Chọn cột, điều kiện, giá trị. Có thể thêm nhiều điều kiện phụ (AND).\n"
                "- Để gửi Telegram: bật 'Gửi Telegram' và bật 'Gửi file' (mặc định CSV).\n"
                "- Rule trên được ưu tiên: dòng khớp rule trên sẽ không xét rule dưới.\n"
                "\nCác điều kiện hỗ trợ (kèm mẫu):\n"
                "• Trống: (Note) Trống\n"
                "• Không trống: (Note) Không trống\n"
                "• Chứa: (Trạng thái) chứa Khóa\n"
                "• Không chứa: (Trạng thái) không chứa Khóa\n"
                "• Thuộc danh sách: (Nhà mạng) thuộc danh sách VNMB, LOCAL\n"
                "• Bắt đầu: (SĐT) bắt đầu 098\n"
                "• Kết thúc: (SĐT) kết thúc 789\n"
                "• Bằng / Không bằng: (Nhà mạng) = VNMB ; (Nhà mạng) ≠ VNMB\n"
                "• So sánh số: (TKC) > 1000 ; (TKC) ≤ 250\n"
                "• Trong khoảng: (TKC) giữa 100..500\n"
                "• Ngoài khoảng: (TKC) ngoài 100..500\n"
                "• Ngày = / < / >: (HSD) = 01/05/2026 ; (Ngày nhập) < 01/02/2026\n"
                "• Khoảng cách ngày: (HSD) cách ±5 ngày ; (HSD) cách trước =5 ngày ; (HSD) cách sau =3 ngày\n"
                "• Khoảng cách mốc+y: (HSD) cách ±5 ngày mốc+30 ; (HSD) cách trước 5 ngày mốc+30 ; (HSD) cách sau 2 ngày mốc+15\n"
                "• Tháng =: (HSD) tháng = 5\n"
                "• Năm =: (HSD) năm = 2026\n"
                "• Tháng này / Năm nay: (HSD) tháng này ; (HSD) năm nay\n"
                "• Công thức (custom): (TKC) custom: num > 1000 and 'VNMB' in text\n"
                "\nVí dụ tổ hợp:\n"
                "1) (HSD cách trước 5 ngày mốc +30)\n"
                "2) (Trạng thái chứa 'Khóa')\n"
                "3) (TKC < 250)\n"
                "4) (HSD cách trước 5 ngày mốc +30) x (Nhà mạng chứa VNMB) x (TKC < 250)\n"
                "\nGửi file:\n"
                "- CSV: đầy đủ cột, giữ nguyên SĐT/Serial (chống dạng khoa học).\n"
                "- TXT: chỉ danh sách SĐT.\n"
                "- Tên file kèm tổng số dòng khớp.\n"
            )
            lay.addWidget(txt)
            btn_close = QDialogButtonBox(QDialogButtonBox.Close)
            btn_close.rejected.connect(help_dlg.reject)
            lay.addWidget(btn_close)
            help_dlg.exec()

        btn_help.clicked.connect(_show_alert_help)

        info = QLabel("Telegram dùng token/chat_id trong tab Cài đặt")
        info.setStyleSheet("color:#9ca3af;")
        btn_test = QPushButton("Test Telegram")
        btn_test_alert = QPushButton("Test cảnh báo")
        btn_test_alert.setStyleSheet("QPushButton { padding:6px 10px; font-weight:600; }")

        top_row.addWidget(btn_help)
        top_row.addSpacing(8)
        top_row.addWidget(info, 1)
        top_row.addStretch()
        top_row.addWidget(btn_test)
        top_row.addWidget(btn_test_alert)
        vbox.addLayout(top_row)

        cred = QLabel("")
        err = QLabel("")
        err.setWordWrap(True)

        def _mask_token(s: str) -> str:
            s = (s or "").strip()
            if not s:
                return "(trống)"
            if len(s) <= 18:
                return s
            return s[:10] + "..." + s[-6:]

        def refresh_cred_labels():
            token = (self.alert_bot_token or "").strip()
            chat_id = (self.alert_chat_id or "").strip()
            ok = bool(token and chat_id)
            cred.setText(f"Token: {_mask_token(token)} | Chat ID: {(chat_id if chat_id else '(trống)')}")
            cred.setStyleSheet("color:#22c55e;" if ok else "color:#ef4444;")
            last_err = (getattr(self, "_telegram_last_error", "") or "").strip()
            if last_err:
                err.setText("Lỗi TG gần nhất: " + last_err)
                err.setStyleSheet("color:#ef4444;")
                err.setVisible(True)
            else:
                err.setVisible(False)

        vbox.addWidget(cred)
        vbox.addWidget(err)
        refresh_cred_labels()

        def do_test():
            ok, e = self._telegram_send_message(f"MXHsim test: {datetime.now().strftime('%H:%M:%S %d/%m/%Y')}")
            if ok:
                QMessageBox.information(dlg, "Telegram", "Đã gửi tin nhắn test.")
            else:
                QMessageBox.warning(dlg, "Telegram", f"Không gửi được Telegram:\n{e}")
            refresh_cred_labels()

        btn_test.clicked.connect(do_test)
        def do_test_alert():
            if not self.alert_rules:
                QMessageBox.information(dlg, "Test cảnh báo", "Chưa có cảnh báo nào. Hãy thử ấn Test Telegram.")
                return
            sel_rows = {i.row() for i in lst.selectionModel().selectedIndexes()}
            if sel_rows:
                rule_set = sel_rows
            else:
                QMessageBox.information(dlg, "Test cảnh báo", "Hãy chọn ít nhất một điều kiện cảnh báo để test.")
                return
            # bỏ qua cờ bật/tắt và tần suất khi test, chỉ áp dụng các rule được chọn
            self._scan_alerts_and_send(force=True, ignore_freq=True, rule_indices=rule_set)
            QMessageBox.information(
                dlg,
                "Test cảnh báo",
                "Đã quét và gửi cảnh báo cho các điều kiện đang chọn (bỏ qua công tắc bật/tắt và tần suất).",
            )

        btn_test_alert.clicked.connect(do_test_alert)

        chk_send = QCheckBox("Gửi Telegram khi thỏa điều kiện")
        chk_send.setChecked(self.alert_send_enabled)

        lst = QListWidget()
        lst.setMinimumWidth(720)
        lst.setSelectionMode(QAbstractItemView.ExtendedSelection)
        lst.setDragDropMode(QAbstractItemView.InternalMove)
        lst.setMouseTracking(True)
        lst.setStyleSheet(
            """
            QListWidget::item { padding: 3px 2px; }
            QListWidget::item:hover { background: #2b3144; }
            QListWidget::item:selected { background: #3b82f6; }
            """
        )
        # -- khu vực mẫu cảnh báo (search + menu + áp dụng) --
        tpl_row = QHBoxLayout()
        lbl_tpl = QLabel("Mẫu cảnh báo:")
        tpl_menu_btn = QToolButton()
        tpl_menu_btn.setText("▾")
        tpl_menu_btn.setFixedWidth(22)
        tpl_menu_btn.setPopupMode(QToolButton.InstantPopup)
        tpl_menu = QMenu(dlg)
        tpl_menu.setStyleSheet(
            """
            QMenu { background: #1f2430; border: 1px solid #3a425a; }
            QMenu::item { padding: 6px 14px; color: #e5e7eb; }
            QMenu::item:selected { background: #2b3144; color: #ffffff; }
            """
        )
        tpl_menu.setContextMenuPolicy(Qt.CustomContextMenu)
        # giữ tham chiếu để eventFilter biết menu nào
        self._alert_tpl_menu = tpl_menu
        tpl_row.setContentsMargins(0, 0, 0, 0)
        tpl_row.setSpacing(4)

        def _refresh_tpl_menu():
            tpl_menu.clear()
            if not self.alert_templates:
                act = tpl_menu.addAction("(Chưa có mẫu)")
                act.setEnabled(False)
            else:
                for tpl in self.alert_templates:
                    name = tpl.get("name", "")
                    act = tpl_menu.addAction(name)
                    act.setData(name)
                    act.triggered.connect(lambda checked=False, n=name: _apply_template(n))
            tpl_menu_btn.setMenu(tpl_menu)
            # right-click delete directly inside dropdown
            try:
                if hasattr(self, "_tpl_menu_ctx_slot"):
                    tpl_menu.customContextMenuRequested.disconnect(self._tpl_menu_ctx_slot)
            except Exception:
                pass
            def _on_tpl_menu_ctx(pos):
                action = tpl_menu.actionAt(pos)
                if action and action.data():
                    name = str(action.data())
                    menu = QMenu(tpl_menu)
                    act_edit = menu.addAction("Sửa mẫu...")
                    act_del = menu.addAction("Xóa mẫu")
                    chosen = menu.exec(tpl_menu.mapToGlobal(pos))
                    if chosen == act_edit:
                        _edit_template_dialog(name)
                    elif chosen == act_del:
                        confirm = QMessageBox.question(
                            tpl_menu,
                            "Xóa mẫu cảnh báo",
                            f"Xóa mẫu '{name}'?",
                            QMessageBox.Yes | QMessageBox.No,
                            QMessageBox.No,
                        )
                        if confirm == QMessageBox.Yes:
                            self._delete_template(name)
                            _refresh_tpl_menu()
            self._tpl_menu_ctx_slot = _on_tpl_menu_ctx
            tpl_menu.customContextMenuRequested.connect(self._tpl_menu_ctx_slot)

        def _apply_template(name: str | None = None):
            target = (name or "").strip()
            if not target:
                return
            tpl = next((t for t in self.alert_templates if t.get("name", "").lower() == target.lower()), None)
            if not tpl:
                QMessageBox.information(dlg, "Mẫu cảnh báo", f"Không tìm thấy mẫu '{target}'.")
                return
            rules = tpl.get("rules")
            if not isinstance(rules, list):
                QMessageBox.warning(dlg, "Mẫu cảnh báo", "Mẫu không hợp lệ.")
                return
            appended = copy.deepcopy(rules)
            for r in appended:
                if isinstance(r, dict):
                    r["id"] = uuid.uuid4().hex
            self.alert_rules.extend(appended)
            for r in appended:
                it = QListWidgetItem()
                _apply_item_style(it, r)
                lst.addItem(it)
            nonlocal_need_reset[0] = True

        def _edit_template_dialog(name: str) -> None:
            tpl = next((t for t in self.alert_templates if str(t.get("name", "")).lower() == name.lower()), None)
            if not tpl:
                QMessageBox.information(dlg, "Mẫu cảnh báo", f"Không tìm thấy mẫu '{name}'.")
                return
            tpl_rules = copy.deepcopy(tpl.get("rules", []))
            existing = tpl_rules[0] if tpl_rules else None
            new_rule = edit_rule(existing)
            if new_rule:
                if tpl_rules:
                    tpl_rules[0] = new_rule
                else:
                    tpl_rules.append(new_rule)
                tpl["rules"] = tpl_rules
                self._save_state()
                _refresh_tpl_menu()

        tpl_row.addWidget(lbl_tpl)
        tpl_row.addWidget(tpl_menu_btn)
        send_row = QHBoxLayout()
        send_row.addWidget(chk_send)
        send_row.addSpacing(12)
        send_row.addLayout(tpl_row)
        send_row.addStretch()
        vbox.addLayout(send_row)

        def _delete_alert_template(name: str):
            idx = next((i for i, t in enumerate(self.alert_templates) if str(t.get("name", "")) == name), -1)
            if idx >= 0:
                self.alert_templates.pop(idx)
                self._save_state()
                _refresh_tpl_menu()
                nonlocal_need_reset[0] = True

        def _show_tpl_delete_menu(pos):
            if not self.alert_templates:
                return
            menu = QMenu(dlg)
            for tpl in self.alert_templates:
                name = tpl.get("name", "")
                if not name:
                    continue
                act = menu.addAction(f"Xóa '{name}'")
                act.triggered.connect(lambda checked=False, n=name: _delete_alert_template(n))
            menu.exec(tpl_menu_btn.mapToGlobal(pos))

        tpl_menu_btn.setContextMenuPolicy(Qt.CustomContextMenu)
        tpl_menu_btn.customContextMenuRequested.connect(_show_tpl_delete_menu)
        # cho phép click phải trực tiếp trên menu thả xuống để xóa mẫu đang hover
        tpl_menu.installEventFilter(self)

        def _apply_item_style(item: QListWidgetItem, rule: dict):
            try:
                c = QColor(rule.get("color", "#ef4444"))
            except Exception:
                c = QColor("#ef4444")
            pm = QPixmap(14, 14)
            pm.fill(c if c.isValid() else QColor("#ef4444"))
            item.setIcon(QIcon(pm))
            active = bool(rule.get("notify")) and bool(rule.get("notify_file"))
            fg = QColor("#22c55e") if active else QColor("#e5e7eb")
            item.setForeground(fg)
            item.setText(self._summarize_alert_rule(rule))

        for r in self.alert_rules:
            it = QListWidgetItem()
            _apply_item_style(it, r)
            lst.addItem(it)
        _refresh_tpl_menu()

        def copy_selected_rule():
            it = lst.currentItem()
            if not it:
                return
            QGuiApplication.clipboard().setText(it.text())

        shortcut_copy = QShortcut(QKeySequence.Copy, lst)
        shortcut_copy.activated.connect(copy_selected_rule)
        shortcut_select_all = QShortcut(QKeySequence.SelectAll, lst)
        shortcut_select_all.activated.connect(lambda: lst.selectAll())
        lst.setContextMenuPolicy(Qt.CustomContextMenu)

        def _show_rule_menu(pos):
            item = lst.itemAt(pos)
            if not item:
                return
            menu = QMenu(lst)
            act_edit = menu.addAction("Sửa")
            act_del = menu.addAction("Xóa")
            act_dup = menu.addAction("Sao chép")
            act_copy = menu.addAction("Copy nội dung")
            chosen = menu.exec(lst.mapToGlobal(pos))
            if chosen == act_edit:
                do_edit()
            elif chosen == act_del:
                do_del()
            elif chosen == act_dup:
                do_dup()
            elif chosen == act_copy:
                copy_selected_rule()

        lst.customContextMenuRequested.connect(_show_rule_menu)
        vbox.addWidget(lst)

        btn_row = QHBoxLayout()
        btn_add = QPushButton("Thêm")
        btn_edit = QPushButton("Sửa")
        btn_del = QPushButton("Xóa")
        btn_dup = QPushButton("Sao chép")
        btn_save_tpl = QPushButton("Lưu mẫu")
        btn_row.addWidget(btn_add)
        btn_row.addWidget(btn_edit)
        btn_row.addWidget(btn_del)
        btn_row.addWidget(btn_dup)
        btn_row.addWidget(btn_save_tpl)
        btn_row.addStretch()
        vbox.addLayout(btn_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        vbox.addWidget(buttons)

        nonlocal_need_reset = [False]

        def _on_rows_moved(parent, start, end, dest_parent, dest_row):
            try:
                if start == end:
                    rule = self.alert_rules.pop(start)
                    if dest_row > start:
                        dest_row -= 1
                    self.alert_rules.insert(dest_row, rule)
                    nonlocal_need_reset[0] = True
            except Exception:
                pass

        try:
            lst.model().rowsMoved.connect(_on_rows_moved)
        except Exception:
            pass

        def available_ops() -> list[tuple[str, str]]:
            return self._alert_ops_ordered()

        def fill_ops(cmb: QComboBox, current_key: Optional[str] = None) -> None:
            ops = available_ops()
            cmb.blockSignals(True)
            cmb.clear()
            for key, label in ops:
                cmb.addItem(label, key)
            if current_key:
                idx = cmb.findData(current_key)
                if idx >= 0:
                    cmb.setCurrentIndex(idx)
            if cmb.count() > 0 and cmb.currentIndex() < 0:
                cmb.setCurrentIndex(0)
            cmb.blockSignals(False)

        def edit_rule(existing: dict | None = None) -> dict | None:
            dlg2 = QDialog(dlg)
            dlg2.setWindowTitle("Thiết lập cảnh báo")
            lay = QVBoxLayout(dlg2)
            lay.addWidget(QLabel("Cột:"))
            cmb_col = QComboBox()
            cmb_col.addItems(self.headers)
            if existing and existing.get("col") in self.headers:
                cmb_col.setCurrentText(existing["col"])
            lay.addWidget(cmb_col)
            cond_row = QHBoxLayout()
            cond_row.addWidget(QLabel("Điều kiện:"))
            btn_ops = QToolButton()
            btn_ops.setText("✎")
            btn_ops.setCursor(Qt.PointingHandCursor)
            btn_ops.setToolTip("Sắp xếp / ẩn điều kiện")
            cond_row.addWidget(btn_ops)
            cond_row.addStretch()
            lay.addLayout(cond_row)
            cmb_op = QComboBox()
            fill_ops(cmb_op)
            if existing:
                idx = cmb_op.findData(existing.get("op", "contains"))
                if idx >= 0:
                    cmb_op.setCurrentIndex(idx)
            lay.addWidget(cmb_op)
            lbl_val = QLabel("Giá trị:")
            lay.addWidget(lbl_val)
            edt_val = QLineEdit(existing.get("value", "") if existing else "")
            lay.addWidget(edt_val)
            lbl_val2 = QLabel("Giá trị 2 (dùng cho Giữa/Không trong khoảng):")
            lay.addWidget(lbl_val2)
            edt_val2 = QLineEdit(existing.get("value2", "") if existing else "")
            lay.addWidget(edt_val2)
            def _open_ops_editor(extra_cmb: QComboBox | None = None):
                dlg_ops = QDialog(dlg2)
                dlg_ops.setWindowTitle("Sắp xếp điều kiện")
                v = QVBoxLayout(dlg_ops)
                lst = QListWidget()
                lst.setSelectionMode(QAbstractItemView.SingleSelection)
                lst.setDragDropMode(QAbstractItemView.InternalMove)
                lst.setDefaultDropAction(Qt.MoveAction)
                for key, label, hidden in self._alert_ops_full():
                    it = QListWidgetItem(label)
                    it.setData(Qt.UserRole, key)
                    it.setFlags(it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsDragEnabled | Qt.ItemIsDropEnabled)
                    it.setCheckState(Qt.Unchecked if hidden else Qt.Checked)
                    lst.addItem(it)
                v.addWidget(lst)
                note = QLabel("Bỏ tick để ẩn khỏi menu. Kéo/thả để đổi thứ tự.")
                note.setStyleSheet("color:#9ca3af;")
                v.addWidget(note)
                btns = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
                v.addWidget(btns)
                btns.accepted.connect(dlg_ops.accept)
                btns.rejected.connect(dlg_ops.reject)
                if dlg_ops.exec() == QDialog.Accepted:
                    order: list[str] = []
                    hidden_set: set[str] = set()
                    for i in range(lst.count()):
                        it = lst.item(i)
                        key = str(it.data(Qt.UserRole))
                        order.append(key)
                        if it.checkState() != Qt.Checked:
                            hidden_set.add(key)
                    if len(hidden_set) == len(order):
                        hidden_set.clear()
                    self.alert_ops_order = order
                    self.alert_ops_hidden = hidden_set
                    self._sanitize_alert_ops()
                    self._save_state()
                    targets = [cmb_op]
                    if extra_cmb is not None:
                        targets.append(extra_cmb)
                    for cmb in targets:
                        if cmb is None:
                            continue
                        cur_key = cmb.currentData()
                        fill_ops(cmb, cur_key)
            btn_ops.clicked.connect(lambda: _open_ops_editor(None))
            lay.addWidget(QLabel("Màu tô:"))
            color_preview = QLabel("     ")
            color_preview.setAutoFillBackground(True)

            def set_preview(cstr: str):
                pal = color_preview.palette()
                pal.setColor(color_preview.backgroundRole(), QColor(cstr))
                color_preview.setPalette(pal)

            default_color = existing.get("color", "#ef4444") if existing else "#ef4444"
            set_preview(default_color)

            hex_edit = QLineEdit(default_color)
            hex_edit.setPlaceholderText("#RRGGBB")
            hex_edit.setFixedWidth(90)

            def apply_hex():
                nonlocal default_color
                text = hex_edit.text().strip()
                if not text:
                    return
                if not text.startswith("#"):
                    text = "#" + text
                c = QColor(text)
                if c.isValid():
                    default_color = c.name()
                    hex_edit.setText(default_color)
                    set_preview(default_color)

            hex_edit.editingFinished.connect(apply_hex)

            btn_color = QPushButton("Bảng màu...")

            # 10 màu gợi ý quen thuộc (đồng bộ với menu Màu chữ)
            swatches = [
                "#ef4444",  # Đỏ
                "#22c55e",  # Xanh lá
                "#2563eb",  # Xanh dương
                "#1e3a8a",  # Xanh đậm
                "#facc15",  # Vàng
                "#f97316",  # Cam
                "#ec4899",  # Hồng
                "#8b5cf6",  # Tím
                "#ffffff",  # Trắng
                "#111111",  # Đen
            ]

            def pick_color():
                nonlocal default_color
                dlgc = QColorDialog(QColor(default_color), dlg2)
                dlgc.setOption(QColorDialog.DontUseNativeDialog, True)
                for i, col in enumerate(swatches):
                    dlgc.setCustomColor(i, QColor(col))
                if dlgc.exec():
                    c = dlgc.currentColor()
                    if c.isValid():
                        default_color = c.name()
                        hex_edit.setText(default_color)
                        set_preview(default_color)

            btn_color.clicked.connect(pick_color)

            swatch_row = QHBoxLayout()
            for s in swatches:
                b = QPushButton()
                b.setFixedSize(18, 18)
                b.setStyleSheet(f"background:{s}; border:1px solid #555;")

                def select(checked=False, col=s):
                    nonlocal default_color
                    default_color = col
                    hex_edit.setText(col)
                    set_preview(col)

                b.clicked.connect(select)
                swatch_row.addWidget(b)
            swatch_row.addStretch(1)

            color_row = QHBoxLayout()
            color_row.addWidget(color_preview)
            color_row.addWidget(hex_edit)
            color_row.addWidget(btn_color)
            color_row.addStretch()
            lay.addLayout(color_row)
            lay.addLayout(swatch_row)

            freq_row = QHBoxLayout()
            freq_row.setContentsMargins(0, 0, 0, 0)
            lbl_freq = QLabel("Tần suất:")
            spn_freq_val = QSpinBox()
            spn_freq_val.setRange(1, 10000)
            spn_freq_val.setValue(int(existing.get("freq_value", 1) if existing else 1))
            cmb_freq_unit = QComboBox()
            cmb_freq_unit.addItem("Ngày", "day")
            cmb_freq_unit.addItem("Giờ", "hour")
            cmb_freq_unit.addItem("Phút", "minute")
            unit_val = str(existing.get("freq_unit", "day") if existing else "day")
            idx_unit = cmb_freq_unit.findData(unit_val)
            if idx_unit >= 0:
                cmb_freq_unit.setCurrentIndex(idx_unit)
            spn_freq_limit = QSpinBox()
            spn_freq_limit.setRange(1, 10000)
            spn_freq_limit.setValue(int(existing.get("freq_limit", 1) if existing else 1))
            freq_row.addWidget(lbl_freq)
            freq_row.addWidget(spn_freq_val)
            freq_row.addWidget(cmb_freq_unit)
            freq_row.addWidget(QLabel("x"))
            freq_row.addWidget(spn_freq_limit)
            freq_row.addStretch()

            font_row = QHBoxLayout()
            chk_bold = QCheckBox("In đậm")
            chk_bold.setChecked(bool(existing.get("bold") if existing else False))
            chk_italic = QCheckBox("Nghiêng")
            chk_italic.setChecked(bool(existing.get("italic") if existing else False))
            font_row.addWidget(chk_bold)
            font_row.addWidget(chk_italic)
            font_row.addStretch()
            lay.addLayout(font_row)

            chk_notify = QCheckBox("Gửi Telegram khi khớp rule này")
            chk_notify.setChecked(bool(existing.get("notify") if existing else False))
            lay.addWidget(chk_notify)
            file_row = QHBoxLayout()
            chk_notify_file = QCheckBox("Gửi file")
            chk_notify_file.setChecked(bool(existing.get("notify_file") if existing else False))
            file_row.addWidget(chk_notify_file)
            cmb_file_type = QComboBox()
            cmb_file_type.addItem("CSV (đầy đủ)", "csv")
            cmb_file_type.addItem("TXT (chỉ SĐT)", "txt")
            ft_val = str(existing.get("notify_file_type", "csv") if existing else "csv").lower()
            idx_ft = cmb_file_type.findData(ft_val)
            if idx_ft >= 0:
                cmb_file_type.setCurrentIndex(idx_ft)
            file_row.addWidget(cmb_file_type)
            file_row.addStretch()
            file_wrap = QWidget()
            file_wrap.setLayout(file_row)
            file_wrap.setVisible(chk_notify.isChecked())
            lay.addWidget(file_wrap)
            freq_wrap = QWidget()
            freq_wrap.setLayout(freq_row)
            freq_wrap.setVisible(chk_notify.isChecked() and chk_notify_file.isChecked())
            def toggle_notify(checked: bool):
                file_wrap.setVisible(checked)
                if checked and not chk_notify_file.isChecked():
                    chk_notify_file.setChecked(True)
                    if cmb_file_type.findData("csv") >= 0:
                        cmb_file_type.setCurrentIndex(cmb_file_type.findData("csv"))
                freq_wrap.setVisible(checked and chk_notify_file.isChecked())
            def toggle_file(checked: bool):
                freq_wrap.setVisible(chk_notify.isChecked() and checked)
            chk_notify.toggled.connect(toggle_notify)
            chk_notify_file.toggled.connect(toggle_file)
            lay.addWidget(freq_wrap)

            # Điều kiện phụ (AND)
            extras_lbl = QLabel("Điều kiện phụ (AND):")
            lay.addWidget(extras_lbl)
            extras_list = QListWidget()
            extras_list.setSelectionMode(QAbstractItemView.SingleSelection)
            extras: list[dict] = list(existing.get("extras", []) if existing else [])
            def refresh_extras():
                extras_list.clear()
                for ex in extras:
                    extras_list.addItem(self._summarize_alert_rule(ex, include_extras=False))
            refresh_extras()
            lay.addWidget(extras_list)

            def edit_extra(existing_ex: dict | None = None) -> dict | None:
                dlg3 = QDialog(dlg2)
                dlg3.setWindowTitle("Điều kiện phụ")
                lay3 = QVBoxLayout(dlg3)
                lay3.addWidget(QLabel("Cột:"))
                cmb_col_ex = QComboBox()
                cmb_col_ex.addItems(self.headers)
                if existing_ex and existing_ex.get("col") in self.headers:
                    cmb_col_ex.setCurrentText(existing_ex["col"])
                lay3.addWidget(cmb_col_ex)
                cond_row_ex = QHBoxLayout()
                cond_row_ex.addWidget(QLabel("Điều kiện:"))
                btn_ops_ex = QToolButton()
                btn_ops_ex.setText("✎")
                btn_ops_ex.setCursor(Qt.PointingHandCursor)
                btn_ops_ex.setToolTip("Sắp xếp / ẩn điều kiện")
                btn_ops_ex.clicked.connect(lambda: _open_ops_editor(cmb_op_ex))
                cond_row_ex.addWidget(btn_ops_ex)
                cond_row_ex.addStretch()
                lay3.addLayout(cond_row_ex)
                cmb_op_ex = QComboBox()
                fill_ops(cmb_op_ex)
                if existing_ex:
                    idx = cmb_op_ex.findData(existing_ex.get("op", "contains"))
                    if idx >= 0:
                        cmb_op_ex.setCurrentIndex(idx)
                lay3.addWidget(cmb_op_ex)
                lbl_v1 = QLabel("Giá trị:")
                lay3.addWidget(lbl_v1)
                edt_v1 = QLineEdit(existing_ex.get("value", "") if existing_ex else "")
                lay3.addWidget(edt_v1)
                lbl_v2 = QLabel("Giá trị 2 (Giữa/±x mốc+y):")
                lay3.addWidget(lbl_v2)
                edt_v2 = QLineEdit(existing_ex.get("value2", "") if existing_ex else "")
                lay3.addWidget(edt_v2)
                def refresh_v():
                    key = cmb_op_ex.currentData()
                    needs_v1 = key not in {"empty", "not_empty", "month_current", "year_current"}
                    needs_v2 = key in {"between", "not_between", "days_equal_pivot", "days_before_pivot", "days_after_pivot"}
                    edt_v1.setVisible(needs_v1); lbl_v1.setVisible(needs_v1)
                    edt_v2.setVisible(needs_v2); lbl_v2.setVisible(needs_v2)
                    if key in {"date_is", "date_before", "date_after"}:
                        lbl_v1.setText("Ngày:"); edt_v1.setPlaceholderText("dd/MM/yyyy")
                    elif key in {"days_equal", "days_before_eq", "days_after_eq"}:
                        lbl_v1.setText("Số ngày:"); edt_v1.setPlaceholderText("Số ngày (vd 5)")
                        lbl_v2.setText("Giá trị 2:"); edt_v2.setPlaceholderText("")
                    elif key in {"days_equal_pivot", "days_before_pivot", "days_after_pivot"}:
                        lbl_v1.setText("x ngày (cảnh báo):"); lbl_v2.setText("y ngày (cộng vào mốc):")
                        edt_v1.setPlaceholderText("x (vd 5)"); edt_v2.setPlaceholderText("y (vd 45)")
                    elif key == "in_list":
                        lbl_v1.setText("Danh sách:"); edt_v1.setPlaceholderText("VNMB, LOCAL,...")
                        lbl_v2.setText("Giá trị 2:"); edt_v2.setPlaceholderText("")
                    elif key == "month_is":
                        lbl_v1.setText("Tháng:"); edt_v1.setPlaceholderText("Tháng (1-12)")
                    elif key == "year_is":
                        lbl_v1.setText("Năm:"); edt_v1.setPlaceholderText("Năm (vd 2026)")
                    elif key == "custom":
                        lbl_v1.setText("Biểu thức:"); edt_v1.setPlaceholderText("val, text, num, date, today")
                    else:
                        lbl_v1.setText("Giá trị:"); edt_v1.setPlaceholderText(""); lbl_v2.setText("Giá trị 2:")
                cmb_op_ex.currentIndexChanged.connect(lambda _: refresh_v())
                refresh_v()
                btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
                lay3.addWidget(btns)
                btns.accepted.connect(dlg3.accept); btns.rejected.connect(dlg3.reject)
                if dlg3.exec() == QDialog.Accepted:
                    return {
                        "col": cmb_col_ex.currentText(),
                        "col_idx": cmb_col_ex.currentIndex(),
                        "op": cmb_op_ex.currentData(),
                        "value": edt_v1.text().strip(),
                        "value2": edt_v2.text().strip(),
                    }
                return None

            def add_extra():
                ex = edit_extra()
                if ex:
                    extras.append(ex); refresh_extras()
            def edit_extra_item():
                row = extras_list.currentRow()
                if row < 0 or row >= len(extras):
                    return
                ex = edit_extra(extras[row])
                if ex:
                    extras[row] = ex; refresh_extras()
            def del_extra():
                row = extras_list.currentRow()
                if row < 0 or row >= len(extras):
                    return
                extras.pop(row); refresh_extras()

            btn_ex_row = QHBoxLayout()
            btn_ex_add = QPushButton("Thêm điều kiện")
            btn_ex_edit = QPushButton("Sửa")
            btn_ex_del = QPushButton("Xóa")
            btn_ex_add.clicked.connect(add_extra)
            btn_ex_edit.clicked.connect(edit_extra_item)
            btn_ex_del.clicked.connect(del_extra)
            btn_ex_row.addWidget(btn_ex_add); btn_ex_row.addWidget(btn_ex_edit); btn_ex_row.addWidget(btn_ex_del); btn_ex_row.addStretch()
            lay.addLayout(btn_ex_row)

            btn_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            lay.addWidget(btn_box)

            def refresh_fields():
                key = cmb_op.currentData()
                needs_v1 = key not in {"empty", "not_empty", "month_current", "year_current"}
                needs_v2 = key in {"between", "not_between", "days_equal_pivot", "days_before_pivot", "days_after_pivot"}
                edt_val.setVisible(needs_v1)
                edt_val2.setVisible(needs_v2)
                lbl_val.setVisible(needs_v1)
                lbl_val2.setVisible(needs_v2)
                if key in {"date_is", "date_before", "date_after"}:
                    lbl_val.setText("Ngày:")
                    edt_val.setPlaceholderText("dd/MM/yyyy")
                elif key in {"days_equal", "days_before_eq", "days_after_eq"}:
                    lbl_val.setText("Số ngày:")
                    edt_val.setPlaceholderText("Số ngày (vd 5)")
                    lbl_val2.setText("Giá trị 2:")
                    edt_val2.setPlaceholderText("")
                elif key in {"days_equal_pivot", "days_before_pivot", "days_after_pivot"}:
                    lbl_val.setText("x ngày (cảnh báo):")
                    lbl_val2.setText("y ngày (cộng vào mốc):")
                    edt_val.setPlaceholderText("x (vd 5)")
                    edt_val2.setPlaceholderText("y (vd 45)")
                elif key == "in_list":
                    lbl_val.setText("Danh sách:")
                    edt_val.setPlaceholderText("VNMB, LOCAL,...")
                    edt_val2.setPlaceholderText("")
                elif key == "month_is":
                    lbl_val.setText("Tháng:")
                    edt_val.setPlaceholderText("Tháng (1-12)")
                elif key == "year_is":
                    lbl_val.setText("Năm:")
                    edt_val.setPlaceholderText("Năm (vd 2026)")
                elif key == "custom":
                    lbl_val.setText("Biểu thức:")
                    edt_val.setPlaceholderText("val, text, num, date, today có sẵn")
                else:
                    lbl_val.setText("Giá trị:")
                    edt_val.setPlaceholderText("")
                    edt_val2.setPlaceholderText("")

            cmb_op.currentIndexChanged.connect(lambda _: refresh_fields())
            refresh_fields()

            btn_box.accepted.connect(dlg2.accept)
            btn_box.rejected.connect(dlg2.reject)
            if dlg2.exec() == QDialog.Accepted:
                apply_hex()
                return {
                    "col": cmb_col.currentText(),
                    "col_idx": cmb_col.currentIndex(),
                    "op": cmb_op.currentData(),
                    "value": edt_val.text().strip(),
                    "value2": edt_val2.text().strip(),
                    "color": default_color,
                    "notify": chk_notify.isChecked(),
                    "notify_file": chk_notify_file.isChecked() if chk_notify.isChecked() else False,
                    "notify_file_type": cmb_file_type.currentData() if chk_notify_file.isChecked() and chk_notify.isChecked() else "csv",
                    "bold": chk_bold.isChecked(),
                    "italic": chk_italic.isChecked(),
                    "freq_value": spn_freq_val.value(),
                    "freq_unit": cmb_freq_unit.currentData(),
                    "freq_limit": spn_freq_limit.value(),
                    "extras": extras,
                    "id": existing.get("id") if existing and existing.get("id") else uuid.uuid4().hex,
                }
            return None

        def add_rule():
            r = edit_rule()
            if r:
                self.alert_rules.append(r)
                it = QListWidgetItem()
                _apply_item_style(it, r)
                lst.addItem(it)
                nonlocal_need_reset[0] = True

        def do_edit():
            row = lst.currentRow()
            if row < 0 or row >= len(self.alert_rules):
                return
            r = edit_rule(self.alert_rules[row])
            if r:
                self.alert_rules[row] = r
                it = lst.item(row)
                _apply_item_style(it, r)
                nonlocal_need_reset[0] = True

        def do_del():
            row = lst.currentRow()
            if row < 0 or row >= len(self.alert_rules):
                return
            del self.alert_rules[row]
            lst.takeItem(row)
            nonlocal_need_reset[0] = True

        def do_dup():
            row = lst.currentRow()
            if row < 0 or row >= len(self.alert_rules):
                return
            cloned = copy.deepcopy(self.alert_rules[row])
            if isinstance(cloned, dict):
                cloned["id"] = uuid.uuid4().hex
            self.alert_rules.append(cloned)
            it = QListWidgetItem()
            _apply_item_style(it, cloned)
            lst.addItem(it)
            lst.setCurrentRow(lst.count() - 1)
            nonlocal_need_reset[0] = True

        def do_save_tpl():
            if not self.alert_rules:
                QMessageBox.information(dlg, "Lưu mẫu", "Chưa có điều kiện để lưu.")
                return
            name, ok = QInputDialog.getText(dlg, "Lưu mẫu cảnh báo", "Tên mẫu:")
            if not ok:
                return
            name = name.strip()
            if not name:
                return
            snapshot = {
                "name": name,
                "rules": copy.deepcopy(self.alert_rules),
                "send_enabled": bool(chk_send.isChecked()),
            }
            found = False
            for tpl in self.alert_templates:
                if tpl.get("name", "").lower() == name.lower():
                    tpl.update(snapshot)
                    found = True
                    break
            if not found:
                self.alert_templates.append(snapshot)
            self._save_state()
            _refresh_tpl_menu()
            QMessageBox.information(dlg, "Lưu mẫu", f"Đã lưu mẫu '{name}'.")

        btn_add.clicked.connect(add_rule)
        btn_edit.clicked.connect(do_edit)
        btn_del.clicked.connect(do_del)
        btn_dup.clicked.connect(do_dup)
        btn_save_tpl.clicked.connect(do_save_tpl)
        lst.itemDoubleClicked.connect(lambda _: do_edit())
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)

        if dlg.exec() == QDialog.Accepted:
            self.alert_send_enabled = chk_send.isChecked()
            if nonlocal_need_reset[0]:
                self.alert_sent_map.clear()
                self.alert_try_map.clear()
            # lưu vào snapshot mẫu và state
            self._persist_now()
            QTimer.singleShot(300, self._scan_alerts_and_send)
        self.table.viewport().update()

    def _match_alert_rule(self, rule: dict, val: Any, col_name: str = "") -> bool:
        op = rule.get("op", "contains")
        text = "" if pd.isna(val) else str(val).strip()
        val1 = rule.get("value", "")
        val2 = rule.get("value2", "")
        today = QDate.currentDate()
        cell_date = QDate.fromString(text, "dd/MM/yyyy")
        num = None
        try:
            num = float(str(val).replace(",", ""))
        except Exception:
            num = None

        if op == "empty":
            return text == ""
        if op == "not_empty":
            return text != ""
        if op == "contains":
            return val1.lower() in text.lower()
        if op == "not_contains":
            return val1.lower() not in text.lower()
        if op == "in_list":
            items = [p.strip() for p in str(val1).replace("\n", ",").split(",") if p.strip()]
            if not items:
                return False
            t = text.lower()
            return any(t == it.lower() for it in items)
        if op == "startswith":
            return text.lower().startswith(val1.lower())
        if op == "endswith":
            return text.lower().endswith(val1.lower())
        if op in {"equals", "notequals"}:
            # ưu tiên so sánh số nếu cả hai parse được
            try:
                num_lhs = float(str(val).replace(",", ""))
                num_rhs = float(str(val1).replace(",", ""))
                return (num_lhs == num_rhs) if op == "equals" else (num_lhs != num_rhs)
            except Exception:
                return (text == val1) if op == "equals" else (text != val1)

        # number/date compare
        if op in {"gt", "gte", "lt", "lte", "eq", "neq", "between", "not_between"}:
            # prefer date if parseable
            if cell_date.isValid():
                d1 = QDate.fromString(str(val1).strip(), "dd/MM/yyyy")
                d2 = QDate.fromString(str(val2).strip(), "dd/MM/yyyy")
                if not d1.isValid():
                    return False
                if op == "gt":
                    return cell_date > d1
                if op == "gte":
                    return cell_date >= d1
                if op == "lt":
                    return cell_date < d1
                if op == "lte":
                    return cell_date <= d1
                if op == "eq":
                    return cell_date == d1
                if op == "neq":
                    return cell_date != d1
                if op in {"between", "not_between"}:
                    if not d2.isValid():
                        return False
                    lo, hi = sorted([d1, d2])
                    inside = lo <= cell_date <= hi
                    return inside if op == "between" else not inside
            if num is None:
                return False
            try:
                v1 = float(str(val1).replace(",", ""))
                v2 = float(str(val2).replace(",", "")) if val2 else None
            except Exception:
                return False
            if op == "gt":
                return num > v1
            if op == "gte":
                return num >= v1
            if op == "lt":
                return num < v1
            if op == "lte":
                return num <= v1
            if op == "eq":
                return num == v1
            if op == "neq":
                return num != v1
            if op in {"between", "not_between"}:
                if v2 is None:
                    return False
                lo, hi = sorted([v1, v2])
                inside = lo <= num <= hi
                return inside if op == "between" else not inside

        if op == "date_is":
            d1 = QDate.fromString(str(val1).strip(), "dd/MM/yyyy")
            return cell_date.isValid() and d1.isValid() and cell_date == d1
        if op == "date_before":
            d1 = QDate.fromString(str(val1).strip(), "dd/MM/yyyy")
            return cell_date.isValid() and d1.isValid() and cell_date < d1
        if op == "date_after":
            d1 = QDate.fromString(str(val1).strip(), "dd/MM/yyyy")
            return cell_date.isValid() and d1.isValid() and cell_date > d1
        if op in {"days_equal", "days_before_eq", "days_after_eq"}:
            if not cell_date.isValid():
                return False
            try:
                days = int(str(val1).replace(",", ""))
            except Exception:
                return False
            diff = today.daysTo(cell_date)  # + nếu cell ở tương lai, - nếu quá khứ
            if op == "days_equal":
                return abs(diff) == days
            if op == "days_before_eq":
                return diff == -days
            if op == "days_after_eq":
                return diff == days
        if op in {"days_equal_pivot", "days_before_pivot", "days_after_pivot"}:
            if not cell_date.isValid():
                return False
            try:
                x = int(str(val1).replace(",", ""))
                y = int(str(val2).replace(",", ""))
            except Exception:
                return False
            target = cell_date.addDays(y)
            diff = today.daysTo(target)  # >0 nếu mốc ở tương lai, <0 nếu đã qua
            if op == "days_equal_pivot":
                return abs(diff) <= x
            if op == "days_before_pivot":
                return 0 <= diff <= x  # cảnh báo trước mốc
            if op == "days_after_pivot":
                return -x <= diff <= 0  # cảnh báo sau mốc
        if op == "month_is":
            if not cell_date.isValid():
                return False
            try:
                month = int(val1)
            except Exception:
                return False
            return cell_date.month() == month
        if op == "year_is":
            if not cell_date.isValid():
                return False
            try:
                year = int(val1)
            except Exception:
                return False
            return cell_date.year() == year
        if op == "month_current":
            return cell_date.isValid() and cell_date.month() == today.month() and cell_date.year() == today.year()
        if op == "year_current":
            return cell_date.isValid() and cell_date.year() == today.year()
        if op == "custom":
            try:
                env = {
                    "val": val,
                    "text": text,
                    "num": num,
                    "date": cell_date if cell_date.isValid() else None,
                    "today": today,
                    "QDate": QDate,
                }
                return bool(eval(val1, {"__builtins__": {}}, env))
            except Exception:
                return False
        return False

    def _match_full_rule(self, rule: dict, row_idx: int, main_col_idx: int, main_col_name: str) -> bool:
        try:
            main_val = self.rows[row_idx][main_col_idx]
        except Exception:
            return False
        if not self._match_alert_rule(rule, main_val, main_col_name):
            return False
        extras = rule.get("extras") or []
        if not extras:
            return True
        for ex in extras:
            ex_col_idx = ex.get("col_idx")
            if ex_col_idx is not None:
                try:
                    ex_col_idx = int(ex_col_idx)
                except Exception:
                    ex_col_idx = None
            if ex_col_idx is None:
                ex_col = str(ex.get("col", "") or "")
                if ex_col:
                    norm = self._normalize_header_name(ex_col)
                    for j, h in enumerate(self.headers):
                        if h == ex_col or self._normalize_header_name(h) == norm:
                            ex_col_idx = j
                            break
            if ex_col_idx is None or ex_col_idx < 0 or ex_col_idx >= len(self.headers):
                return False
            if ex_col_idx >= len(self.rows[row_idx]):
                return False
            ex_val = self.rows[row_idx][ex_col_idx]
            ex_col_name = self.headers[ex_col_idx] if 0 <= ex_col_idx < len(self.headers) else ""
            if not self._match_alert_rule(ex, ex_val, ex_col_name):
                return False
        return True

    def _row_key(self, row_idx: int) -> str:
        try:
            return "|".join("" if pd.isna(v) else str(v).strip() for v in self.rows[row_idx])
        except Exception:
            return str(row_idx)

    def _telegram_send_message(self, text: str) -> tuple[bool, str]:
        token = self.alert_bot_token.strip()
        chat_id = self.alert_chat_id.strip()
        if not (token and chat_id):
            return False, "Thiếu token/chat_id (tab Cài đặt)"
        try:
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
            req = urllib.request.Request(url, data=data)
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode("utf-8", errors="ignore")
            try:
                js = json.loads(body or "{}")
                if js.get("ok") is True:
                    return True, ""
                return False, str(js.get("description") or body[:200] or "Telegram error")
            except Exception:
                # Nếu parse JSON fail nhưng không raise HTTPError thì coi như OK
                return True, ""
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8", errors="ignore")
            except Exception:
                body = ""
            code = getattr(exc, "code", "")
            msg = f"HTTP {code}".strip()
            if body:
                msg += f": {body[:200]}"
            return False, msg
        except Exception as exc:
            return False, str(exc)

    def _send_telegram_alert(self, row_idx: int, rule: dict) -> bool:
        try:
            parts = [str(v).strip() for v in self.rows[row_idx]]
        except Exception:
            parts = []
        # Tin nhắn ngắn gọn, chỉ mô tả điều kiện chính (không kèm style/freq)
        text = f"Cảnh báo: {self._summarize_alert_rule(rule, include_extras=False, include_meta=False)}"

        ok, err = self._telegram_send_message(text)
        if not ok:
            self._telegram_last_error = err
        return ok

    def _format_alert_csv_cell(self, val: Any, col_idx: int) -> str:
        """Giữ nguyên chuỗi, và tránh Excel tự đổi sang số khoa học cho dãy dài."""
        # Nếu là cột SĐT -> chuẩn hóa về số đầy đủ và bọc công thức giữ nguyên
        phone_idx = self._find_phone_column(self.headers) if hasattr(self, "headers") else None
        if phone_idx is not None and col_idx == phone_idx:
            norm = self._normalize_phone_value(val)
            if norm:
                return f'="{norm}"'
        s = "" if pd.isna(val) else str(val)
        digits_only = re.fullmatch(r"[0-9]+", s)
        if not digits_only:
            # thử loại bỏ dấu chấm/thanh ngăn cách để xử lý các chuỗi 0xxx.xxx
            stripped = re.sub(r"[^0-9]", "", s)
            if stripped:
                s_digits = stripped
            else:
                return s
        else:
            s_digits = s
        digits_only = re.fullmatch(r"[0-9]+", s)
        if digits_only and len(s) >= 10:
            return f'="{s}"'
        if s_digits != s and len(s_digits) >= 10:
            return f'="{s_digits}"'
        return s

    def _alert_window_id(self, rule: dict) -> str:
        """Id cửa sổ tần suất, ví dụ day:1:19873 hoặc hour:2:357890."""
        now = datetime.now()
        unit = str(rule.get("freq_unit") or "day").lower()
        try:
            span = max(1, int(rule.get("freq_value", 1)))
        except Exception:
            span = 1
        if unit.startswith("min"):
            minutes = int(now.timestamp() // 60)
            idx = minutes // span
            return f"min:{span}:{idx}"
        if unit.startswith("gi") or unit.startswith("hour") or unit == "h":
            hours = int(now.timestamp() // 3600)
            idx = hours // span
            return f"hour:{span}:{idx}"
        days = int(now.timestamp() // 86400)
        idx = days // span
        return f"day:{span}:{idx}"

    def _can_send_alert(self, key: str, rule: dict, ignore_freq: bool = False) -> bool:
        if ignore_freq:
            return True
        window_id = self._alert_window_id(rule)
        entry = self.alert_sent_map.get(key)
        try:
            limit = int(rule.get("freq_limit", 1))
        except Exception:
            limit = 1
        if limit <= 0:
            limit = 1
        if isinstance(entry, dict):
            if entry.get("win") == window_id and int(entry.get("count", 0)) >= limit:
                return False
        return True

    def _mark_alert_sent(self, key: str, rule: dict) -> None:
        window_id = self._alert_window_id(rule)
        entry = self.alert_sent_map.get(key)
        if isinstance(entry, dict) and entry.get("win") == window_id:
            count = int(entry.get("count", 0)) + 1
        else:
            count = 1
        self.alert_sent_map[key] = {"win": window_id, "count": count}
        # lưu ngay để lần mở sau không gửi trùng
        self._save_state()

    def _send_telegram_file_batch(self, rule_idx: int, row_indices: list[int]) -> tuple[bool, str]:
        """Gửi một file chứa nhiều dòng cho cùng rule."""
        if not row_indices:
            return True, ""
        rule = self.alert_rules[rule_idx]
        caption = f"Cảnh báo: {self._summarize_alert_rule(rule, include_extras=True, include_meta=False)}"
        ftype = str(rule.get("notify_file_type") or "csv").lower()
        try:
            total = len(row_indices)
            if ftype.startswith("t"):  # txt: chỉ list SĐT mỗi dòng
                phones = []
                phone_idx = self._find_phone_column(self.headers)
                for r in row_indices:
                    if 0 <= r < len(self.rows):
                        val = self.rows[r][phone_idx] if (phone_idx is not None and phone_idx < len(self.rows[r])) else ""
                        norm = self._normalize_phone_value(val)
                        if norm:
                            phones.append(norm)
                content = ("\n".join(phones) + "\n").encode("utf-8-sig")
                filename = f"alert_rule{rule_idx+1}_total{total}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                return self._telegram_send_document(filename, content, caption)
            else:  # csv đầy đủ
                buf = io.StringIO()
                writer = csv.writer(buf)
                writer.writerow(self.headers)
                for r in row_indices:
                    if 0 <= r < len(self.rows):
                        row_fmt = [self._format_alert_csv_cell(v, idx) for idx, v in enumerate(self.rows[r])]
                        writer.writerow(row_fmt)
                csv_bytes = buf.getvalue().encode("utf-8-sig")
                filename = f"alert_rule{rule_idx+1}_total{len(row_indices)}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                return self._telegram_send_document(filename, csv_bytes, caption)
        except Exception as exc:
            return False, str(exc)

    def _telegram_get_updates(self, token: str) -> tuple[bool, str, List[dict]]:
        token = str(token or "").strip()
        if not token:
            return False, "Chưa nhập token bot", []
        try:
            qs = urllib.parse.urlencode({"timeout": 0, "limit": 100})
            url = f"https://api.telegram.org/bot{token}/getUpdates?{qs}"
            with urllib.request.urlopen(url, timeout=10) as resp:
                body = resp.read().decode("utf-8", errors="ignore")
            try:
                js = json.loads(body or "{}")
            except Exception:
                return False, body[:200] or "Không đọc được phản hồi Telegram", []
            if js.get("ok") is True:
                res = js.get("result", [])
                return True, "", res if isinstance(res, list) else []
            return False, str(js.get("description") or body[:200] or "Telegram error"), []
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read().decode("utf-8", errors="ignore")
            except Exception:
                body = ""
            code = getattr(exc, "code", "")
            msg = f"HTTP {code}".strip()
            if body:
                msg += f": {body[:200]}"
            return False, msg, []
        except Exception as exc:
            return False, str(exc), []

    def _telegram_send_document(self, filename: str, data: bytes, caption: str = "") -> tuple[bool, str]:
        token = self.alert_bot_token.strip()
        chat_id = self.alert_chat_id.strip()
        if not (token and chat_id):
            return False, "Thiếu token/chat_id (tab Cài đặt)"
        boundary = "----MXHsimBoundary" + uuid.uuid4().hex
        parts: list[bytes] = []

        def add_field(name: str, value: str):
            parts.append(f"--{boundary}\r\n".encode("utf-8"))
            parts.append(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode("utf-8"))
            parts.append(value.encode("utf-8"))
            parts.append(b"\r\n")

        def add_file(name: str, filename: str, content: bytes, content_type: str = "application/octet-stream"):
            parts.append(f"--{boundary}\r\n".encode("utf-8"))
            parts.append(
                f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'.encode("utf-8")
            )
            parts.append(f"Content-Type: {content_type}\r\n\r\n".encode("utf-8"))
            parts.append(content)
            parts.append(b"\r\n")

        add_field("chat_id", chat_id)
        if caption:
            add_field("caption", caption)
        add_file("document", filename, data, "text/csv")
        parts.append(f"--{boundary}--\r\n".encode("utf-8"))
        body = b"".join(parts)
        url = f"https://api.telegram.org/bot{token}/sendDocument"
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        req.add_header("Content-Length", str(len(body)))
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                resp_body = resp.read().decode("utf-8", errors="ignore")
            try:
                js = json.loads(resp_body or "{}")
                if js.get("ok") is True:
                    return True, ""
                return False, str(js.get("description") or resp_body[:200] or "Telegram error")
            except Exception:
                return True, ""
        except urllib.error.HTTPError as exc:
            try:
                body_err = exc.read().decode("utf-8", errors="ignore")
            except Exception:
                body_err = ""
            code = getattr(exc, "code", "")
            msg = f"HTTP {code}".strip()
            if body_err:
                msg += f": {body_err[:200]}"
            return False, msg
        except Exception as exc:
            return False, str(exc)

    def _telegram_extract_chats(self, updates: List[dict]) -> List[dict]:
        chats_by_id: dict[str, dict] = {}
        for upd in updates:
            if not isinstance(upd, dict):
                continue
            msg = None
            for k in ("message", "channel_post", "edited_message", "edited_channel_post"):
                v = upd.get(k)
                if isinstance(v, dict):
                    msg = v
                    break
            if not msg:
                continue
            chat = msg.get("chat")
            if not isinstance(chat, dict):
                continue
            cid = chat.get("id")
            if cid is None:
                continue
            cid_s = str(cid).strip()
            ctype = str(chat.get("type") or "").strip()
            name = str(chat.get("title") or "").strip()
            if not name:
                username = str(chat.get("username") or "").strip()
                if username:
                    name = "@" + username
                else:
                    fn = str(chat.get("first_name") or "").strip()
                    ln = str(chat.get("last_name") or "").strip()
                    name = (fn + " " + ln).strip()
            if not name:
                name = "(không tên)"
            label = f"{cid_s} - {name}"
            if ctype:
                label += f" ({ctype})"
            chats_by_id[cid_s] = {"id": cid_s, "name": name, "type": ctype, "label": label}
        return sorted(chats_by_id.values(), key=lambda x: (x.get("type", ""), x.get("name", ""), x.get("id", "")))

    def _pick_telegram_chat_from_updates(self, token: str) -> Optional[dict]:
        token = str(token or "").strip()
        if not token:
            QMessageBox.warning(self, "Telegram", "Chưa nhập Token Bot trong tab Cài đặt.")
            return None
        ok, err, updates = self._telegram_get_updates(token)
        if not ok:
            QMessageBox.warning(self, "Telegram", f"Không load được getUpdates:\n{err}")
            return None
        chats = self._telegram_extract_chats(updates)
        if not chats:
            QMessageBox.information(
                self,
                "Telegram",
                "Không thấy chat nào trong getUpdates.\n\nHãy nhắn /start cho bot (chat riêng) hoặc gửi 1 tin trong nhóm có bot, rồi thử lại.",
            )
            return None

        dlg = QDialog(self)
        dlg.setWindowTitle("Chọn chatID")
        vbox = QVBoxLayout(dlg)
        info = QLabel("Chọn chat_id để dùng khi gửi cảnh báo Telegram.")
        info.setStyleSheet("color:#9ca3af;")
        vbox.addWidget(info)
        lst = QListWidget()
        for c in chats:
            item = QListWidgetItem(str(c.get("label") or c.get("id") or ""))
            item.setData(Qt.UserRole, c)
            lst.addItem(item)
        vbox.addWidget(lst)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)
        vbox.addWidget(buttons)
        lst.itemDoubleClicked.connect(lambda _: dlg.accept())
        if lst.count() > 0:
            cur = str(getattr(self, "alert_chat_id", "") or "").strip()
            picked_row = 0
            if cur:
                for i in range(lst.count()):
                    it = lst.item(i)
                    data = it.data(Qt.UserRole) if it else None
                    if isinstance(data, dict) and str(data.get("id") or "").strip() == cur:
                        picked_row = i
                        break
            lst.setCurrentRow(picked_row)
        if dlg.exec() == QDialog.Accepted:
            it = lst.currentItem()
            if it:
                picked = it.data(Qt.UserRole)
                if isinstance(picked, dict) and picked.get("id"):
                    return picked
        return None

    def _scan_alerts_and_send(
        self,
        force: bool = False,
        ignore_freq: bool = False,
        rule_indices: Optional[set[int]] = None,
    ) -> None:
        """Quét toàn bộ bảng và gửi Telegram cho các rule đang khớp.

        `force=True` bỏ qua cờ bật/tắt alert_send_enabled (dùng cho nút Test cảnh báo).
        `ignore_freq=True` bỏ qua giới hạn tần suất (gửi ngay, dùng cho test).
        `rule_indices` giới hạn danh sách rule cần quét (None = tất cả).
        Tách khỏi `_alert_color()` để tránh gọi network trong lúc paint/repaint.
        """
        try:
            if not self.alert_rules:
                return
            self._ensure_alert_rule_ids()
            # Chỉ cảnh báo khi bật Telegram + rule được tích gửi file
            if not force and not self.alert_send_enabled:
                return
            if not self.headers or not self.rows:
                return

            matched_rows: set[int] = set()
            for idx, rule in enumerate(self.alert_rules):
                if rule_indices is not None and idx not in rule_indices:
                    continue
                if not rule.get("notify") or not rule.get("notify_file"):
                    continue

                rule_id = str(rule.get("id") or idx)
                col_idx = rule.get("col_idx")
                if col_idx is not None:
                    try:
                        col_idx = int(col_idx)
                    except Exception:
                        col_idx = None

                if col_idx is None:
                    rule_col = str(rule.get("col", "") or "")
                    if rule_col:
                        norm = self._normalize_header_name(rule_col)
                        for j, h in enumerate(self.headers):
                            if h == rule_col or self._normalize_header_name(h) == norm:
                                col_idx = j
                                break

                if col_idx is None or col_idx < 0 or col_idx >= len(self.headers):
                    continue

                col_name = self.headers[col_idx] if 0 <= col_idx < len(self.headers) else ""
                pending_rows: list[int] = []
                for row_idx, row in enumerate(self.rows):
                    if row_idx in matched_rows:
                        continue
                    if col_idx >= len(row):
                        continue
                    val = row[col_idx]
                    try:
                        if not self._match_full_rule(rule, row_idx, col_idx, col_name):
                            continue
                    except Exception:
                        continue

                    matched_rows.add(row_idx)  # ưu tiên rule trên: khóa các rule sau
                    key = f"{self._row_key(row_idx)}|{rule_id}"
                    if self._can_send_alert(key, rule, ignore_freq=ignore_freq):
                        pending_rows.append(row_idx)
                        # tạm thời đánh dấu lần thử để tránh lặp trong cùng đợt
                        self.alert_try_map[key] = time.time()

                if not pending_rows:
                    continue

                if rule.get("notify_file"):
                    ok, err = self._send_telegram_file_batch(idx, pending_rows)
                    if ok:
                        for row_idx in pending_rows:
                            key = f"{self._row_key(row_idx)}|{rule_id}"
                            self._mark_alert_sent(key, rule)
                    else:
                        self._telegram_last_error = err
                else:
                    for row_idx in pending_rows:
                        key = f"{self._row_key(row_idx)}|{rule_id}"
                        if self._send_telegram_alert(row_idx, rule):
                            self._mark_alert_sent(key, rule)
        except Exception:
            # timer callback phải luôn an toàn
            pass

    def _alert_color(self, row_idx: int, col_idx: int, val: Any) -> Optional[QColor]:
        if not self.alert_rules:
            return None
        col_name = self.headers[col_idx] if 0 <= col_idx < len(self.headers) else ""
        norm_col = self._normalize_header_name(col_name)
        for idx, rule in enumerate(self.alert_rules):
            rule_col = rule.get("col", "")
            rule_col_idx = rule.get("col_idx")
            if rule_col_idx is not None:
                try:
                    if int(rule_col_idx) != col_idx:
                        continue
                except Exception:
                    continue
            elif rule_col != col_name and self._normalize_header_name(rule_col) != norm_col:
                continue
            try:
                if self._match_full_rule(rule, row_idx, col_idx, col_name):
                    color = QColor(rule.get("color", "#fff2cc"))
                    style_flags = {
                        "bg": color if color.isValid() else QColor("#fff2cc"),
                        "bold": bool(rule.get("bold")),
                        "italic": bool(rule.get("italic")),
                    }
                    return style_flags
            except Exception:
                continue
        return None

    def _export_stats_filtered(self) -> None:
        """Xuất ra Excel danh sách dòng theo bộ lọc thống kê hiện tại."""
        rows = getattr(self, "_stats_filtered_rows", [])
        headers = getattr(self, "_stats_filtered_headers", [])
        if not rows or not headers:
            QMessageBox.information(self, "Xuất Excel", "Không có dữ liệu sau khi lọc để xuất.")
            return
        default_dir = self.current_path.parent if hasattr(self, "current_path") else Path(".")
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Xuất dữ liệu đã lọc",
            str(default_dir / "thong_ke_loc.xlsx"),
            "Excel Files (*.xlsx);;All Files (*)",
        )
        if not path:
            return
        try:
            df = pd.DataFrame(rows, columns=headers)
            df.to_excel(path, index=False)
            self._status(f"Đã xuất {len(rows)} dòng ra {path}")
        except Exception as exc:
            QMessageBox.warning(self, "Lỗi xuất Excel", f"Không thể ghi file:\n{exc}")

    def _apply_state(self, state: dict) -> None:
        self.headers = list(state.get("headers", []))
        self.source_headers = list(state.get("source_headers", []))
        self.rows_all = copy.deepcopy(state.get("rows", []))
        self.rows = list(self.rows_all)
        self.row_histories = copy.deepcopy(state.get("row_histories", [[] for _ in self.rows_all]))
        self.cell_styles = copy.deepcopy(state.get("cell_styles", {}))
        self.row_height = int(state.get("row_height", self.row_height))
        self.hidden_columns = set(state.get("hidden_columns", []))
        self._ensure_source_column()
        self._ensure_change_column()
        self._ensure_row_histories()
        self._set_model(self.headers, self.rows, auto_resize=False)

    def _undo(self) -> None:
        if not self.undo_stack:
            return
        state = self.undo_stack.pop()
        self.redo_stack.append(self._create_state_snapshot())
        if len(self.redo_stack) > 20:
            self.redo_stack.pop(0)
        self._undoing = True
        self._apply_state(state)
        self._persist_now()
        self._undoing = False

    def _redo(self) -> None:
        if not self.redo_stack:
            return
        state = self.redo_stack.pop()
        self.undo_stack.append(self._create_state_snapshot())
        if len(self.undo_stack) > 20:
            self.undo_stack.pop(0)
        self._undoing = True
        self._apply_state(state)
        self._persist_now()
        self._undoing = False

    def _record_session(self, force: bool = False) -> None:
        if not self.current_path:
            return
        now = datetime.now()
        last_entry = self.session_history[0] if self.session_history else None
        if not force and last_entry:
            try:
                last_time = datetime.fromisoformat(last_entry.get("time", ""))
            except Exception:
                last_time = None
            if (
                last_time
                and (now - last_time) < timedelta(minutes=30)
                and last_entry.get("path") == str(self.current_path)
            ):
                return
        snapshot_path = self._write_history_snapshot(now)
        if not snapshot_path:
            return
        entry = {
            "path": str(self.current_path),
            "time": now.isoformat(),
            "snapshot": str(snapshot_path),
        }
        self.session_history.insert(0, entry)
        self._reset_history_countdown(now)
        cutoff = now - timedelta(days=3)
        filtered = []
        for h in self.session_history:
            try:
                t = datetime.fromisoformat(h.get("time", ""))
            except Exception:
                continue
            if t >= cutoff:
                filtered.append(h)
        kept = filtered[:20]
        removed = [h for h in self.session_history if h not in kept]
        self.session_history = kept
        for h in removed:
            snap = h.get("snapshot")
            if snap:
                try:
                    Path(snap).unlink(missing_ok=True)
                except Exception:
                    pass
        self._save_state()

    def _write_history_snapshot(self, now: datetime) -> Optional[Path]:
        try:
            HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            return None
        stamp = now.strftime("%Y%m%d_%H%M%S")
        base = HISTORY_DIR / f"session_{stamp}.json"
        path = base
        counter = 1
        while path.exists():
            path = HISTORY_DIR / f"session_{stamp}_{counter}.json"
            counter += 1
        self._ensure_row_histories()
        widths = {}
        if self.table.model():
            for col in range(self.table.model().columnCount()):
                widths[str(col)] = self.table.columnWidth(col)
        snapshot = {
            "time": now.isoformat(),
            "path": str(self.current_path),
            "headers": list(self.headers),
            "source_headers": list(self.source_headers),
            "rows": copy.deepcopy(self.rows_all),
            "column_widths": widths,
            "column_align": {k: int(v) for k, v in self.alignment_map.items()},
            "filters": {str(k): v for k, v in self.filter_values.items()},
            "column_formats": {str(k): str(v) for k, v in self.column_formats.items()},
            "row_histories": copy.deepcopy(self.row_histories),
            "cell_styles": copy.deepcopy(self.cell_styles),
            "row_height": self.row_height,
        }
        try:
            path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            return None
        return path

    def _apply_history_snapshot(self, snapshot: dict) -> None:
        path = snapshot.get("path")
        if path:
            self.current_path = Path(path)
        self.headers = list(snapshot.get("headers", []))
        self.source_headers = list(snapshot.get("source_headers", []))
        self.rows_all = copy.deepcopy(snapshot.get("rows", []))
        self.rows = list(self.rows_all)
        widths = snapshot.get("column_widths", {})
        if isinstance(widths, dict):
            self.saved_column_widths = {str(k): int(v) for k, v in widths.items()}
        aligns = snapshot.get("column_align", {})
        if isinstance(aligns, dict):
            self.alignment_map = {str(k): int(v) for k, v in aligns.items()}
        filters = snapshot.get("filters", {})
        if isinstance(filters, dict):
            self.filter_values = {int(k): str(v) for k, v in filters.items()}
        formats = snapshot.get("column_formats", {})
        if isinstance(formats, dict):
            self.column_formats = {str(k): str(v) for k, v in formats.items()}
        rh = snapshot.get("row_histories", [])
        if isinstance(rh, list):
            self.row_histories = rh
        cs = snapshot.get("cell_styles", {})
        if isinstance(cs, dict):
            self.cell_styles = cs
        rhh = snapshot.get("row_height")
        if rhh is not None:
            try:
                self.row_height = int(rhh)
            except Exception:
                pass
        self._ensure_change_column()
        self._ensure_row_histories()
        self.sort_orders.clear()
        self._apply_filters()
        self._persist_now()

    def _show_history(self) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle("Lịch sử phiên")
        layout = QVBoxLayout(dialog)
        countdown_label = QLabel("30:00")
        countdown_label.setStyleSheet("color: #8b99b8;")
        countdown_label.setAlignment(Qt.AlignCenter)
        countdown_label.setFixedHeight(20)
        layout.addWidget(countdown_label)
        self.history_countdown_label = countdown_label
        self._update_history_countdown()
        list_widget = QListWidget()
        self._populate_history_list(list_widget)
        list_widget.currentItemChanged.connect(
            lambda curr, prev: self._set_history_selection(curr)
        )
        list_widget.itemDoubleClicked.connect(
            lambda item: self._restore_history_entry(item.data(Qt.UserRole), dialog)
        )
        layout.addWidget(list_widget)
        buttons = QDialogButtonBox()
        btn_restore = buttons.addButton("Khôi phục", QDialogButtonBox.AcceptRole)
        btn_restore.clicked.connect(lambda: self._restore_selected_history(dialog))
        btn_save = buttons.addButton("Lưu phiên", QDialogButtonBox.ActionRole)
        btn_save.clicked.connect(lambda: self._save_history_now(list_widget))
        btn_clear = buttons.addButton("Xóa lịch sử", QDialogButtonBox.DestructiveRole)
        btn_clear.clicked.connect(lambda: self._confirm_clear_history(list_widget))
        buttons.addButton(QDialogButtonBox.Close)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        dialog.exec()
        self.history_countdown_label = None

    def _populate_history_list(self, list_widget: QListWidget) -> None:
        list_widget.clear()
        for entry in self.session_history:
            path = entry.get("path", "")
            timestamp = entry.get("time", "")
            snapshot = entry.get("snapshot", "")
            display_time = self._format_session_time(timestamp)
            item = QListWidgetItem(f"{display_time} — {Path(path).name}")
            item.setData(Qt.UserRole, snapshot or path)
            list_widget.addItem(item)

    def _save_history_now(self, list_widget: QListWidget) -> None:
        self._record_session(force=True)
        self._populate_history_list(list_widget)

    def _confirm_clear_history(self, list_widget: QListWidget) -> None:
        if not self.session_history:
            return
        resp = QMessageBox.question(
            self,
            "Xóa lịch sử phiên",
            "Bạn có chắc muốn xóa toàn bộ lịch sử phiên không?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if resp == QMessageBox.Yes:
            self._clear_history(list_widget)

    def _clear_history(self, list_widget: QListWidget) -> None:
        for entry in self.session_history:
            snap = entry.get("snapshot")
            if snap:
                try:
                    Path(snap).unlink(missing_ok=True)
                except Exception:
                    pass
        self.session_history = []
        self._save_state()
        self._populate_history_list(list_widget)

    def _clear_table_data(self) -> None:
        if not self.headers:
            return
        resp = QMessageBox.question(
            self,
            "Xóa bảng",
            "Xóa dữ liệu đang hiển thị trên bảng (giữ nguyên header)?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if resp != QMessageBox.Yes:
            return
        visible_ids = {id(r) for r in self.rows}
        if not visible_ids:
            return
        new_rows_all = []
        new_row_histories = []
        for row, hist in zip(self.rows_all, self.row_histories):
            if id(row) in visible_ids:
                continue
            new_rows_all.append(row)
            new_row_histories.append(hist)
        self.rows_all = new_rows_all
        self.row_histories = new_row_histories
        # keep filters so view shows remaining (or empty) with same criteria
        self._apply_filters()
        self._persist_now()
    def _load_history_snapshot(self, snapshot_path: str, dialog: QDialog) -> None:
        if not snapshot_path:
            return
        path = Path(snapshot_path)
        if path.exists() and path.is_file() and path.suffix.lower() == ".json":
            try:
                snapshot = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                QMessageBox.warning(self, "Khôi phục", "Không đọc được dữ liệu phiên.")
                return
            self._apply_history_snapshot(snapshot)
            dialog.accept()
            return
        if not path.exists() and snapshot_path.lower().endswith(".json"):
            QMessageBox.warning(self, "Khôi phục", "Không tìm thấy dữ liệu phiên.")
            return
        # fallback for old entries (path to Excel)
        self.current_path = path
        self.reload()
        dialog.accept()

    def _get_active_template_headers(self) -> Optional[List[str]]:
        if not self.active_template:
            return None
        for tpl in self.templates:
            if tpl.get("name") == self.active_template:
                headers = tpl.get("headers", [])
                if isinstance(headers, list):
                    return [str(h).strip() for h in headers if str(h).strip() and str(h).strip() != "Nguồn"]
        return None

    def _get_template_by_name(self, name: Optional[str]) -> Optional[dict]:
        if not name:
            return None
        for tpl in self.templates:
            if tpl.get("name") == name:
                return tpl
        return None

    def _apply_template_snapshot(self, tpl: dict) -> None:
        headers = tpl.get("headers", [])
        rows = tpl.get("rows", [])
        if headers:
            self.headers = list(headers)
            self.source_headers = list(tpl.get("source_headers", headers))
        self.rows_all = copy.deepcopy(rows) if isinstance(rows, list) else []
        self.rows = list(self.rows_all)
        self.row_histories = copy.deepcopy(tpl.get("row_histories", [[] for _ in self.rows_all]))
        if isinstance(tpl.get("column_formats"), dict):
            self.column_formats = {str(k): str(v) for k, v in tpl["column_formats"].items()}
        if isinstance(tpl.get("column_widths"), dict):
            self.saved_column_widths = {str(k): int(v) for k, v in tpl["column_widths"].items()}
        if isinstance(tpl.get("alignment"), dict):
            self.alignment_map = {str(k): int(v) for k, v in tpl["alignment"].items()}
        if isinstance(tpl.get("filters"), dict):
            self.filter_values = {int(k): str(v) for k, v in tpl["filters"].items()}
        # Alert rules per template
        if isinstance(tpl.get("alert_rules"), list):
            self.alert_rules = copy.deepcopy(tpl["alert_rules"])
        else:
            self.alert_rules = []
        self.alert_send_enabled = bool(tpl.get("alert_send_enabled", False))
        # ensure col_idx remains in range if headers changed
        for r in self.alert_rules:
            if "col_idx" in r:
                try:
                    r["col_idx"] = int(r["col_idx"])
                except Exception:
                    r.pop("col_idx", None)
        self._ensure_source_column()
        self._ensure_change_column()
        self._ensure_row_histories()
        self._apply_filters()
        self._persist_now()

    def _apply_template_to_import(self, headers_file: List[str], rows_file: List[List[Any]]) -> tuple[List[str], List[List[Any]]]:
        if not self.active_template:
            return headers_file, rows_file
        template_headers = self._get_active_template_headers()
        if not template_headers:
            return headers_file, rows_file
        header_map = {str(h).strip().lower(): idx for idx, h in enumerate(headers_file)}
        mapped_rows: List[List[Any]] = []
        for row in rows_file:
            new_row = []
            for h in template_headers:
                idx = header_map.get(h.strip().lower())
                if idx is None or idx >= len(row):
                    new_row.append("")
                else:
                    new_row.append(row[idx])
            mapped_rows.append(new_row)
        return template_headers, mapped_rows

    def _on_template_changed(self, index: int) -> None:
        if index <= 0:
            self.active_template = None
            # Xóa dữ liệu hiện hành giống thao tác "Thêm trang" nhưng không ảnh hưởng mẫu đã lưu
            self.headers = []
            self.source_headers = []
            self.rows_all = []
            self.rows = []
            self.row_histories = []
            self.filter_values = {}
            self.sort_orders.clear()
            self._set_model(self.headers, self.rows)
            self._persist_now()
            return
        name = self.template_combo.currentText().strip()
        self.active_template = name if name else None
        tpl = self._get_template_by_name(self.active_template)
        if tpl:
            self._apply_template_snapshot(tpl)
        self._save_state()

    def _save_template(self) -> None:
        default_name = self.active_template or ""
        name, ok = QInputDialog.getText(self, "Lưu trang mẫu", "Tên trang mẫu:", text=default_name)
        if not ok:
            return
        name = name.strip()
        if not name:
            return
        headers = [h for h in self.headers if h and h != "Nguồn"]
        snapshot = {
            "name": name,
            "headers": headers,
            "source_headers": list(self.source_headers),
            "rows": copy.deepcopy(self.rows_all),
            "column_formats": dict(self.column_formats),
            "column_widths": dict(self.saved_column_widths),
            "alignment": dict(self.alignment_map),
            "filters": dict(self.filter_values),
            "row_histories": copy.deepcopy(self.row_histories),
        }
        found = False
        for tpl in self.templates:
            if tpl.get("name") == name:
                tpl.update(snapshot)
                found = True
                break
        if not found:
            self.templates.append(snapshot)
        self.active_template = name
        self._refresh_template_combo()
        self._refresh_stats_template_combo()
        self._save_state()

    def _add_template(self) -> None:
        resp = QMessageBox.question(
            self,
            "Thêm trang mới",
            "Hãy lưu trang hiện tại trước khi mở trang mới, sẽ xóa trang hiện tại. Bạn có chắc muốn tiếp tục không?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if resp != QMessageBox.Yes:
            return
        self.headers = []
        self.source_headers = []
        self.rows_all = []
        self.rows = []
        self.row_histories = []
        self.filter_values = {}
        self.sort_orders.clear()
        self.active_template = None
        self._set_model(self.headers, self.rows)
        self._refresh_template_combo()
        if hasattr(self, "template_combo"):
            self.template_combo.setCurrentIndex(0)
        self._persist_now()

    def _delete_template(self, name: str) -> None:
        self.templates = [tpl for tpl in self.templates if tpl.get("name") != name]
        if self.active_template == name:
            self.active_template = None
        self._refresh_template_combo()
        self._refresh_stats_template_combo()
        self._save_state()

    def _set_history_selection(self, item: QListWidgetItem | None) -> None:
        self._history_selected_snapshot = item.data(Qt.UserRole) if item else None

    def _restore_selected_history(self, dialog: QDialog) -> None:
        snapshot_path = self._history_selected_snapshot
        if snapshot_path:
            self._load_history_snapshot(snapshot_path, dialog)

    def _restore_history_entry(self, path: str, dialog: QDialog) -> None:
        if path:
            self._load_history_snapshot(path, dialog)

    def _export_file(self) -> None:
        if not self.rows_all:
            QMessageBox.warning(self, "Xuất file", "Không có dữ liệu để xuất.")
            return
        path, selected_filter = QFileDialog.getSaveFileName(
            self,
            "Xuất dữ liệu",
            str(self.current_path.with_suffix("")),
            "Excel (*.xlsx);;CSV (*.csv)",
        )
        if not path:
            return
        try:
            df = pd.DataFrame(self.rows_all, columns=self.headers)
            if selected_filter.endswith("xlsx") or path.lower().endswith(".xlsx"):
                if not path.lower().endswith(".xlsx"):
                    path += ".xlsx"
                df.to_excel(path, index=False)
            else:
                if not path.lower().endswith(".csv"):
                    path += ".csv"
                df.to_csv(path, index=False)
            QMessageBox.information(self, "Xuất file", f"Đã lưu ra {Path(path).name}.")
        except Exception as exc:
            QMessageBox.warning(self, "Xuất file", f"Lỗi khi xuất: {exc}")

    def _format_session_time(self, iso: str) -> str:
        try:
            dt = datetime.fromisoformat(iso)
            return dt.strftime("%H:%M:%S %d/%m/%Y")
        except Exception:
            return iso

    def closeEvent(self, event) -> None:
        self._save_cached_data()
        self._save_state()
        super().closeEvent(event)

    # ===== Header context menu for alignment ===== #
    def _show_header_menu(self, pos) -> None:
        header = self.table.horizontalHeader()
        logical = header.logicalIndexAt(pos)
        if logical < 0:
            return
        # Lấy các cột đang chọn, nếu không có thì dùng cột được click
        selected = set(idx.column() for idx in self.table.selectionModel().selectedColumns())
        if not selected:
            selected = {logical}

        menu = QMenu(self)
        format_menu = menu.addMenu("Định dạng")
        act_fmt_default = format_menu.addAction("Mặc định (như Excel)")
        act_fmt_default.triggered.connect(lambda checked=False, cols=selected: self._clear_column_format(cols))
        format_options = [
            ("Chung", Qt.AlignLeft | Qt.AlignVCenter),
            ("Số", Qt.AlignRight | Qt.AlignVCenter),
            ("Số có dấu", Qt.AlignRight | Qt.AlignVCenter),
            ("Tiền", Qt.AlignRight | Qt.AlignVCenter),
            ("Ngày", Qt.AlignHCenter | Qt.AlignVCenter),
            ("Thời gian", Qt.AlignHCenter | Qt.AlignVCenter),
            ("Số điện thoại", Qt.AlignLeft | Qt.AlignVCenter),
            ("Văn bản", Qt.AlignLeft | Qt.AlignVCenter),
        ]
        for fmt_text, fmt_align in format_options:
            act_fmt = format_menu.addAction(fmt_text)
            act_fmt.triggered.connect(
                lambda checked=False, f=fmt_text, a=fmt_align, cols=selected: self._apply_column_format(cols, f, a)
            )
        align_menu = menu.addMenu("Căn lề")
        align_actions = [
            ("Căn trái", Qt.AlignLeft | Qt.AlignVCenter),
            ("Căn giữa", Qt.AlignHCenter | Qt.AlignVCenter),
            ("Căn phải", Qt.AlignRight | Qt.AlignVCenter),
        ]
        for text, align in align_actions:
            act = align_menu.addAction(text)
            act.triggered.connect(lambda checked=False, a=align, cols=selected: self._set_alignment(cols, a))

        style_menu = menu.addMenu("Kiểu chữ")
        act_bold = style_menu.addAction("In đậm")
        act_bold.triggered.connect(lambda: self._apply_style_to_columns(selected, bold=True))
        act_italic = style_menu.addAction("Nghiêng")
        act_italic.triggered.connect(lambda: self._apply_style_to_columns(selected, italic=True))
        act_under = style_menu.addAction("Gạch chân")
        act_under.triggered.connect(lambda: self._apply_style_to_columns(selected, underline=True))
        act_clear_style = style_menu.addAction("Xóa kiểu")
        act_clear_style.triggered.connect(lambda: self._apply_style_to_columns(selected, clear_font=True))

        color_menu = menu.addMenu("Màu chữ")
        swatches = [
            ("Mặc định", None),
            ("Đỏ", "#ef4444"),
            ("Xanh lá", "#22c55e"),
            ("Xanh dương", "#2563eb"),
            ("Xanh đậm", "#1e3a8a"),
            ("Vàng", "#facc15"),
            ("Cam", "#f97316"),
            ("Hồng", "#ec4899"),
            ("Tím", "#8b5cf6"),
            ("Trắng", "#ffffff"),
            ("Đen", "#111111"),
        ]

        def make_icon(hex_color: str | None) -> QIcon:
            if not hex_color:
                return QIcon()
            pm = QPixmap(14, 14)
            pm.fill(QColor(hex_color))
            return QIcon(pm)

        for name, col in swatches:
            act = color_menu.addAction(make_icon(col), name)
            act.triggered.connect(lambda checked=False, c=col: self._apply_style_to_columns(selected, color=c))

        def pick_color():
            dlgc = QColorDialog(self)
            dlgc.setOption(QColorDialog.DontUseNativeDialog, True)
            for i, (_, col) in enumerate(swatches):
                if col:
                    dlgc.setCustomColor(i, QColor(col))
            if dlgc.exec():
                c = dlgc.currentColor()
                if c.isValid():
                    self._apply_style_to_columns(selected, color=c.name())

        color_menu.addSeparator()
        color_menu.addAction("Bảng màu...").triggered.connect(pick_color)

        # Màu nền
        bg_menu = menu.addMenu("Màu nền")
        act_bg_clear = bg_menu.addAction("Mặc định")
        act_bg_clear.triggered.connect(lambda: self._apply_style_to_columns(selected, bg=""))
        bg_menu.addSeparator()
        for name, col in swatches[1:]:  # bỏ mục Mặc định
            act = bg_menu.addAction(make_icon(col), name)
            act.triggered.connect(lambda checked=False, c=col: self._apply_style_to_columns(selected, bg=c))
        def pick_bg():
            dlgc = QColorDialog(self)
            dlgc.setOption(QColorDialog.DontUseNativeDialog, True)
            for i, (_, col) in enumerate(swatches):
                if col:
                    dlgc.setCustomColor(i, QColor(col))
            if dlgc.exec():
                c = dlgc.currentColor()
                if c.isValid():
                    self._apply_style_to_columns(selected, bg=c.name())
        bg_menu.addSeparator()
        bg_menu.addAction("Bảng màu...").triggered.connect(pick_bg)

        act_add_left = menu.addAction("Thêm cột bên trái")
        act_add_left.triggered.connect(lambda: self._add_column(logical, side="left"))
        act_rename = menu.addAction("Đổi tên")
        act_rename.triggered.connect(lambda: self._rename_header(logical))
        act_add_right = menu.addAction("Thêm cột bên phải")
        act_add_right.triggered.connect(lambda: self._add_column(logical, side="right"))
        menu.addSeparator()
        act_hide = menu.addAction("Ẩn cột đã chọn")
        act_hide.triggered.connect(lambda: self._hide_columns(selected))
        act_show = menu.addAction("Hiển thị cột...")
        act_show.triggered.connect(self._show_hidden_columns_dialog)
        menu.addSeparator()
        act_del_col = menu.addAction("Xóa cột đã chọn")
        act_del_col.triggered.connect(lambda: self._delete_columns(selected))

        menu.exec(header.mapToGlobal(pos))

    def _sort_column(self, column: int) -> None:
        if column < 0 or column >= len(self.headers):
            return
        ascending = self.sort_orders.get(column, True)
        key = self._build_sort_key(column)
        paired = list(zip(self.rows_all, self.row_histories))
        paired.sort(key=lambda p: key(p[0]), reverse=not ascending)
        self.rows_all, self.row_histories = [p[0] for p in paired], [p[1] for p in paired]
        self.sort_orders[column] = not ascending
        self._apply_filters()
        self._persist_now()

    def _build_sort_key(self, column: int) -> Callable[[List[Any]], Any]:
        fmt = self.column_formats.get(str(column), "")
        if fmt in {"Số", "Số có dấu", "Tiền"}:
            return lambda row: self._numeric_sort_value(row, column)
        if fmt == "Ngày":
            return lambda row: self._datetime_sort_value(row, column, include_time=False)
        if fmt == "Thời gian":
            return lambda row: self._datetime_sort_value(row, column, include_time=True)
        if fmt == "Số điện thoại":
            return lambda row: self._phone_sort_value(row, column)
        return lambda row: self._text_sort_value(row, column)

    def _numeric_sort_value(self, row: List[Any], column: int) -> float:
        if column >= len(row):
            return 0.0
        val = row[column]
        text = "" if pd.isna(val) else str(val)
        clean = text.replace(",", "").replace(" ", "")
        if not clean or clean in {"-", ".", "-."}:
            return 0.0
        try:
            return float(clean)
        except ValueError:
            return 0.0

    def _datetime_sort_value(self, row: List[Any], column: int, include_time: bool) -> datetime:
        if column >= len(row):
            return datetime.min
        val = row[column]
        text = "" if pd.isna(val) else str(val)
        dt = parse_datetime_string(text, include_time=include_time)
        return dt if dt else datetime.min

    def _text_sort_value(self, row: List[Any], column: int) -> str:
        if column >= len(row):
            return ""
        val = row[column]
        text = "" if pd.isna(val) else str(val)
        return text.lower()

    def _phone_sort_value(self, row: List[Any], column: int) -> Any:
        if column >= len(row):
            return ""
        val = row[column]
        digits = re.sub(r"\D", "", "" if pd.isna(val) else str(val))
        if digits.startswith("84") and len(digits) >= 10:
            digits = "0" + digits[2:]
        elif len(digits) == 9 and not digits.startswith("0"):
            digits = "0" + digits
        return digits
    def _set_alignment(self, columns: set[int], alignment: int) -> None:
        data_cols = self._view_columns_to_data(columns)
        if not data_cols:
            return
        for col in data_cols:
            self.alignment_map[str(col)] = int(alignment)
        if self.table.model():
            # Cập nhật model align map reference
            self.table.model().alignment_map = self.alignment_map
            self.table.model().column_formats = self.column_formats
            # Thông báo thay đổi để repaint
            top_left = self.table.model().index(0, min(columns))
            bottom_right = self.table.model().index(self.table.model().rowCount() - 1, max(columns))
            self.table.model().dataChanged.emit(top_left, bottom_right, [Qt.TextAlignmentRole])
        self._persist_now()

    def _on_table_double_clicked(self, index: QModelIndex) -> None:
        if not index.isValid():
            return
        fmt = self.column_formats.get(str(index.column()))
        if fmt not in ("Ngày", "Thời gian"):
            return
        current = str(self.rows[index.row()][index.column()])
        dialog = QuickDateTimeDialog(self, current, include_time=(fmt == "Thời gian"))
        if dialog.exec() == QDialog.Accepted:
            value = dialog.value()
            if value:
                self.table.model().setData(index, value)

    def _apply_column_format(self, columns: set[int], format_name: str, alignment: int) -> None:
        if not columns:
            return
        data_cols = self._view_columns_to_data(columns)
        for col in data_cols:
            self.column_formats[str(col)] = format_name
        self._set_alignment(columns, alignment)

    def _clear_column_format(self, columns: set[int]) -> None:
        if not columns:
            return
        data_cols = self._view_columns_to_data(columns)
        changed = False
        for col in data_cols:
            if str(col) in self.column_formats:
                self.column_formats.pop(str(col), None)
                changed = True
        if changed:
            # cập nhật lại hiển thị
            self._apply_filters()
            self._persist_now()

    # ===== Column/Row modifications ===== #
    def _add_column(self, ref_col: int, side: str = "right") -> None:
        name, ok = QInputDialog.getText(self, "Thêm cột", "Tên cột mới:", text="Cột mới")
        if not ok:
            return
        actual_ref = self._view_to_data_column(ref_col)
        if actual_ref is None:
            idx = 0 if side == "left" else len(self.headers)
        else:
            idx = actual_ref if side == "left" else actual_ref + 1
        idx = max(0, min(idx, len(self.headers)))
        self.headers.insert(idx, name)
        self.source_headers.insert(idx, "")
        for r in self.rows:
            r.insert(idx, "")
        # dịch align và width
        new_align = {}
        for k, v in self.alignment_map.items():
            c = int(k)
            if c >= idx:
                new_align[str(c + 1)] = v
            else:
                new_align[str(c)] = v
        self.alignment_map = new_align
        new_widths = {}
        for k, v in self.saved_column_widths.items():
            c = int(k)
            if c >= idx:
                new_widths[str(c + 1)] = v
            else:
                new_widths[str(c)] = v
        self.saved_column_widths = new_widths
        new_formats = {}
        for k, v in self.column_formats.items():
            c = int(k)
            if c >= idx:
                new_formats[str(c + 1)] = v
            else:
                new_formats[str(c)] = v
        self.column_formats = new_formats
        self._set_model(self.headers, self.rows)
        self._save_cached_data()
        self._save_state()

    def _delete_columns(self, columns: set[int]) -> None:
        original_len = len(self.headers)
        data_cols = sorted(self._view_columns_to_data(columns), reverse=True)
        if not data_cols:
            return
        for c in data_cols:
            if 0 <= c < len(self.headers):
                self.headers.pop(c)
                if 0 <= c < len(self.source_headers):
                    self.source_headers.pop(c)
                for r in self.rows:
                    if c < len(r):
                        r.pop(c)
        # rebuild align/width map
        new_align = {}
        remap = sorted(set(range(original_len)) - set(data_cols))
        for new_idx, old_idx in enumerate(remap):
            key = str(old_idx)
            if key in self.alignment_map:
                new_align[str(new_idx)] = self.alignment_map[key]
        self.alignment_map = new_align
        new_widths = {}
        for new_idx, old_idx in enumerate(remap):
            key = str(old_idx)
            if key in self.saved_column_widths:
                new_widths[str(new_idx)] = self.saved_column_widths[key]
        self.saved_column_widths = new_widths
        new_formats = {}
        for key, value in self.column_formats.items():
            idx = int(key)
            if idx in data_cols:
                continue
            shift = sum(1 for removed in data_cols if removed < idx)
            new_formats[str(idx - shift)] = value
        self.column_formats = new_formats
        self._set_model(self.headers, self.rows)
        self._save_cached_data()
        self._save_state()

    def _trim_columns_to(self, max_len: int) -> None:
        if max_len >= len(self.headers):
            return
        for idx in range(len(self.headers) - 1, max_len - 1, -1):
            if 0 <= idx < len(self.headers):
                self.headers.pop(idx)
            if 0 <= idx < len(self.source_headers):
                self.source_headers.pop(idx)
            for r in self.rows:
                if idx < len(r):
                    r.pop(idx)
            for r in self.rows_all:
                if idx < len(r):
                    r.pop(idx)
        self.saved_column_widths = {k: v for k, v in self.saved_column_widths.items() if int(k) < max_len}
        self.alignment_map = {k: v for k, v in self.alignment_map.items() if int(k) < max_len}
        self.filter_values = {k: v for k, v in self.filter_values.items() if k < max_len}
        self.column_formats = {k: v for k, v in self.column_formats.items() if int(k) < max_len}

    def _insert_row(self, position: str = "below", base_row: Optional[int] = None) -> None:
        model = self.table.model()
        if not model:
            return
        if base_row is None:
            sel = self.table.selectionModel().selectedRows()
            if sel:
                base_row = sel[0].row()
            else:
                base_row = model.rowCount() - 1 if model.rowCount() > 0 else 0
        idx = base_row if position == "above" else base_row + 1
        idx = max(0, min(idx, len(self.rows)))
        new_row = ["" for _ in range(len(self.headers))]
        self.rows.insert(idx, new_row)
        self.rows_all.insert(idx, new_row)
        self._ensure_change_column()
        self._ensure_row_histories()
        change_idx = self._change_col_idx()
        now_text = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
        if change_idx is not None and change_idx < len(new_row):
            new_row[change_idx] = now_text
        if idx < len(self.row_histories):
            self.row_histories.insert(idx, [now_text])
        else:
            self.row_histories.append([now_text])
        self._set_model(self.headers, self.rows)
        self._save_cached_data()
        self._save_state()

    def _delete_rows(self) -> None:
        model = self.table.model()
        if not model:
            return
        sel = sorted((idx.row() for idx in self.table.selectionModel().selectedRows()), reverse=True)
        if not sel:
            return
        to_remove = []
        for r in sel:
            if 0 <= r < len(self.rows):
                to_remove.append(self.rows[r])
        for row_ref in to_remove:
            if row_ref in self.rows_all:
                idx = self.rows_all.index(row_ref)
                self.rows_all.pop(idx)
                if idx < len(self.row_histories):
                    self.row_histories.pop(idx)
        self._apply_filters()
        self._save_cached_data()
        self._save_state()

    def _delete_empty_rows(self) -> None:
        src_idx = self.headers.index("Nguồn") if "Nguồn" in self.headers else None
        kept: List[List[Any]] = []
        kept_hist: List[List[str]] = []
        for row in self.rows:
            has_value = False
            for idx, val in enumerate(row):
                if idx == src_idx:
                    continue
                text = "" if pd.isna(val) else str(val)
                if text.strip():
                    has_value = True
                    break
            if has_value:
                kept.append(row)
                if row in self.rows_all:
                    hist_idx = self.rows_all.index(row)
                    kept_hist.append(self.row_histories[hist_idx] if hist_idx < len(self.row_histories) else [])
        if len(kept) != len(self.rows):
            self.rows = kept
            self.rows_all = kept
            self.row_histories = kept_hist
            self._set_model(self.headers, self.rows)
            self._save_cached_data()
            self._save_state()

    def _clear_selected_cells(self) -> None:
        model = self.table.model()
        if not model:
            return
        indexes = self.table.selectionModel().selectedIndexes()
        if not indexes:
            return
        for idx in indexes:
            model.setData(idx, "")
        self._persist_now()

    def _cut_selection_to_clipboard(self) -> None:
        # Cut = copy selection then clear selected cells
        self._copy_selection_to_clipboard()
        self._clear_selected_cells()

    def _handle_paste(self) -> None:
        model = self.table.model()
        if not model:
            return
        indexes = sorted(self.table.selectionModel().selectedIndexes(), key=lambda idx: (idx.row(), idx.column()))
        if not indexes:
            return
        clipboard = QGuiApplication.clipboard().text()
        if not clipboard:
            return
        # Keep empty lines so non-contiguous selections (e.g. rows 1,5,8) preserve gaps.
        rows = clipboard.splitlines()
        if not rows:
            return
        values = [row.split("\t") for row in rows]
        if not values:
            return
        start_row, start_col = indexes[0].row(), indexes[0].column()
        max_cols = max(len(row) for row in values) if values else 0
        for r_idx, row in enumerate(values):
            for c_idx in range(max_cols):
                val = row[c_idx] if c_idx < len(row) else ""
                target_row = start_row + r_idx
                target_col = start_col + c_idx
                if target_row >= model.rowCount() or target_col >= model.columnCount():
                    continue
                model.setData(model.index(target_row, target_col), val)
        self._persist_now()

    def _copy_selection_to_clipboard(self) -> None:
        model = self.table.model()
        sel = self.table.selectionModel()
        if not model or not sel:
            return
        indexes = sel.selectedIndexes()
        if not indexes:
            return
        # sắp xếp và xây lưới bao kín selection
        indexes = sorted(indexes, key=lambda i: (i.row(), i.column()))
        rows = [i.row() for i in indexes]
        cols = [i.column() for i in indexes]
        r_min, r_max = min(rows), max(rows)
        c_min, c_max = min(cols), max(cols)
        grid = [["" for _ in range(c_max - c_min + 1)] for _ in range(r_max - r_min + 1)]
        for idx in indexes:
            r = idx.row() - r_min
            c = idx.column() - c_min
            val = model.data(idx, Qt.DisplayRole)
            grid[r][c] = "" if val is None else str(val)
        text = "\n".join("\t".join(row) for row in grid)
        QGuiApplication.clipboard().setText(text)

    def _copy_stats_selection(self) -> None:
        if not hasattr(self, "stats_nm_table"):
            return
        sel = self.stats_nm_table.selectionModel()
        if not sel:
            return
        indexes = sel.selectedIndexes()
        if not indexes:
            return
        indexes = sorted(indexes, key=lambda i: (i.row(), i.column()))
        rows = [i.row() for i in indexes]
        cols = [i.column() for i in indexes]
        r_min, r_max = min(rows), max(rows)
        c_min, c_max = min(cols), max(cols)
        grid = [["" for _ in range(c_max - c_min + 1)] for _ in range(r_max - r_min + 1)]
        for idx in indexes:
            r = idx.row() - r_min
            c = idx.column() - c_min
            val = idx.data(Qt.DisplayRole)
            grid[r][c] = "" if val is None else str(val)
        text = "\n".join("\t".join(row) for row in grid)
        QGuiApplication.clipboard().setText(text)

    def _on_stats_cell_entered(self, index: QModelIndex) -> None:
        """Hiển thị tooltip: Tổng/Min/Max của các ô được chọn (hoặc ô đang rê)."""
        if not index.isValid():
            return
        if not hasattr(self, "stats_row_stats") or not self.stats_row_stats:
            return
        # bỏ tooltip nếu giá trị ô là 0/rỗng
        val_disp = index.data(Qt.DisplayRole)
        if val_disp is None:
            return
        try:
            val_num = float(str(val_disp).replace(",", "").strip())
            if val_num == 0:
                return
        except Exception:
            pass
        sel = self.stats_nm_table.selectionModel()
        rows = {index.row()}
        if sel and sel.hasSelection():
            rows = {idx.row() for idx in sel.selectedIndexes()}
        # xác định cột để lấy thống kê phù hợp
        col = index.column()
        # map vị trí cột
        month_cols = len(self.stats_month_order) * 2
        base_month = 7
        base_tail = base_month + month_cols

        agg_count = 0
        agg_sum = 0.0
        agg_min = None
        agg_max = None

        def _is_num(x):
            try:
                return x is not None and math.isfinite(float(x))
            except Exception:
                return False

        for r in rows:
            if r < 0 or r >= len(self.stats_row_stats):
                continue
            st = self.stats_row_stats[r]
            if base_month <= col < base_tail:
                idx_order = (col - base_month) // 2
                side_lt = (col - base_month) % 2 == 0
                m_idx = self.stats_month_order[idx_order]
                if side_lt:
                    vals_list = (st.get("months_lt_values") or [[] for _ in range(12)])[m_idx]
                else:
                    vals_list = (st.get("months_gt_values") or [[] for _ in range(12)])[m_idx]
                nums = [float(v) for v in vals_list if _is_num(v)]
                c = len(nums)
                s = sum(nums) if nums else 0.0
                mn_val = min(nums) if nums else None
                mx_val = max(nums) if nums else None
            elif col == base_tail:
                vals_list = st.get("tk_lt_values") or []
                nums = [float(v) for v in vals_list if _is_num(v)]
                c = len(nums)
                s = sum(nums) if nums else 0.0
                mn_val = min(nums) if nums else None
                mx_val = max(nums) if nums else None
            elif col == base_tail + 1:
                vals_list = st.get("tk_gt_values") or []
                nums = [float(v) for v in vals_list if _is_num(v)]
                c = len(nums)
                s = sum(nums) if nums else 0.0
                mn_val = min(nums) if nums else None
                mx_val = max(nums) if nums else None
            else:
                vals_list = st.get("tk_values") or []
                nums = [float(v) for v in vals_list if _is_num(v)]
                c = len(nums)
                s = sum(nums) if nums else 0.0
                mn_val = min(nums) if nums else None
                mx_val = max(nums) if nums else None
            if c and _is_num(s):
                agg_count += c
                agg_sum += float(s)
                if _is_num(mn_val):
                    mn_f = float(mn_val)
                    agg_min = mn_f if agg_min is None else min(agg_min, mn_f)
                if _is_num(mx_val):
                    mx_f = float(mx_val)
                    agg_max = mx_f if agg_max is None else max(agg_max, mx_f)

        if agg_count == 0:
            return
        if agg_min is None:
            agg_min = 0.0
        if agg_max is None:
            agg_max = 0.0
        def fmt(v: float) -> str:
            try:
                return self._format_sum_value(float(v))
            except Exception:
                return str(v)
        tooltip = f"Tổng TKC: {fmt(agg_sum)}\nTKC min: {fmt(agg_min)}\nTKC max: {fmt(agg_max)}"
        item = self.stats_nm_table.item(index.row(), index.column())
        if item:
            item.setToolTip(tooltip)

    def _selection_info(self):
        indexes = sorted(self.table.selectionModel().selectedIndexes(), key=lambda idx: (idx.column(), idx.row()))
        if not indexes:
            return None
        cols = {idx.column() for idx in indexes}
        if len(cols) != 1:
            return None
        # ensure contiguous rows
        rows = [idx.row() for idx in indexes]
        if rows != list(range(rows[0], rows[0] + len(rows))):
            return None
        return indexes

    def _paste_from_context_menu(self) -> None:
        selection = self._selection_info()
        if not selection:
            QMessageBox.warning(self, "Dán", "Chỉ có thể dán vào một cột liền kề.")
            return
        clipboard = QGuiApplication.clipboard().text()
        # Keep empty lines (they represent gaps when copying non-contiguous rows)
        lines = clipboard.splitlines()
        if not lines:
            return
        if len(lines) > len(selection):
            QMessageBox.warning(self, "Dán", "Ô chọn không đủ để chứa dữ liệu.")
            return
        model = self.table.model()
        for idx, value in zip(selection, lines):
            model.setData(idx, value)
        self._persist_now()

    # ===================== Filters ===================== #
    def _build_filter_row(self) -> None:
        # Clear old inputs
        for w in self.filter_inputs:
            w.deleteLater()
        self.filter_inputs = []
        for lbl in self.filter_letter_labels:
            lbl.deleteLater()
        self.filter_letter_labels = []
        for btn in self.filter_clear_buttons:
            btn.deleteLater()
        self.filter_clear_buttons = []
        for btn in list(getattr(self, "filter_extra_buttons", [])) or []:
            deleter = getattr(btn, "deleteLater", None)
            if deleter:
                deleter()
        self.filter_extra_buttons = []
        for btn in getattr(self, "filter_quick_buttons", []):
            if btn:
                btn.deleteLater()
        self.filter_quick_buttons = []
        for btn in getattr(self, "filter_nav_buttons", []):
            btn.deleteLater()
        self.filter_nav_buttons = []
        # Build new inputs per column (absolute positioning)
        display_headers = self._display_headers()
        for idx in range(len(display_headers)):
            line = FilterLineEdit(self.filter_bar)
            letter = col_letter(idx)
            header_name = display_headers[idx]
            line.setPlaceholderText(header_name)
            if idx in self.filter_values:
                line.setText(self.filter_values[idx])
            line.returnPressed.connect(lambda idx=idx, w=line: self._on_filter_enter(idx, w.text()))
            line.setFixedHeight(25)
            line.show()
            self.filter_inputs.append(line)
            btn_clear = QToolButton(self.filter_bar)
            btn_clear.setText("×")
            btn_clear.setCursor(Qt.PointingHandCursor)
            btn_clear.setFixedSize(16, 16)
            btn_clear.setToolTip("Xóa bộ lọc")
            btn_clear.setStyleSheet("background: transparent; color: #a0aec0; border: none;")
            btn_clear.clicked.connect(lambda _, col=idx: self._clear_filter(col))
            btn_clear.setVisible(bool(line.text().strip()))
            line.textChanged.connect(lambda text, b=btn_clear: b.setVisible(bool(text.strip())))
            self.filter_clear_buttons.append(btn_clear)
            # nút danh sách SĐT
            actual_col = self._view_to_data_column(idx)
            phone_idx = self._find_phone_column(self.headers)
            is_phone_col = actual_col is not None and (
                self.column_formats.get(str(actual_col)) == "Số điện thoại"
                or actual_col == phone_idx
            )
            phone_btn = None
            if is_phone_col:
                phone_btn = PhoneFilterButton(
                    idx,
                    on_click=lambda col=idx: self._open_phone_list_filter(col),
                    on_double=lambda col=idx: self._clear_phone_list_filter(col),
                    parent=self.filter_bar,
                )
                phone_btn.setText("📋")
                phone_btn.setFixedSize(18, 18)
                phone_btn.setCursor(Qt.PointingHandCursor)
                phone_btn.setToolTip("Lọc theo danh sách SĐT (nhấp đúp để bỏ lọc)")
                phone_btn.setStyleSheet(
                    "QToolButton { background:#10b981; color:#ffffff; border-radius:3px; padding:1px 2px; }"
                    "QToolButton:hover { background:#059669; }"
                )
                phone_btn.show()
            self.filter_extra_buttons.append(phone_btn)
            # nút chọn nhanh (giống tab thống kê) cho các cột cần
            norm = self._normalize_header_name(header_name)
            quick_btn = None
            target_keys = {
                "nhamang",
                "trangthai",
                "tkc",
                "tkkm",
                "hsd",
                "psc",
                "nhap",
                "vitri",
                "losim",
                "lo",
                "note",
                "thaydoi",
                "thaydoiluc",
                "nguon",
            }
            if any(k in norm for k in target_keys):
                quick_btn = QToolButton(self.filter_bar)
                quick_btn.setText("▾")
                quick_btn.setFixedSize(18, 18)
                quick_btn.setCursor(Qt.PointingHandCursor)
                quick_btn.setToolTip("Chọn nhanh")
                quick_btn.setStyleSheet(
                    "QToolButton { background:#1e2230; color:#f2f4f8; border:1px solid #3a425a; border-radius:2px; padding:0 4px; }"
                    "QToolButton:hover { background:#2b3144; }"
                )
                quick_btn.clicked.connect(lambda _, c=idx, b=quick_btn: self._open_filter_quick_menu(c, b))
                quick_btn.show()
            self.filter_quick_buttons.append(quick_btn)
        # Nút điều hướng lên/xuống
        btn_up = QToolButton(self.filter_bar)
        btn_up.setText("⬆")
        btn_up.setFixedSize(20, 18)
        btn_up.setCursor(Qt.PointingHandCursor)
        btn_up.setToolTip("Cuộn lên đầu bảng")
        btn_up.clicked.connect(lambda: self.table.verticalScrollBar().setValue(self.table.verticalScrollBar().minimum()))
        btn_up.show()
        btn_down = QToolButton(self.filter_bar)
        btn_down.setText("⬇")
        btn_down.setFixedSize(20, 18)
        btn_down.setCursor(Qt.PointingHandCursor)
        btn_down.setToolTip("Cuộn xuống cuối bảng")
        btn_down.clicked.connect(lambda: self.table.verticalScrollBar().setValue(self.table.verticalScrollBar().maximum()))
        btn_down.show()
        self.filter_nav_buttons = [btn_up, btn_down]
        self._build_letter_row()

    def _sync_filter_widths(self) -> None:
        if not self.filter_inputs:
            return
        header = self.table.horizontalHeader()
        vh_width = self.table.verticalHeader().width()
        frame = self.table.frameWidth()
        offset = vh_width + frame
        total_width = offset
        for idx, edit in enumerate(self.filter_inputs):
            try:
                w = header.sectionSize(idx)
                x = header.sectionViewportPosition(idx)
            except Exception:
                w = 100
                x = 0
            x_base = offset + x
            edit_x, edit_w = x_base, w  # giá trị mặc định khi không có nút phụ
            phone_btn = self.filter_extra_buttons[idx] if idx < len(self.filter_extra_buttons) else None
            if phone_btn:
                btn_w = phone_btn.width()
                btn_x = x_base - btn_w - 2
                if btn_x < 0:
                    btn_x = x_base + 2
                    edit_x = btn_x + btn_w + 6
                    edit_w = max(30, w - btn_w - 6)
                else:
                    edit_x = x_base
                    edit_w = w
                phone_btn.move(btn_x, 4)
            # vị trí quick button (nếu có) đặt sát phải edit, trước nút clear
            quick_btn = self.filter_quick_buttons[idx] if idx < len(self.filter_quick_buttons) else None
            if quick_btn:
                q_w = quick_btn.width()
                # giữ nguyên edit_w; chỉ chừa chỗ cho nút clear bằng cách dời clear khi có quick
            edit.setFixedWidth(edit_w)
            edit.move(edit_x, 0)
            total_width = max(total_width, offset + x + w)
            if idx < len(self.filter_clear_buttons):
                btn = self.filter_clear_buttons[idx]
                if quick_btn:
                    clear_x = edit_x + edit_w - btn.width() - quick_btn.width() - 6
                else:
                    clear_x = edit_x + edit_w - btn.width() - 4
                btn.move(clear_x, 3)
            if quick_btn:
                quick_btn.move(edit_x + edit_w - quick_btn.width() - 2, 4)
            self._sync_letter_labels()
        # Không buộc min width theo tổng cột để tránh nở cửa sổ; chỉ resize nội bộ, phần dư sẽ cuộn
        self.filter_bar.setMinimumWidth(0)
        self.filter_bar.setMaximumWidth(16777215)
        # bố trí nút lên/xuống bên phải cột cuối
        if self.filter_nav_buttons:
            btn_up, btn_down = self.filter_nav_buttons
            # đặt sát ô nguồn: căn vào mép phải filter bar hiện tại
            nav_x = total_width + 2
            btn_up.move(nav_x, 2)
            btn_down.move(nav_x, btn_up.y() + btn_up.height() + 2)
            total_width = max(total_width, nav_x + btn_up.width() + 4)
        self.filter_bar.resize(total_width, self.filter_bar.height())
        # cập nhật vị trí scroll theo bảng
        try:
            self.filter_area.horizontalScrollBar().setValue(self.table.horizontalScrollBar().value())
        except Exception:
            pass
        self._update_filter_letter_styles()

    def _apply_quick_filter(self, col_idx: int, value: str) -> None:
        if col_idx < 0 or col_idx >= len(self.filter_inputs):
            return
        edit = self.filter_inputs[col_idx]
        edit.setText(value)
        self._on_filter_enter(col_idx, value)

    def _open_filter_quick_menu(self, col_idx: int, button: QToolButton) -> None:
        if col_idx < 0 or col_idx >= len(self.filter_inputs):
            return
        menu = QMenu(self)
        menu.setStyleSheet(
            "QMenu { background:#1e2230; color:#f5f7fb; border:1px solid #3a425a; }"
            "QMenu::item:selected { background:#2f374f; color:#ffffff; }"
            "QMenu::item:checked { background:#30405a; font-weight:bold; }"
        )
        current = self.filter_inputs[col_idx].text().strip()
        act_all = menu.addAction("Tất cả", lambda: self._apply_quick_filter(col_idx, ""))
        act_all.setCheckable(True)
        act_all.setChecked(current == "")
        act_empty = menu.addAction("Trống", lambda: self._apply_quick_filter(col_idx, "trống"))
        act_empty.setCheckable(True)
        act_empty.setChecked(current.lower() == "trống")
        menu.addSeparator()
        values = []
        seen = set()
        actual_col = self._view_to_data_column(col_idx)
        source_rows = self.rows_all if self.rows_all else self.rows
        if actual_col is not None:
            for r in source_rows:
                if actual_col >= len(r):
                    continue
                val = "" if pd.isna(r[actual_col]) else str(r[actual_col]).strip()
                if not val or val in seen:
                    continue
                seen.add(val)
                values.append(val)
                if len(values) >= 50:
                    break
        if not values:
            values.append("(không có dữ liệu)")
        for v in values:
            act = menu.addAction(v, lambda val=v: self._apply_quick_filter(col_idx, val))
            act.setCheckable(True)
            if v == current:
                act.setChecked(True)
        menu.exec(button.mapToGlobal(button.rect().bottomLeft()))

    def _on_filter_enter(self, col: int, text: str) -> None:
        if text:
            self.filter_values[col] = text
        elif col in self.filter_values:
            self.filter_values.pop(col)
        # Chỉ lọc khi nhấn Enter
        self._apply_filters()
        self._save_state()

    def _clear_filter(self, col: int) -> None:
        if 0 <= col < len(self.filter_inputs):
            self.filter_inputs[col].clear()
        if col in self.filter_values:
            self.filter_values.pop(col)
        actual_col = self._view_to_data_column(col)
        phone_idx = self._find_phone_column(self.headers)
        if actual_col is not None and (actual_col == phone_idx or self.column_formats.get(str(actual_col)) == "Số điện thoại"):
            self.phone_list_filter = None
        self._apply_filters()
        self._save_state()

    def _clear_phone_list_filter(self, view_col: Optional[int] = None) -> None:
        self.phone_list_filter = None
        if view_col is not None and 0 <= view_col < len(self.filter_inputs):
            try:
                self.filter_inputs[view_col].clear()
            except Exception:
                pass
            if view_col in self.filter_values:
                self.filter_values.pop(view_col, None)
        self._apply_filters()
        self._save_state()

    def _open_phone_list_filter(self, view_col: int) -> None:
        actual_col = self._view_to_data_column(view_col)
        phone_idx = self._find_phone_column(self.headers)
        if actual_col is None or (
            actual_col != phone_idx and self.column_formats.get(str(actual_col)) != "Số điện thoại"
        ):
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Lọc theo danh sách SĐT")
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel("Nhập danh sách SĐT, mỗi dòng một số:"))
        text_box = QTextEdit()
        if self.phone_list_filter:
            text_box.setPlainText("\n".join(sorted(self.phone_list_filter)))
        layout.addWidget(text_box)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.Accepted:
            return
        raw = text_box.toPlainText()
        numbers: set[str] = set()
        for line in raw.splitlines():
            norm = self._normalize_phone_value(line)
            if norm:
                numbers.add(norm)
        self.phone_list_filter = numbers if numbers else None
        self._apply_filters()
        self._save_state()

    def _apply_filters(self) -> None:
        try:
            phone_idx = self._find_phone_column(self.headers)
            if not self.filter_values and not self.phone_list_filter:
                self.rows = list(self.rows_all)
                self._set_model(self.headers, self.rows, auto_resize=getattr(self, "_force_autoresize", False))
                self._force_autoresize = False
                self._refresh_stats()
                return
            def norm_text(s: str) -> str:
                txt = str(s or "").lower().strip()
                txt = unicodedata.normalize("NFD", txt)
                txt = "".join(ch for ch in txt if unicodedata.category(ch) != "Mn")
                txt = re.sub(r"\s+", " ", txt)
                return txt
            filtered = []
            phone_list_set = self.phone_list_filter if self.phone_list_filter else None
            for row in self.rows_all:
                keep = True
                if phone_list_set and phone_idx is not None:
                    phone_val = "" if phone_idx >= len(row) else self._normalize_phone_value(row[phone_idx])
                    if not phone_val or phone_val not in phone_list_set:
                        continue
                for col, val in self.filter_values.items():
                    actual_col = self._view_to_data_column(col)
                    if actual_col is None or actual_col >= len(row):
                        continue
                    cell = "" if pd.isna(row[actual_col]) else str(row[actual_col])
                    is_phone = (
                        actual_col == phone_idx
                        or self.column_formats.get(str(actual_col)) == "Số điện thoại"
                    )
                    if is_phone:
                        needle = self._normalize_phone_value(val)
                        hay = self._normalize_phone_value(cell)
                        if needle and needle not in hay:
                            keep = False
                            break
                        if not needle and val.strip():
                            keep = False
                            break
                        continue
                    fmt = self.column_formats.get(str(actual_col))
                    if fmt in {"Số", "Số có dấu", "Tiền"}:
                        needle_num = self._normalize_number_string_main(val)
                        hay_num = self._normalize_number_string_main(cell)
                        if needle_num and needle_num not in hay_num:
                            keep = False
                            break
                        if not needle_num and val.strip():
                            keep = False
                            break
                        continue
                    if fmt in {"Ngày", "Thời gian"}:
                        needle_norm = norm_text(val)
                        cell_norm = norm_text(cell)
                        if needle_norm and needle_norm not in cell_norm:
                            keep = False
                            break
                        continue
                    if norm_text(val) not in norm_text(cell):
                        keep = False
                        break
                if keep:
                    filtered.append(row)
            self.rows = filtered
            self._set_model(self.headers, self.rows, auto_resize=getattr(self, "_force_autoresize", False))
            self._force_autoresize = False
            self._refresh_stats()
        except Exception:
            self._show_error_popup("Lỗi lọc dữ liệu", traceback.format_exc())

    def _normalize_header_name(self, text: str) -> str:
        name = str(text or "").strip().lower()
        name = unicodedata.normalize("NFD", name)
        name = "".join(ch for ch in name if unicodedata.category(ch) != "Mn")
        name = name.replace("đ", "d")
        name = re.sub(r"\s+", "", name)
        name = re.sub(r"[^0-9a-z]", "", name)
        return name

    def _normalize_phone_value(self, text: str) -> str:
        digits = re.sub(r"\D", "", str(text or ""))
        if not digits:
            return ""
        if digits.startswith("84") and len(digits) >= 10:
            digits = "0" + digits[2:]
        elif len(digits) == 9 and not digits.startswith("0"):
            digits = "0" + digits
        return digits

    def _normalize_number_string_main(self, text: str) -> str:
        clean = str(text or "").strip()
        if not clean:
            return ""
        sign = ""
        if clean.startswith("-"):
            sign = "-"
            clean = clean[1:]
        clean = clean.replace(" ", "").replace(",", "")
        parts = clean.split(".")
        if len(parts) > 2:
            dec = parts[-1]
            int_part = "".join(parts[:-1])
            clean = int_part + "." + dec
        return sign + clean

    def _format_phone_value(self, text: str) -> str:
        """Định dạng số điện thoại, giữ dấu chấm nếu đầu vào có."""
        raw = str(text or "")
        had_dots = "." in raw
        segment_lengths = [len(s) for s in raw.split(".")] if had_dots else []
        digits = re.sub(r"\D", "", raw)
        if not digits:
            return raw
        prefix_added = False
        if digits.startswith("84") and len(digits) >= 10:
            digits = "0" + digits[2:]
        elif len(digits) == 9 and not digits.startswith("0"):
            digits = "0" + digits
            prefix_added = True
        if had_dots:
            total_len = sum(segment_lengths)
            if len(digits) == total_len:
                parts = []
                idx = 0
                for ln in segment_lengths:
                    parts.append(digits[idx : idx + ln])
                    idx += ln
                return ".".join(parts)
            if prefix_added and len(digits) == total_len + 1 and segment_lengths:
                core = digits[-total_len:]
                parts = []
                idx = 0
                for ln in segment_lengths:
                    parts.append(core[idx : idx + ln])
                    idx += ln
                return "0" + ".".join(parts)
        return digits

    def _format_phone_display(self, digits: str) -> str:
        return self._format_phone(digits)

    def _dedupe_phone_rows(self, keep_row: Optional[List[Any]] = None) -> None:
        phone_idx = self._find_phone_column(self.headers)
        if phone_idx is None:
            return
        if keep_row is not None:
            if phone_idx >= len(keep_row):
                return
            target = self._normalize_phone_value(keep_row[phone_idx])
            if not target:
                return
            new_rows = []
            new_hist = []
            for row, hist in zip(self.rows_all, self.row_histories):
                if row is keep_row:
                    new_rows.append(row)
                    new_hist.append(hist)
                    continue
                val = self._normalize_phone_value(row[phone_idx]) if phone_idx < len(row) else ""
                if val == target:
                    continue
                new_rows.append(row)
                new_hist.append(hist)
            self.rows_all = new_rows
            self.row_histories = new_hist
            return
        last_idx = {}
        for idx, row in enumerate(self.rows_all):
            val = self._normalize_phone_value(row[phone_idx]) if phone_idx < len(row) else ""
            if not val:
                continue
            last_idx[val] = idx
        if not last_idx:
            return
        new_rows = []
        new_hist = []
        for idx, (row, hist) in enumerate(zip(self.rows_all, self.row_histories)):
            val = self._normalize_phone_value(row[phone_idx]) if phone_idx < len(row) else ""
            if val and last_idx.get(val) != idx:
                continue
            new_rows.append(row)
            new_hist.append(hist)
        self.rows_all = new_rows
        self.row_histories = new_hist

    def _format_source_label(self, path: Path, sheet_name: Optional[str]) -> str:
        file_name = path.name
        if sheet_name:
            return f"{sheet_name} - {file_name}"
        return file_name

    def _refresh_source_labels(self) -> None:
        if "Nguồn" not in self.headers or not self.rows_all:
            return
        idx = self.headers.index("Nguồn")
        changed = False
        sheet_cache: dict[str, Optional[str]] = {}
        for row in self.rows_all:
            if idx >= len(row):
                while len(row) <= idx:
                    row.append("")
            val = "" if pd.isna(row[idx]) else str(row[idx]).strip()
            if not val:
                continue
            if " - " in val:
                continue
            source_path = Path(val)
            file_name = source_path.name if val else ""
            if not file_name:
                continue
            sheet = None
            if val in sheet_cache:
                sheet = sheet_cache[val]
            else:
                if source_path.exists():
                    try:
                        xls = pd.ExcelFile(source_path)
                        sheet = xls.sheet_names[0] if xls.sheet_names else None
                    except Exception:
                        sheet = None
                else:
                    if self.current_path and self.current_path.exists() and Path(val).name == self.current_path.name:
                        sheet = self.current_sheet
                sheet_cache[val] = sheet
            label = f"{sheet} - {file_name}" if sheet else file_name
            if label != val:
                row[idx] = label
                changed = True
        if changed:
            self._apply_filters()
            self._persist_now()

    def _find_phone_column(self, headers: List[str]) -> Optional[int]:
        targets = {"sdt", "sodienthoai", "sodt", "phone", "sophone", "tel"}
        for idx, name in enumerate(headers):
            if self._normalize_header_name(name) in targets:
                return idx
        return None

    def _status_column_index(self) -> Optional[int]:
        """Tìm cột 'Trạng thái' (bỏ dấu, không phân biệt hoa thường)."""
        targets = ["trangthai", "tinhtrang", "khoa"]
        for idx, name in enumerate(self.headers):
            norm = self._normalize_header_name(name)
            if any(t in norm for t in targets):
                return idx
        return None

    def _auto_color_status_column(self, color: str = "#fff2cc") -> None:
        """Tô nền mặc định cho cột Trạng thái (không đè lên màu người dùng đã đặt)."""
        status_idx = self._status_column_index()
        if status_idx is None or not self.rows_all:
            return
        changed = False
        old_defaults = {"#fff59d"}  # màu cũ ít nhìn thấy hơn
        for g_row in range(len(self.rows_all)):
            key = f"{g_row}_{status_idx}"
            style = self.cell_styles.get(key, {})
            if "bg" in style and style["bg"] and style["bg"] not in old_defaults:
                continue
            style = dict(style)
            style["bg"] = color
            self.cell_styles[key] = style
            changed = True
        if changed:
            view_col = status_idx + (1 if self.show_index_column else 0)
            model = self.table.model()
            if model and model.rowCount() > 0 and 0 <= view_col < model.columnCount():
                top_left = model.index(0, view_col)
                bottom_right = model.index(model.rowCount() - 1, view_col)
                model.dataChanged.emit(top_left, bottom_right, [Qt.BackgroundRole])
            self._persist_now()

    def _append_from_file(self, path: Path, sheet_name: Optional[str] = None) -> None:
        try:
            headers_file, rows_file, used_sheet = load_table_data(path, sheet_name=sheet_name)
        except Exception as exc:
            QMessageBox.critical(self, "Lỗi đọc file", str(exc))
            return
        # Nếu đang ở trang trống chỉ có cột meta, reset để lấy full cột file
        if (not self.rows_all) and self.headers and all(h in ("Nguồn", "Thay đổi lúc") for h in self.headers):
            self.headers = []
            self.source_headers = []
            self.row_histories = []
        headers_file = list(headers_file)
        headers_file, rows_file = self._apply_template_to_import(headers_file, rows_file)
        # Nếu đang dùng mẫu và header còn trống, giữ header từ mẫu, không lấy header file
        if not self.headers and self.active_template:
            tpl = self._get_template_by_name(self.active_template)
            if tpl and isinstance(tpl.get("headers"), list):
                self.headers = list(tpl.get("headers", []))
                self.source_headers = list(tpl.get("source_headers", self.headers))
        if not self.headers:
            self.current_path = path
            self.current_sheet = used_sheet
            base_headers = [h for h in headers_file if str(h).strip() not in ("Nguồn", "Thay đổi lúc")]
            now_text = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
            # Xây lại headers: các cột gốc + Thay đổi lúc + Nguồn (Nguồn ở cuối)
            self.headers = list(base_headers) + ["Thay đổi lúc", "Nguồn"]
            self.source_headers = list(base_headers) + ["Thay đổi lúc", "Nguồn"]
            target_len = len(self.headers)
            rows_norm = []
            for row in rows_file:
                r = list(row[: len(base_headers)])
                if len(r) < len(base_headers):
                    r += [""] * (len(base_headers) - len(r))
                r.append(now_text)  # Thay đổi lúc
                r.append(self._format_source_label(path, used_sheet))  # Nguồn
                rows_norm.append(r)
            self.row_histories = [[now_text] for _ in rows_norm]
            self.rows_all = rows_norm
            self.sort_orders.clear()
            self._auto_detect_formats()
            self._apply_default_alignment()
            self._ensure_change_column()
            self._ensure_row_histories()
            self._force_autoresize = True
            self._apply_filters()
            self._persist_now()
            QTimer.singleShot(0, lambda: self.table.verticalScrollBar().setValue(self.table.verticalScrollBar().maximum()))
            return
        self._ensure_source_column()
        self._ensure_change_column()
        now_text = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
        header_map = {self._normalize_header_name(h): idx for idx, h in enumerate(headers_file)}
        source_idx = self.headers.index("Nguồn")
        change_idx = self._change_col_idx()
        mapped_rows: List[List[Any]] = []
        mapped_hist: List[List[str]] = []
        for row in rows_file:
            new_row = ["" for _ in range(len(self.headers))]
            for idx, header in enumerate(self.headers):
                if idx == source_idx:
                    continue
                key = self._normalize_header_name(header)
                src_idx = header_map.get(key)
                if src_idx is None or src_idx >= len(row):
                    continue
                new_row[idx] = row[src_idx]
            new_row[source_idx] = self._format_source_label(path, used_sheet)
            if change_idx is not None:
                new_row[change_idx] = now_text
            mapped_rows.append(new_row)
            mapped_hist.append([now_text])
        phone_idx = self._find_phone_column(self.headers)
        if phone_idx is not None:
            deduped: dict[str, tuple[List[Any], List[str]]] = {}
            empty_counter = 0
            for row, hist in zip(mapped_rows, mapped_hist):
                val = "" if phone_idx >= len(row) else self._normalize_phone_value(row[phone_idx])
                key = val if val else f"__empty__{empty_counter}"
                if not val:
                    empty_counter += 1
                deduped[key] = (row, hist)
            mapped_rows = [v[0] for v in deduped.values()]
            mapped_hist = [v[1] for v in deduped.values()]
            new_sdts = {self._normalize_phone_value(r[phone_idx]) for r in mapped_rows if phone_idx < len(r)}
            if new_sdts:
                kept_rows = []
                kept_hist = []
                for r, h in zip(self.rows_all, self.row_histories):
                    val = self._normalize_phone_value(r[phone_idx]) if phone_idx < len(r) else ""
                    if val in new_sdts:
                        continue
                    kept_rows.append(r)
                    kept_hist.append(h)
                self.rows_all = kept_rows
                self.row_histories = kept_hist
        self.rows_all.extend(mapped_rows)
        self.row_histories.extend(mapped_hist)
        self._auto_detect_formats()
        self._apply_default_alignment()
        self._apply_fixed_width_rules()
        self._ensure_row_histories()
        self.sort_orders.clear()
        self._force_autoresize = True
        self._apply_filters()
        self._persist_now()
        QTimer.singleShot(0, lambda: self.table.verticalScrollBar().setValue(self.table.verticalScrollBar().maximum()))

    def _select_sheet_for_add(self, path: Path) -> Optional[str]:
        try:
            xls = pd.ExcelFile(path)
        except Exception as exc:
            QMessageBox.critical(self, "Lỗi đọc file", str(exc))
            return None
        sheets = list(xls.sheet_names or [])
        if not sheets:
            return None
        if len(sheets) == 1:
            return sheets[0]
        dialog = QDialog(self)
        dialog.setWindowTitle("Chọn sheet để thêm")
        layout = QVBoxLayout(dialog)
        list_widget = QListWidget()
        for name in sheets:
            list_widget.addItem(QListWidgetItem(name))
        list_widget.setCurrentRow(0)
        layout.addWidget(list_widget)
        buttons = QDialogButtonBox()
        btn_add = buttons.addButton("Thêm", QDialogButtonBox.AcceptRole)
        btn_add_all = buttons.addButton("Thêm tất cả", QDialogButtonBox.ActionRole)
        buttons.addButton(QDialogButtonBox.Cancel)
        btn_add.clicked.connect(dialog.accept)
        btn_add_all.clicked.connect(lambda: dialog.done(2))
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        result = dialog.exec()
        if result == 2:
            return "__ALL__"
        if result != QDialog.Accepted:
            return None
        item = list_widget.currentItem()
        return item.text() if item else None

    def _append_all_sheets(self, path: Path) -> None:
        try:
            xls = pd.ExcelFile(path)
            sheets = list(xls.sheet_names or [])
        except Exception as exc:
            QMessageBox.critical(self, "Lỗi đọc file", str(exc))
            return
        if not sheets:
            return
        for name in sheets:
            self._append_from_file(path, name)

    def _update_filter_letter_styles(self) -> None:
        selected_columns = set()
        sm = self.table.selectionModel()
        if sm:
            selected_columns = {idx.column() for idx in sm.selectedIndexes()}
        for idx, lbl in enumerate(self.filter_letter_labels):
            if idx in selected_columns:
                lbl.setStyleSheet("color: #00f2ff; font-weight: bold;")
            else:
                lbl.setStyleSheet("color: #9ba0b5; font-weight: normal;")
        self._update_status_bar()

    def _apply_filters_and_save(self) -> None:
        self._apply_filters()
        self._save_state()
        # lưu Excel sẽ do autosave timer đảm nhiệm

    def _normalize_rows(self, rows: List[List[Any]], target_len: int) -> List[List[Any]]:
        norm = []
        for r in rows:
            row = list(r)
            if len(row) < target_len:
                row.extend([""] * (target_len - len(row)))
            elif len(row) > target_len:
                row = row[:target_len]
            norm.append(row)
        return norm

    def _ensure_source_column(self) -> None:
        if "Nguồn" not in self.headers:
            self.headers.append("Nguồn")
            self.source_headers.append("Nguồn")
            for row in self.rows:
                row.append("")
            for row in self.rows_all:
                row.append("")
        # đảm bảo Nguồn nằm cuối cùng
        src_idx = self.headers.index("Nguồn")
        last_idx = len(self.headers) - 1
        if src_idx != last_idx:
            self._move_column(src_idx, last_idx)

    def _change_col_idx(self) -> Optional[int]:
        try:
            return self.headers.index("Thay đổi lúc")
        except ValueError:
            return None

    def _shift_meta_on_insert(self, idx: int) -> None:
        """Dịch các mapping align/width/format/filter khi chèn thêm cột ở idx."""
        new_align = {}
        for k, v in self.alignment_map.items():
            c = int(k)
            new_align[str(c + 1) if c >= idx else str(c)] = v
        self.alignment_map = new_align

        new_widths = {}
        for k, v in self.saved_column_widths.items():
            c = int(k)
            new_widths[str(c + 1) if c >= idx else str(c)] = v
        self.saved_column_widths = new_widths

        new_formats = {}
        for k, v in self.column_formats.items():
            c = int(k)
            new_formats[str(c + 1) if c >= idx else str(c)] = v
        self.column_formats = new_formats

        self.filter_values = { (k + 1 if k >= idx else k): v for k, v in self.filter_values.items() }

    def _move_column(self, from_idx: int, to_idx: int) -> None:
        """Di chuyển một cột, kèm theo align/width/format/filter."""
        if from_idx == to_idx or from_idx < 0 or to_idx < 0:
            return
        def _move(lst: List[Any]) -> None:
            if from_idx >= len(lst):
                return
            val = lst.pop(from_idx)
            lst.insert(min(to_idx, len(lst)), val)
        _move(self.headers)
        _move(self.source_headers)
        for row in self.rows:
            _move(row)
        for row in self.rows_all:
            _move(row)
        def _reindex(mapping: dict[str, int]) -> dict[str, int]:
            out = {}
            for k, v in mapping.items():
                c = int(k)
                if c == from_idx:
                    c = to_idx
                elif from_idx < to_idx and from_idx < c <= to_idx:
                    c -= 1
                elif to_idx < from_idx and to_idx <= c < from_idx:
                    c += 1
                out[str(c)] = v
            return out
        self.alignment_map = _reindex(self.alignment_map)
        self.saved_column_widths = _reindex(self.saved_column_widths)
        self.column_formats = _reindex(self.column_formats)
        new_filters: dict[int, str] = {}
        for k, v in self.filter_values.items():
            c = k
            if c == from_idx:
                c = to_idx
            elif from_idx < to_idx and from_idx < c <= to_idx:
                c -= 1
            elif to_idx < from_idx and to_idx <= c < from_idx:
                c += 1
            new_filters[c] = v
        self.filter_values = new_filters

    def _ensure_change_column(self) -> None:
        """Đảm bảo cột 'Thay đổi lúc' tồn tại và nằm ngay bên trái 'Nguồn' (Nguồn cuối cùng)."""
        self._ensure_source_column()
        src_idx = self.headers.index("Nguồn")
        change_idx = self._change_col_idx()
        if change_idx is None:
            insert_at = src_idx  # trước nguồn
            self._shift_meta_on_insert(insert_at)
            self.headers.insert(insert_at, "Thay đổi lúc")
            self.source_headers.insert(insert_at, "Thay đổi lúc")
            for row in self.rows:
                row.insert(insert_at, "")
            for row in self.rows_all:
                row.insert(insert_at, "")
            change_idx = insert_at
            src_idx += 1  # nguồn bị đẩy sang phải
        # nếu không đúng vị trí (src_idx-1)
        desired = src_idx - 1
        if change_idx != desired:
            self._move_column(change_idx, desired)

    def _row_index_from_view(self, view_row: int) -> Optional[int]:
        if view_row < 0 or view_row >= len(self.rows):
            return None
        row_ref = self.rows[view_row]
        for idx, r in enumerate(self.rows_all):
            if r is row_ref:
                return idx
        try:
            return self.rows_all.index(row_ref)
        except ValueError:
            return None

    def _ensure_row_histories(self) -> None:
        """Đảm bảo row_histories khớp với rows_all và có sẵn thời gian."""
        target_len = len(self.rows_all)
        while len(self.row_histories) < target_len:
            self.row_histories.append([])
        if len(self.row_histories) > target_len:
            self.row_histories = self.row_histories[:target_len]
        change_idx = self._change_col_idx()
        now_text = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
        for i, row in enumerate(self.rows_all):
            if change_idx is not None:
                while len(row) <= change_idx:
                    row.append("")
            hist = self.row_histories[i]
            if change_idx is not None:
                cell = "" if change_idx >= len(row) else str(row[change_idx])
                if not cell.strip():
                    row[change_idx] = now_text
                if not hist:
                    hist.append(now_text)
                if not hist:
                    hist.append(now_text)

    def _auto_detect_formats(self) -> None:
        if not self.headers:
            return
        for idx, name in enumerate(self.headers):
            norm = self._normalize_header_name(name)
            fmt = None
            if any(key in norm for key in ["hsd", "han", "ngay"]):
                fmt = "Ngày"
            elif any(key in norm for key in ["sdt", "sodienthoai", "phone", "tel"]) or norm == "so":
                fmt = "Số điện thoại"
            elif norm in {"tkc", "tkkm"} or any(key in norm for key in ["sotien", "soluong"]):
                fmt = "Số có dấu"
            if fmt:
                self.column_formats[str(idx)] = fmt

    def _apply_default_alignment(self) -> None:
        if not self.headers:
            return
        for idx in range(len(self.headers)):
            self.alignment_map[str(idx)] = int(Qt.AlignHCenter | Qt.AlignVCenter)

    def _apply_fixed_width_rules(self) -> None:
        if not self.headers:
            return
        rules = [
            (["sdt", "sodienthoai", "phone", "tel"], 83),
            (["seri", "serial"], 137),
            (["trangthai", "trangthaikhoa", "tinhtrang"], 100),
            (["nhamang"], 85),
            (["taikhoan", "tk", "tkc", "tkkm"], 80),
            (["ngay", "hsd", "han"], 92),
            (["thaydoiluc"], 120),
            (["nguon"], 120),
        ]
        for idx, name in enumerate(self.headers):
            norm = self._normalize_header_name(name)
            for keys, w in rules:
                if any(k in norm for k in keys):
                    self.saved_column_widths[str(idx)] = w
                    break

    def _auto_resize_columns(self, max_width: int = 200) -> None:
        if not self.table.model():
            return
        model = self.table.model()
        fm = self.table.fontMetrics()
        padding = 16
        sample_rows = min(model.rowCount(), 300)
        fixed_rules = [
            (["sdt", "so", "sodienthoai", "phone", "tel", "sđt"], 83),
            (["seri", "serial", "seria"], 137),
            (["trangthai", "trangthaikhoa", "tinhtrang", "trangthai"], 100),
            (["nhamang"], 85),
            (["taikhoan", "tk", "tkc", "tkkm"], 80),
            (["ngay", "hsd", "han"], 92),
            (["thaydoiluc"], 120),
            (["nguon"], 120),
        ]
        for col in range(model.columnCount()):
            header_text = str(model.headerData(col, Qt.Horizontal, Qt.DisplayRole) or "")
            min_w = fm.horizontalAdvance(header_text) + padding
            width = min_w
            for r in range(sample_rows):
                idx = model.index(r, col)
                text = str(model.data(idx, Qt.DisplayRole) or "")
                width = max(width, fm.horizontalAdvance(text) + padding)
            # áp dụng rule cố định theo tên header
            norm = self._normalize_header_name(header_text)
            fixed = None
            for keys, w in fixed_rules:
                if any(k in norm for k in keys):
                    fixed = w
                    break
            if fixed is not None:
                width = fixed
            else:
                width = min(width, max_width)
            width = max(min_w if fixed is None else 0, min(width, max_width if fixed is None else width))
            self.table.setColumnWidth(col, width)
            self.saved_column_widths[str(col)] = width

    # ============ Statistics ============ #
    def _refresh_stats(self) -> None:
        # tránh đệ quy do signal lặp lại khi setCurrentText / setDate
        if getattr(self, "_refreshing_stats", False):
            return
        if not hasattr(self, "stats_nm_table"):
            return
        # yêu cầu chọn mẫu trước
        if not hasattr(self, "stats_template") or self.stats_template.currentIndex() <= 0:
            self.stats_nm_table.setRowCount(0)
            return

        self._refreshing_stats = True
        try:
            sel_tpl = self.stats_template.currentText()
            tpl = self._get_template_by_name(sel_tpl)
            # Ưu tiên dữ liệu đang hiển thị (đang mở) nếu có
            if self.rows_all:
                headers = self.headers
                rows = self.rows_all
            else:
                headers = tpl.get("headers", []) if tpl else []
                rows = tpl.get("rows", []) if tpl else []
            if not headers or rows is None or len(rows) == 0:
                self.stats_nm_table.setRowCount(0)
                return

            # xác định cột
            hsd_idx = None
            nhap_idx = None
            psc_idx = None
            nm_idx = None
            state_idx = None
            tkc_idx = None
            tkkm_idx = None
            pos_idx = None
            lo_idx = None
            source_idx = None
            phone_idx = None
            for i, h in enumerate(headers):
                norm = self._normalize_header_name(h)
                if hsd_idx is None and any(k in norm for k in ["hsd", "han"]):
                    hsd_idx = i
                if nhap_idx is None and "nhap" in norm:
                    nhap_idx = i
                if psc_idx is None and "psc" in norm:
                    psc_idx = i
                if nm_idx is None and "nhamang" in norm:
                    nm_idx = i
                if state_idx is None and any(k in norm for k in ["trangthai", "tinhtrang", "khoa"]):
                    state_idx = i
                if tkc_idx is None and "tkc" in norm:
                    tkc_idx = i
                if tkkm_idx is None and "tkkm" in norm:
                    tkkm_idx = i
                if pos_idx is None and ("vitri" in norm or "vi tri" in norm):
                    pos_idx = i
                if lo_idx is None and ("losim" in norm or "lo" == norm):
                    lo_idx = i
                if source_idx is None and "nguon" in norm:
                    source_idx = i
                if phone_idx is None and (any(k in norm for k in ["sdt", "sodienthoai", "phone", "tel"]) or norm == "so"):
                    phone_idx = i
            if phone_idx is None:
                # fallback theo định dạng
                for i, fmt in self.column_formats.items():
                    if fmt == "Số điện thoại":
                        phone_idx = int(i)
                        break

            def custom_date_in_range(row, idx, month_cb, de_from, de_to):
                if idx is None or idx >= len(row):
                    return True
                text = month_cb.currentText() if month_cb else "Tất cả"
                min_dt = QDate(1900, 1, 1)
                # nếu chọn Tất cả và không nhập ngày => bỏ qua lọc
                if text == "Tất cả" and de_from.date() == min_dt and de_to.date() == min_dt:
                    return True
                val = row[idx]
                dt = parse_datetime_string("" if pd.isna(val) else str(val), include_time=False)
                if not dt:
                    return True
                d = dt.date()
                f_dt = de_from.date()
                t_dt = de_to.date()
                f = None if f_dt == min_dt else f_dt.toPython()
                t = None if t_dt == min_dt else t_dt.toPython()
                if f and d < f:
                    return False
                if t and d > t:
                    return False
                return True

            def match_text(row, idx, needle: str) -> bool:
                if not needle or needle.lower() == "tất cả":
                    return True
                if idx is None or idx >= len(row):
                    return False
                val = "" if pd.isna(row[idx]) else str(row[idx])
                if needle.lower() == "trống":
                    return val.strip() == ""
                return needle.lower() in val.lower()

            def parse_number(text: str):
                if not text:
                    return None
                clean = text.replace(",", "").replace(" ", "")
                try:
                    val = float(clean)
                    return val if math.isfinite(val) else None
                except Exception:
                    return None

            def match_numeric(row, idx, op_combo, v1_combo, v2_combo) -> bool:
                if idx is None or idx >= len(row):
                    return True
                op = op_combo.currentText() if op_combo else "="
                v1 = parse_number(v1_combo.currentText()) if v1_combo else None
                v2 = parse_number(v2_combo.currentText()) if v2_combo else None
                if v1 is None and op != "Giữa":
                    return True
                val = parse_number("" if pd.isna(row[idx]) else str(row[idx]))
                if val is None:
                    return False
                if op == "=":
                    return val == v1
                if op == ">":
                    return val > (v1 if v1 is not None else val)
                if op == "<":
                    return val < (v1 if v1 is not None else val)
                if op == "≥":
                    return val >= (v1 if v1 is not None else val)
                if op == "≤":
                    return val <= (v1 if v1 is not None else val)
                if op == "Giữa":
                    if v1 is None and v2 is None:
                        return True
                    if v1 is None or v2 is None:
                        return False
                    lo, hi = sorted([v1, v2])
                    return lo <= val <= hi
                return True

            # Cập nhật danh sách giá trị có sẵn cho các combo bộ lọc
            def fill_combo(combo: QComboBox, col_idx: Optional[int], limit: int = 200):
                if combo is None:
                    return
                current = combo.currentText()
                items = ["Tất cả", "Trống"]
                if col_idx is not None:
                    seen = set()
                    for r in rows:
                        if col_idx >= len(r):
                            continue
                        val = "" if pd.isna(r[col_idx]) else str(r[col_idx]).strip()
                        if not val:
                            continue
                        if val in seen:
                            continue
                        seen.add(val)
                        items.append(val)
                        if len(items) >= limit:
                            break
                combo.blockSignals(True)
                combo.clear()
                combo.addItems(items)
                combo.setCurrentText(current if current else "")
                combo.blockSignals(False)

            # cập nhật source cho combo filters
            fill_combo(self.stats_pos_input, pos_idx)
            fill_combo(self.stats_nm_input, nm_idx)
            fill_combo(self.stats_lo_input, lo_idx)
            fill_combo(self.stats_state_input, state_idx)
            fill_combo(self.stats_tkc_v1, tkc_idx)
            fill_combo(self.stats_tkc_v2, tkc_idx)
            fill_combo(self.stats_tkkm_v1, tkkm_idx)
            fill_combo(self.stats_tkkm_v2, tkkm_idx)

            pos_filter = self.stats_pos_input.currentText().strip() if hasattr(self, "stats_pos_input") else ""
            nm_filter = self.stats_nm_input.currentText().strip() if hasattr(self, "stats_nm_input") else ""
            lo_filter = self.stats_lo_input.currentText().strip() if hasattr(self, "stats_lo_input") else ""
            state_filter = self.stats_state_input.currentText().strip() if hasattr(self, "stats_state_input") else ""

            filtered_rows = [
                r
                for r in rows
                if custom_date_in_range(r, hsd_idx, self.stats_hsd_month, self.stats_hsd_from, self.stats_hsd_to)
                and custom_date_in_range(r, nhap_idx, self.stats_nhap_month, self.stats_nhap_from, self.stats_nhap_to)
                and custom_date_in_range(r, psc_idx, self.stats_psc_month, self.stats_psc_from, self.stats_psc_to)
                and match_text(r, pos_idx, pos_filter)
                and match_text(r, nm_idx, nm_filter)
                and match_text(r, lo_idx, lo_filter)
                and match_text(r, state_idx, state_filter)
                and match_numeric(r, tkc_idx, self.stats_tkc_op, self.stats_tkc_v1, self.stats_tkc_v2)
                and match_numeric(r, tkkm_idx, self.stats_tkkm_op, self.stats_tkkm_v1, self.stats_tkkm_v2)
            ]
            self._stats_filtered_rows = filtered_rows
            self._stats_filtered_headers = headers
            total_sim = len(filtered_rows)

            def norm_nm(name: str) -> str:
                low = name.lower().strip()
                compact = low.replace(" ", "")
                if compact in {"vn", "vina", "vinaphone"}:
                    return "Vinaphone"
                if compact in {"mb", "mobi", "mobiphone", "mobifone"}:
                    return "Mobifone"
                if compact in {"vt", "viettel"}:
                    return "Viettel"
                if compact in {"vnmb", "vietnammobile", "vnm", "vietnamobile"}:
                    return "Vietnammobile"
                if compact in {"itel", "itelecom", "itelcom"}:
                    return "iTel"
                return name if name else "(trống)"

            def count_nm(idx):
                counter = {}
                if idx is None:
                    return counter
                for r in filtered_rows:
                    if idx >= len(r):
                        continue
                    val = "" if pd.isna(r[idx]) else str(r[idx]).strip()
                    key = norm_nm(val)
                    counter[key] = counter.get(key, 0) + 1
                return counter

            def count_by(idx):
                counter = {}
                if idx is None:
                    return counter
                for r in filtered_rows:
                    if idx >= len(r):
                        continue
                    val = "" if pd.isna(r[idx]) else str(r[idx]).strip()
                    key = val if val else "(trống)"
                    counter[key] = counter.get(key, 0) + 1
                return counter

            # Đếm theo nhà mạng + trạng thái + phân bổ tháng HSD + TKC threshold
            nm_stats = {}
            tk_threshold = self.stats_tk_threshold or 250
            for r in filtered_rows:
                nm_raw = ""
                if nm_idx is not None and nm_idx < len(r):
                    nm_raw = "" if pd.isna(r[nm_idx]) else str(r[nm_idx]).strip()
                nm_key = norm_nm(nm_raw)
                st_val = "" if state_idx is None or state_idx >= len(r) or pd.isna(r[state_idx]) else str(r[state_idx]).strip()
                low = st_val.lower()
                low_norm = unicodedata.normalize("NFD", low)
                low_norm = "".join(ch for ch in low_norm if unicodedata.category(ch) != "Mn")
                # dùng chuỗi bỏ dấu để nhận diện trạng thái
                if ("2chieu" in low_norm) or ("2 chieu" in low_norm):
                    st_key = "Chặn 2 chiều"
                elif "chan" in low_norm:
                    st_key = "Chặn"
                elif "khoa" in low_norm:
                    st_key = "Khóa"
                elif "nguyen" in low_norm and "kit" in low_norm:
                    st_key = "Nguyên kit"
                else:
                    st_key = None
                entry = nm_stats.setdefault(
                    nm_key,
                    {
                        "total": 0,
                        "Khóa": 0,
                        "Chặn": 0,
                        "Chặn 2 chiều": 0,
                        "Nguyên kit": 0,
                        "months_lt": [0] * 12,
                        "months_gt": [0] * 12,
                        "months_lt_sum": [0.0] * 12,
                        "months_gt_sum": [0.0] * 12,
                        "months_lt_min": [None] * 12,
                        "months_lt_max": [None] * 12,
                        "months_gt_min": [None] * 12,
                        "months_gt_max": [None] * 12,
                        "months_lt_values": [[] for _ in range(12)],
                        "months_gt_values": [[] for _ in range(12)],
                        "tk_lt": 0,
                        "tk_gt": 0,
                        "tk_lt_sum": 0.0,
                        "tk_gt_sum": 0.0,
                        "tk_lt_min": None,
                        "tk_lt_max": None,
                        "tk_gt_min": None,
                        "tk_gt_max": None,
                        "tk_lt_values": [],
                        "tk_gt_values": [],
                        "tk_count": 0,
                        "tk_sum": 0.0,
                        "tk_min": None,
                        "tk_max": None,
                        "tk_values": [],
                    },
                )
                entry["total"] += 1
                if st_key:
                    entry[st_key] += 1
                # tháng HSD
                tk_val = parse_number(
                    "" if tkc_idx is None or tkc_idx >= len(r) or pd.isna(r[tkc_idx]) else str(r[tkc_idx])
                )
                if hsd_idx is not None and hsd_idx < len(r):
                    hsd_val = "" if pd.isna(r[hsd_idx]) else str(r[hsd_idx])
                    hsd_dt = parse_datetime_string(hsd_val, include_time=False)
                    if hsd_dt:
                        m = hsd_dt.month
                        if 1 <= m <= 12 and tk_val is not None:
                            if tk_val < tk_threshold:
                                entry["months_lt"][m - 1] += 1
                                entry["months_lt_sum"][m - 1] += tk_val
                                entry["months_lt_min"][m - 1] = (
                                    tk_val if entry["months_lt_min"][m - 1] is None else min(entry["months_lt_min"][m - 1], tk_val)
                                )
                                entry["months_lt_max"][m - 1] = (
                                    tk_val if entry["months_lt_max"][m - 1] is None else max(entry["months_lt_max"][m - 1], tk_val)
                                )
                                entry["months_lt_values"][m - 1].append(tk_val)
                            elif tk_val > tk_threshold:
                                entry["months_gt"][m - 1] += 1
                                entry["months_gt_sum"][m - 1] += tk_val
                                entry["months_gt_min"][m - 1] = (
                                    tk_val if entry["months_gt_min"][m - 1] is None else min(entry["months_gt_min"][m - 1], tk_val)
                                )
                                entry["months_gt_max"][m - 1] = (
                                    tk_val if entry["months_gt_max"][m - 1] is None else max(entry["months_gt_max"][m - 1], tk_val)
                                )
                                entry["months_gt_values"][m - 1].append(tk_val)
                # TKC threshold tổng
                if tk_val is not None:
                    if tk_val < tk_threshold:
                        entry["tk_lt"] += 1
                        entry["tk_lt_sum"] += tk_val
                        entry["tk_lt_min"] = tk_val if entry["tk_lt_min"] is None else min(entry["tk_lt_min"], tk_val)
                        entry["tk_lt_max"] = tk_val if entry["tk_lt_max"] is None else max(entry["tk_lt_max"], tk_val)
                        entry["tk_lt_values"].append(tk_val)
                    elif tk_val > tk_threshold:
                        entry["tk_gt"] += 1
                        entry["tk_gt_sum"] += tk_val
                        entry["tk_gt_min"] = tk_val if entry["tk_gt_min"] is None else min(entry["tk_gt_min"], tk_val)
                        entry["tk_gt_max"] = tk_val if entry["tk_gt_max"] is None else max(entry["tk_gt_max"], tk_val)
                        entry["tk_gt_values"].append(tk_val)
                    entry["tk_count"] += 1
                    entry["tk_sum"] += tk_val
                    entry["tk_min"] = tk_val if entry["tk_min"] is None else min(entry["tk_min"], tk_val)
                    entry["tk_max"] = tk_val if entry["tk_max"] is None else max(entry["tk_max"], tk_val)
                    entry["tk_values"].append(tk_val)

            def fill_nm_table(data_dict):
                def set_cell(r: int, c: int, text: str):
                    item = QTableWidgetItem(text)
                    item.setTextAlignment(Qt.AlignCenter)
                    self.stats_nm_table.setItem(r, c, item)

                rows_n = len(data_dict)
                self.stats_nm_table.setRowCount(rows_n + 1 if rows_n else 1)
                total_tot = total_khoa = total_chan = total_chan2 = total_ngk = 0
                total_months_lt = [0] * 12
                total_months_gt = [0] * 12
                total_months_lt_sum = [0.0] * 12
                total_months_gt_sum = [0.0] * 12
                total_months_lt_min = [None] * 12
                total_months_lt_max = [None] * 12
                total_months_gt_min = [None] * 12
                total_months_gt_max = [None] * 12
                total_months_lt_values = [[] for _ in range(12)]
                total_months_gt_values = [[] for _ in range(12)]
                total_tk_lt = total_tk_gt = 0
                total_tk_lt_sum = total_tk_gt_sum = 0.0
                total_tk_lt_min = total_tk_gt_min = None
                total_tk_lt_max = total_tk_gt_max = None
                total_tk_count = 0
                total_tk_sum = 0.0
                total_tk_min = None
                total_tk_max = None
                total_tk_values = []
                total_tk_lt_values = []
                total_tk_gt_values = []
                self.stats_row_stats = []
                for r, (nm, vals) in enumerate(sorted(data_dict.items(), key=lambda x: (-x[1]["total"], x[0]))):
                    set_cell(r, 0, str(nm))
                    set_cell(r, 1, f'{vals["total"]:,}')
                    normal = vals["total"] - (
                        vals.get("Nguyên kit", 0) + vals["Khóa"] + vals["Chặn"] + vals["Chặn 2 chiều"]
                    )
                    normal = max(normal, 0)
                    set_cell(r, 2, f"{normal:,}")
                    set_cell(r, 3, f'{vals.get("Nguyên kit",0):,}')
                    set_cell(r, 4, f'{vals["Khóa"]:,}')
                    set_cell(r, 5, f'{vals["Chặn"]:,}')
                    set_cell(r, 6, f'{vals["Chặn 2 chiều"]:,}')
                    months_lt = vals.get("months_lt", [0] * 12)
                    months_gt = vals.get("months_gt", [0] * 12)
                    months_lt_sum = vals.get("months_lt_sum", [0.0] * 12)
                    months_gt_sum = vals.get("months_gt_sum", [0.0] * 12)
                    months_lt_min = vals.get("months_lt_min", [None] * 12)
                    months_lt_max = vals.get("months_lt_max", [None] * 12)
                    months_gt_min = vals.get("months_gt_min", [None] * 12)
                    months_gt_max = vals.get("months_gt_max", [None] * 12)
                    months_lt_values = vals.get("months_lt_values", [[] for _ in range(12)])
                    months_gt_values = vals.get("months_gt_values", [[] for _ in range(12)])
                    col_base = 7
                    for idx_order, m_idx in enumerate(self.stats_month_order):
                        set_cell(r, col_base + idx_order * 2, f"{months_lt[m_idx]:,}")
                        set_cell(r, col_base + idx_order * 2 + 1, f"{months_gt[m_idx]:,}")
                        total_months_lt[m_idx] += months_lt[m_idx]
                        total_months_gt[m_idx] += months_gt[m_idx]
                        total_months_lt_sum[m_idx] += months_lt_sum[m_idx]
                        total_months_gt_sum[m_idx] += months_gt_sum[m_idx]
                        total_months_lt_values[m_idx].extend(months_lt_values[m_idx])
                        total_months_gt_values[m_idx].extend(months_gt_values[m_idx])
                        if months_lt_min[m_idx] is not None:
                            total_months_lt_min[m_idx] = months_lt_min[m_idx] if total_months_lt_min[m_idx] is None else min(total_months_lt_min[m_idx], months_lt_min[m_idx])
                        if months_lt_max[m_idx] is not None:
                            total_months_lt_max[m_idx] = months_lt_max[m_idx] if total_months_lt_max[m_idx] is None else max(total_months_lt_max[m_idx], months_lt_max[m_idx])
                        if months_gt_min[m_idx] is not None:
                            total_months_gt_min[m_idx] = months_gt_min[m_idx] if total_months_gt_min[m_idx] is None else min(total_months_gt_min[m_idx], months_gt_min[m_idx])
                        if months_gt_max[m_idx] is not None:
                            total_months_gt_max[m_idx] = months_gt_max[m_idx] if total_months_gt_max[m_idx] is None else max(total_months_gt_max[m_idx], months_gt_max[m_idx])
                    last_col = col_base + len(self.stats_month_order) * 2
                    set_cell(r, last_col, f"{vals.get('tk_lt',0):,}")
                    set_cell(r, last_col + 1, f"{vals.get('tk_gt',0):,}")
                    total_tot += vals["total"]
                    total_khoa += vals["Khóa"]
                    total_chan += vals["Chặn"]
                    total_chan2 += vals["Chặn 2 chiều"]
                    total_ngk += vals.get("Nguyên kit", 0)
                    total_tk_lt += vals.get("tk_lt", 0)
                    total_tk_gt += vals.get("tk_gt", 0)
                    total_tk_lt_sum += vals.get("tk_lt_sum", 0.0)
                    total_tk_gt_sum += vals.get("tk_gt_sum", 0.0)
                    total_tk_lt_values.extend(vals.get("tk_lt_values", []))
                    total_tk_gt_values.extend(vals.get("tk_gt_values", []))
                    total_tk_values.extend(vals.get("tk_values", []))
                    tk_lt_min = vals.get("tk_lt_min")
                    tk_lt_max = vals.get("tk_lt_max")
                    tk_gt_min = vals.get("tk_gt_min")
                    tk_gt_max = vals.get("tk_gt_max")
                    if tk_lt_min is not None:
                        total_tk_lt_min = tk_lt_min if total_tk_lt_min is None else min(total_tk_lt_min, tk_lt_min)
                    if tk_lt_max is not None:
                        total_tk_lt_max = tk_lt_max if total_tk_lt_max is None else max(total_tk_lt_max, tk_lt_max)
                    if tk_gt_min is not None:
                        total_tk_gt_min = tk_gt_min if total_tk_gt_min is None else min(total_tk_gt_min, tk_gt_min)
                    if tk_gt_max is not None:
                        total_tk_gt_max = tk_gt_max if total_tk_gt_max is None else max(total_tk_gt_max, tk_gt_max)
                    total_tk_count += vals.get("tk_count", 0)
                    total_tk_sum += vals.get("tk_sum", 0.0)
                    tk_min = vals.get("tk_min")
                    tk_max = vals.get("tk_max")
                    if tk_min is not None:
                        total_tk_min = tk_min if total_tk_min is None else min(total_tk_min, tk_min)
                    if tk_max is not None:
                        total_tk_max = tk_max if total_tk_max is None else max(total_tk_max, tk_max)
                    self.stats_row_stats.append(
                        {
                            "count": vals.get("tk_count", 0),
                            "sum": vals.get("tk_sum", 0.0),
                            "min": vals.get("tk_min"),
                            "max": vals.get("tk_max"),
                            "lt_count": vals.get("tk_lt", 0),
                            "lt_sum": vals.get("tk_lt_sum", 0.0),
                            "lt_min": vals.get("tk_lt_min"),
                            "lt_max": vals.get("tk_lt_max"),
                            "gt_count": vals.get("tk_gt", 0),
                            "gt_sum": vals.get("tk_gt_sum", 0.0),
                            "gt_min": vals.get("tk_gt_min"),
                            "gt_max": vals.get("tk_gt_max"),
                            "months_lt_sum": months_lt_sum,
                            "months_gt_sum": months_gt_sum,
                            "months_lt_min": months_lt_min,
                            "months_lt_max": months_lt_max,
                            "months_gt_min": months_gt_min,
                            "months_gt_max": months_gt_max,
                            "tk_values": list(vals.get("tk_values", [])),
                            "tk_lt_values": list(vals.get("tk_lt_values", [])),
                            "tk_gt_values": list(vals.get("tk_gt_values", [])),
                            "months_lt_values": [list(v) for v in months_lt_values],
                            "months_gt_values": [list(v) for v in months_gt_values],
                        }
                    )
                # dòng tổng
                total_row = rows_n
                set_cell(total_row, 0, "Tổng")
                set_cell(total_row, 1, f"{total_tot:,}")
                total_normal = total_tot - (total_ngk + total_khoa + total_chan + total_chan2)
                total_normal = max(total_normal, 0)
                set_cell(total_row, 2, f"{total_normal:,}")
                set_cell(total_row, 3, f"{total_ngk:,}")
                set_cell(total_row, 4, f"{total_khoa:,}")
                set_cell(total_row, 5, f"{total_chan:,}")
                set_cell(total_row, 6, f"{total_chan2:,}")
                col_base = 7
                for idx_order, m_idx in enumerate(self.stats_month_order):
                    set_cell(total_row, col_base + idx_order * 2, f"{total_months_lt[m_idx]:,}")
                    set_cell(total_row, col_base + idx_order * 2 + 1, f"{total_months_gt[m_idx]:,}")
                last_col = col_base + len(self.stats_month_order) * 2
                set_cell(total_row, last_col, f"{total_tk_lt:,}")
                set_cell(total_row, last_col + 1, f"{total_tk_gt:,}")
                self.stats_row_stats.append(
                    {
                        "count": total_tk_count,
                        "sum": total_tk_sum,
                        "min": total_tk_min,
                        "max": total_tk_max,
                        "lt_count": total_tk_lt,
                        "lt_sum": total_tk_lt_sum,
                        "lt_min": total_tk_lt_min,
                        "lt_max": total_tk_lt_max,
                        "gt_count": total_tk_gt,
                        "gt_sum": total_tk_gt_sum,
                        "gt_min": total_tk_gt_min,
                        "gt_max": total_tk_gt_max,
                        "months_lt_sum": total_months_lt_sum,
                        "months_gt_sum": total_months_gt_sum,
                        "months_lt_min": total_months_lt_min,
                        "months_lt_max": total_months_lt_max,
                        "months_gt_min": total_months_gt_min,
                        "months_gt_max": total_months_gt_max,
                        "tk_values": list(total_tk_values),
                        "tk_lt_values": list(total_tk_lt_values),
                        "tk_gt_values": list(total_tk_gt_values),
                        "months_lt_values": [list(v) for v in total_months_lt_values],
                        "months_gt_values": [list(v) for v in total_months_gt_values],
                    }
                )
                if not getattr(self, "_stats_nm_autosized", False):
                    self.stats_nm_table.resizeColumnsToContents()
                    self._stats_nm_autosized = True
                    self._remember_stats_nm_widths()
                # áp width đã lưu (nếu có)
                self._apply_stats_nm_widths()
                # Giữ kích thước tối thiểu theo nội dung nhưng vẫn cho phép giãn ra
                vh = self.stats_nm_table.verticalHeader()
                visible_rows = max(1, min(self.stats_nm_table.rowCount(), 12))
                row_h = vh.defaultSectionSize() or 24
                hbar_h = self.stats_nm_table.horizontalScrollBar().sizeHint().height()
                height = (
                    self.stats_nm_table.horizontalHeader().height()
                    + visible_rows * row_h
                    + hbar_h
                    + self.stats_nm_table.frameWidth() * 2
                )
                self.stats_nm_table.setMinimumHeight(height)

            fill_nm_table(nm_stats)
            # nếu chưa áp width (ví dụ refresh sớm) thì áp lại sau 1 tick
            QTimer.singleShot(0, self._apply_stats_nm_widths)
            # Cập nhật biểu đồ HSD theo ngày
            self._chart_cache = {
                "headers": headers,
                "rows": rows,
                "hsd_idx": hsd_idx,
                "nm_idx": nm_idx,
                "tkc_idx": tkc_idx,
                "parse_number": parse_number,
            }
            # đồng bộ bộ lọc biểu đồ theo bộ lọc HSD hiện tại
            try:
                if hasattr(self, "chart_hsd_month"):
                    self.chart_hsd_month.blockSignals(True)
                    self.chart_hsd_from.blockSignals(True)
                    self.chart_hsd_to.blockSignals(True)
                    self.chart_hsd_nm.blockSignals(True)
                    if hasattr(self, "stats_hsd_month"):
                        self.chart_hsd_month.setCurrentText(self.stats_hsd_month.currentText())
                    if hasattr(self, "stats_hsd_from"):
                        self.chart_hsd_from.setDate(self.stats_hsd_from.date())
                    if hasattr(self, "stats_hsd_to"):
                        self.chart_hsd_to.setDate(self.stats_hsd_to.date())
                    # điền danh sách nhà mạng cho combo biểu đồ
                    if hasattr(self, "stats_nm_input"):
                        items = ["Tất cả"]
                        for i in range(self.stats_nm_input.count()):
                            txt = self.stats_nm_input.itemText(i)
                            if txt and txt not in items:
                                items.append(txt)
                        current = self.chart_hsd_nm.currentText()
                        self.chart_hsd_nm.clear()
                        self.chart_hsd_nm.addItems(items)
                        if current:
                            idx = self.chart_hsd_nm.findText(current)
                            if idx >= 0:
                                self.chart_hsd_nm.setCurrentIndex(idx)
            finally:
                if hasattr(self, "chart_hsd_month"):
                    self.chart_hsd_month.blockSignals(False)
                    self.chart_hsd_from.blockSignals(False)
                    self.chart_hsd_to.blockSignals(False)
                    self.chart_hsd_nm.blockSignals(False)
            # refresh biểu đồ theo bộ lọc HSD hiện tại để khớp dữ liệu
            self._chart_tpl = sel_tpl
            self._refresh_hsd_chart_cached()
        finally:
            self._refreshing_stats = False

    def _refresh_hsd_chart_cached(self) -> None:
        if hasattr(self, "hsd_chart_enabled") and not self.hsd_chart_enabled:
            return
        cache = getattr(self, "_chart_cache", None)
        if not cache:
            return
        self._refresh_hsd_chart(
            cache["headers"],
            cache["rows"],
            cache["hsd_idx"],
            cache["nm_idx"],
            cache["tkc_idx"],
            cache["parse_number"],
        )

    def _toggle_hsd_chart(self) -> None:
        """Bật/tắt biểu đồ HSD để giảm lag khi không cần xem."""
        self.hsd_chart_enabled = not getattr(self, "hsd_chart_enabled", True)
        self._apply_hsd_chart_state(apply_refresh=self.hsd_chart_enabled)

    def _apply_hsd_chart_state(self, apply_refresh: bool = True) -> None:
        """Áp trạng thái chart hiện tại (ẩn/hiện + nhãn nút); tùy chọn refresh."""
        enabled = getattr(self, "hsd_chart_enabled", True)
        if hasattr(self, "hsd_chart_view"):
            self.hsd_chart_view.setVisible(enabled)
        if not enabled and hasattr(self, "hsd_tip"):
            self.hsd_tip.hide()
        if hasattr(self, "chart_hsd_toggle_btn"):
            self.chart_hsd_toggle_btn.setText("Tắt biểu đồ" if enabled else "Hiện biểu đồ")
            self.chart_hsd_toggle_btn.setChecked(not enabled)
        if enabled and apply_refresh:
            self._refresh_hsd_chart_cached()

    def _refresh_hsd_chart(self, headers, rows, hsd_idx, nm_idx, tkc_idx, parse_number) -> None:
        """Vẽ biểu đồ cột HSD theo ngày (dưới bảng thống kê) – độc lập với bộ lọc bảng."""
        if not hasattr(self, "hsd_chart_view"):
            return
        chart = QChart()
        chart.setAnimationOptions(QChart.SeriesAnimations)
        chart.legend().setVisible(False)
        self._hsd_bar_details = {}
        # remove old label items if any
        if hasattr(self, "_hsd_label_items"):
            for it in self._hsd_label_items:
                it.setParentItem(None)
            self._hsd_label_items = []

        if hsd_idx is None or nm_idx is None:
            self.hsd_chart_view.setChart(chart)
            return

        # lọc theo bộ lọc riêng của biểu đồ
        def chart_date_in_range(row):
            if hsd_idx is None or hsd_idx >= len(row):
                return False
            val = row[hsd_idx]
            dt = parse_datetime_string("" if pd.isna(val) else str(val), include_time=False)
            if not dt:
                return False
            d = dt.date()
            min_dt = QDate(1900, 1, 1)
            f_dt = self.chart_hsd_from.date() if hasattr(self, "chart_hsd_from") else min_dt
            t_dt = self.chart_hsd_to.date() if hasattr(self, "chart_hsd_to") else min_dt
            f = None if f_dt == min_dt else f_dt.toPython()
            t = None if t_dt == min_dt else t_dt.toPython()
            if f and d < f:
                return False
            if t and d > t:
                return False
            return True

        rows_chart = [r for r in rows if chart_date_in_range(r)]

        def _nm_val(r):
            if nm_idx >= len(r) or pd.isna(r[nm_idx]):
                return "(không rõ)"
            return str(r[nm_idx]).strip() or "(không rõ)"

        def _tk_val(r):
            if tkc_idx is None or tkc_idx >= len(r) or pd.isna(r[tkc_idx]):
                return None
            return parse_number(str(r[tkc_idx]))

        stats_by_date = {}
        for r in rows_chart:
            raw = "" if pd.isna(r[hsd_idx]) else str(r[hsd_idx])
            dt = parse_datetime_string(raw, include_time=False)
            if not dt:
                continue
            d = dt.date()
            nm = _nm_val(r)
            tk = _tk_val(r)
            rec = stats_by_date.setdefault(d, {"count": 0, "count_lt": 0, "tk_sum": 0.0, "nms": {}})
            rec["count"] += 1
            nm_rec = rec["nms"].setdefault(nm, {"count": 0, "tk_sum": 0.0})
            nm_rec["count"] += 1
            if tk is not None:
                nm_rec["tk_sum"] += tk
                rec["tk_sum"] += tk
                if tk < (self.stats_tk_threshold or 250):
                    rec["count_lt"] += 1

        if not stats_by_date:
            self.hsd_chart_view.setChart(chart)
            return

        dates_sorted = sorted(stats_by_date.keys())
        categories = []
        counts_total = []
        counts_lt = []
        for d in dates_sorted:
            label = d.strftime("%d/%m")
            categories.append(label)
            total = stats_by_date[d]["count"]
            lt = stats_by_date[d]["count_lt"]
            counts_total.append(total)
            counts_lt.append(lt)
            self._hsd_bar_details[label] = stats_by_date[d]["nms"]

        bar_set_lt = QBarSet(f"< {self.stats_tk_threshold or 250}")
        bar_set_lt.setColor(QColor("#e74c3c"))
        bar_set_ge = QBarSet(f">= {self.stats_tk_threshold or 250}")
        bar_set_ge.setColor(QColor("#2ecc71"))
        bar_set_lt.append(counts_lt)
        bar_set_ge.append([max(t - l, 0) for t, l in zip(counts_total, counts_lt)])

        series = QStackedBarSeries()
        series.append(bar_set_lt)
        series.append(bar_set_ge)
        # tắt nhãn mặc định, sẽ tự vẽ nhãn tùy chỉnh
        series.setLabelsVisible(False)
        chart.addSeries(series)
        # Lưu lại để hover ở vùng trống cũng hiển thị
        self._hsd_cat_labels = categories
        self._hsd_dates = dates_sorted
        self._hsd_counts_total = counts_total
        self._hsd_counts_lt = counts_lt
        self._hsd_series = series
        self._hsd_stats_by_date = stats_by_date
        self._hsd_label_to_date = {lbl: d for lbl, d in zip(categories, dates_sorted)}

        cat_axis = QBarCategoryAxis()
        cat_axis.append(categories)
        chart.addAxis(cat_axis, Qt.AlignBottom)
        series.attachAxis(cat_axis)

        val_axis = QValueAxis()
        max_count = max(counts_total) if counts_total else 0
        val_axis.setRange(0, max(1, int(max_count * 1.1)))
        val_axis.setLabelFormat("%d")
        chart.addAxis(val_axis, Qt.AlignLeft)
        series.attachAxis(val_axis)

        def on_hover(state: bool, index: int):
            # dùng tooltip tùy chỉnh; bỏ QToolTip
            if not state:
                return
            if index < 0 or index >= len(categories):
                return
            label = categories[index]
            detail = self._hsd_bar_details.get(label, {})
            if not detail:
                return
            lines = []
            for nm, info in sorted(detail.items(), key=lambda x: -x[1]["count"]):
                tk_txt = self._format_sum_value(info["tk_sum"]) if info["tk_sum"] else "0"
                lines.append(f"{nm}: {info['count']} (TKC: {tk_txt})")
            # hiển thị bằng label custom ngay tại vị trí cursor
            if hasattr(self, "hsd_tip"):
                self.hsd_tip.setText("\n".join(lines))
                self.hsd_tip.adjustSize()
                self.hsd_tip.move(QCursor.pos() + QPoint(12, 12))
                self.hsd_tip.show()

        bar_set_lt.hovered.connect(on_hover)
        bar_set_ge.hovered.connect(on_hover)

        chart.setTitle("HSD theo ngày (số SIM)")
        chart.legend().setVisible(True)
        chart.legend().setAlignment(Qt.AlignRight)
        chart.layout().setContentsMargins(6, 6, 6, 6)
        self.hsd_chart_view.setChart(chart)
        # Tạm thời bỏ nhãn giá trị trên cột để tránh lệch sang cột khác
        self._hsd_label_items = []

    def _stats_min_date(self, headers: List[str], rows: List[List[Any]], hsd_idx: Optional[int]) -> Optional[datetime.date]:
        if hsd_idx is None:
            # thử tìm theo tên
            for i, h in enumerate(headers):
                norm = self._normalize_header_name(h)
                if any(k in norm for k in ["hsd", "han", "ngay"]):
                    hsd_idx = i
                    break
        if hsd_idx is None:
            return None
        min_dt = None
        for r in rows:
            if hsd_idx >= len(r):
                continue
            val = r[hsd_idx]
            dt = parse_datetime_string("" if pd.isna(val) else str(val), include_time=False)
            if dt:
                d = dt.date()
                if min_dt is None or d < min_dt:
                    min_dt = d
        return min_dt

    def _stats_max_date(self, headers: List[str], rows: List[List[Any]], hsd_idx: Optional[int]) -> Optional[datetime.date]:
        if hsd_idx is None:
            for i, h in enumerate(headers):
                norm = self._normalize_header_name(h)
                if any(k in norm for k in ["hsd", "han", "ngay"]):
                    hsd_idx = i
                    break
        if hsd_idx is None:
            return None
        max_dt = None
        for r in rows:
            if hsd_idx >= len(r):
                continue
            val = r[hsd_idx]
            dt = parse_datetime_string("" if pd.isna(val) else str(val), include_time=False)
            if dt:
                d = dt.date()
                if max_dt is None or d > max_dt:
                    max_dt = d
        return max_dt

    def _set_stats_default_range(self) -> None:
        if not hasattr(self, "stats_hsd_from"):
            return
        min_dt = QDate(1900, 1, 1)
        for de in (self.stats_hsd_from, self.stats_hsd_to, self.stats_nhap_from, self.stats_nhap_to, self.stats_psc_from, self.stats_psc_to):
            de.setDate(min_dt)
        for cb in (self.stats_hsd_month, self.stats_nhap_month, self.stats_psc_month):
            cb.setCurrentIndex(cb.findText("Tất cả"))

    def _find_date_column(self) -> Optional[int]:
        for i, h in enumerate(self.headers):
            norm = self._normalize_header_name(h)
            if any(k in norm for k in ["hsd", "han", "ngay"]):
                return i
        return None

    def _apply_source_column(self, rows: List[List[Any]], sheet_name: Optional[str] = None) -> None:
        if "Nguồn" not in self.headers:
            return
        idx = self.headers.index("Nguồn")
        source = self._format_source_label(self.current_path, sheet_name or self.current_sheet)
        for row in rows:
            while len(row) <= idx:
                row.append("")
            row[idx] = source

    def _write_excel(self) -> None:
        try:
            df = pd.DataFrame(self.rows_all, columns=self.headers)
            df.to_excel(self.current_path, index=False)
        except PermissionError:
            QMessageBox.warning(
                self,
                "Không ghi được file",
                f"Không ghi được {self.current_path}.\n"
                "Có thể file đang mở. Vui lòng đóng file Excel rồi thử lại.",
            )
        except Exception as exc:
            QMessageBox.warning(self, "Lỗi ghi file", str(exc))

    def _on_cell_edited(self, row: int, col: int, value: Any) -> None:
        try:
            self._on_cell_edited_impl(row, col, value)
            return
        except Exception:
            err = traceback.format_exc()
        self._show_error_popup("Lỗi khi sửa ô", err)

    def _on_cell_edited_impl(self, row: int, col: int, value: Any) -> None:
        # rows trong view tham chiếu cùng list với rows_all nên đã cập nhật; chỉ cần lưu
        actual_col = self._view_to_data_column(col)
        phone_idx = self._find_phone_column(self.headers)
        if phone_idx is not None and actual_col == phone_idx:
            if 0 <= row < len(self.rows):
                row_ref = self.rows[row]
                if phone_idx < len(row_ref):
                    formatted = self._format_phone_value(str(value))
                    if row_ref[phone_idx] != formatted:
                        row_ref[phone_idx] = formatted
                        model = self.table.model()
                        if model:
                            idx = model.index(row, col)
                            model.dataChanged.emit(idx, idx, [Qt.DisplayRole, Qt.EditRole])
                self._dedupe_phone_rows(row_ref)
                self._apply_filters()
        # cập nhật thời gian thay đổi
        change_idx = self._change_col_idx()
        global_idx = self._row_index_from_view(row)
        if change_idx is not None and global_idx is not None:
            now_text = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
            if 0 <= change_idx < len(self.rows[0]):
                self.rows[row][change_idx] = now_text
            if 0 <= global_idx < len(self.rows_all):
                if change_idx < len(self.rows_all[global_idx]):
                    self.rows_all[global_idx][change_idx] = now_text
            self._ensure_row_histories()
            if global_idx < len(self.row_histories):
                self.row_histories[global_idx].append(now_text)
            model = self.table.model()
            if model and 0 <= change_idx < model.columnCount():
                idx = model.index(row, change_idx + (1 if self.show_index_column else 0))
                model.dataChanged.emit(idx, idx, [Qt.DisplayRole, Qt.EditRole])
        self._persist_now()
        # Excel sẽ được lưu theo chu kỳ autosave

    def _apply_autosave_setting(self) -> None:
        if self.autosave_enabled and self.autosave_interval_ms and self.autosave_interval_ms > 0:
            self.autosave_timer.start(self.autosave_interval_ms)
        else:
            self.autosave_timer.stop()

    def _update_autosave_from_inputs(self) -> None:
        text = self.autosave_input.text().strip()
        unit = self.autosave_unit.currentText()
        try:
            val = float(text)
            if val < 0:
                val = 0
        except Exception:
            val = 0
        if unit == "phút":
            ms = int(val * 60000)
        else:
            ms = int(val * 1000)
        self.autosave_interval_ms = ms
        self._apply_autosave_setting()
        self._save_state()

    def _set_autosave_enabled(self, enabled: bool) -> None:
        self.autosave_enabled = enabled
        self._apply_autosave_setting()
        self._save_state()

    def _apply_row_height_setting(self) -> None:
        text = self.row_height_input.text().strip() if hasattr(self, "row_height_input") else ""
        try:
            val = int(float(text))
        except Exception:
            val = self.row_height
        val = max(16, min(120, val))
        self.row_height = val
        self._enforce_row_height(val)
        vh = self.table.verticalHeader()
        vh.setSectionResizeMode(QHeaderView.Fixed)
        vh.setMinimumSectionSize(max(16, val))
        vh.setDefaultSectionSize(val)
        self._persist_now()
        QMessageBox.information(self, "Cao dòng", f"Đã đặt cao dòng = {val}px.")

    def _apply_style_to_selection(
        self,
        bold: Optional[bool] = None,
        italic: Optional[bool] = None,
        underline: Optional[bool] = None,
        color: Optional[str] = None,
        bg: Optional[str] = None,
        clear_font: bool = False,
    ) -> None:
        sel = self.table.selectionModel()
        if not sel:
            return
        indexes = sel.selectedIndexes()
        if not indexes:
            return
        model = self.table.model()
        if not model:
            return
        changed = False
        for idx in indexes:
            g_row = self._row_index_from_view(idx.row())
            col_view = idx.column()
            if g_row is None:
                continue
            actual_col = self._view_to_data_column(col_view)
            if actual_col is None:
                continue
            key = f"{g_row}_{actual_col}"
            style = self.cell_styles.get(key, {})
            if clear_font:
                style.pop("bold", None)
                style.pop("italic", None)
                style.pop("underline", None)
            if bold is not None:
                style["bold"] = bold
            if italic is not None:
                style["italic"] = italic
            if underline is not None:
                style["underline"] = underline
            if color is not None:
                if color:
                    style["color"] = color
                else:
                    style.pop("color", None)
            if bg is not None:
                if bg:
                    style["bg"] = bg
                else:
                    style.pop("bg", None)
            self.cell_styles[key] = style
            changed = True
        if changed:
            top_left = min(indexes, key=lambda i: (i.row(), i.column()))
            bottom_right = max(indexes, key=lambda i: (i.row(), i.column()))
            model.dataChanged.emit(top_left, bottom_right, [Qt.FontRole, Qt.ForegroundRole, Qt.BackgroundRole])
            self._persist_now()
        # push to undo stack handled in _persist_now

    def _apply_style_to_columns(
        self,
        columns: set[int],
        bold: Optional[bool] = None,
        italic: Optional[bool] = None,
        underline: Optional[bool] = None,
        color: Optional[str] = None,
        bg: Optional[str] = None,
        clear_font: bool = False,
    ) -> None:
        if not columns:
            return
        model = self.table.model()
        if not model:
            return
        changed = False
        for view_col in columns:
            actual = self._view_to_data_column(view_col)
            if actual is None:
                continue
            for g_row in range(len(self.rows_all)):
                key = f"{g_row}_{actual}"
                style = self.cell_styles.get(key, {})
                if clear_font:
                    style.pop("bold", None)
                    style.pop("italic", None)
                    style.pop("underline", None)
                if bold is not None:
                    style["bold"] = bold
                if italic is not None:
                    style["italic"] = italic
                if underline is not None:
                    style["underline"] = underline
                if color is not None:
                    if color:
                        style["color"] = color
                    else:
                        style.pop("color", None)
                if bg is not None:
                    if bg:
                        style["bg"] = bg
                    else:
                        style.pop("bg", None)
                self.cell_styles[key] = style
                changed = True
            if model.rowCount() > 0:
                top_left = model.index(0, view_col)
                bottom_right = model.index(model.rowCount() - 1, view_col)
                model.dataChanged.emit(top_left, bottom_right, [Qt.FontRole, Qt.ForegroundRole, Qt.BackgroundRole])
        if changed:
            self._persist_now()

    # ===================== Header interactions ===================== #
    def _select_column_from_header(self, col: int, add: bool = False) -> None:
        model = self.table.model()
        if not model or col < 0 or col >= model.columnCount():
            return
        sel_model = self.table.selectionModel()
        if not sel_model:
            return
        if not add:
            sel_model.clearSelection()
        top_left = model.index(0, col)
        bottom_right = model.index(model.rowCount() - 1, col)
        selection = QItemSelection(top_left, bottom_right)
        flags = QItemSelectionModel.Columns | (QItemSelectionModel.Select if not add else QItemSelectionModel.Toggle)
        sel_model.select(selection, flags)
        # đặt focus vào ô lọc tương ứng
        if col < len(self.filter_inputs):
            self.filter_inputs[col].setFocus()

    def _rename_header(self, col: int) -> None:
        actual = self._view_to_data_column(col)
        if actual is None or actual < 0 or actual >= len(self.headers):
            return
        current = self.headers[actual]
        new_name, ok = QInputDialog.getText(self, "Đổi tên header", "Tên mới:", text=current)
        if not ok:
            return
        self.headers[actual] = new_name.strip()
        self._set_model(self.headers, self.rows)
        self._save_cached_data()
        self._save_state()
        # Excel sẽ được lưu theo chu kỳ autosave

    # ===================== Event filter to clear selection when not holding Ctrl ===================== #
    def eventFilter(self, obj, event):
        if not hasattr(self, "table"):
            return super().eventFilter(obj, event)
        if obj is self.table and event.type() == QEvent.MouseButtonPress:
            # Only clear selection on left-click; keep right-click selections for context menu actions
            if event.button() == Qt.LeftButton and not (event.modifiers() & Qt.ControlModifier):
                sel_model = self.table.selectionModel()
                if sel_model:
                    sel_model.clearSelection()
        if obj is self.table and event.type() == QEvent.KeyPress:
            if event.modifiers() & Qt.ControlModifier:
                if event.key() == Qt.Key_V:
                    self._handle_paste()
                    return True
                if event.key() == Qt.Key_C:
                    self._copy_selection_to_clipboard()
                    return True
                if event.key() == Qt.Key_X:
                    self._cut_selection_to_clipboard()
                    return True
                if event.key() == Qt.Key_Z:
                    self._undo()
                    return True
                if event.key() == Qt.Key_Y:
                    self._redo()
                    return True
        if obj is self.table and event.type() == QEvent.KeyPress:
            if event.key() in (Qt.Key_Delete, Qt.Key_Backspace):
                self._clear_selected_cells()
                return True
        # Copy trong bảng thống kê
        if hasattr(self, "stats_nm_table") and obj is self.stats_nm_table and event.type() == QEvent.KeyPress:
            if event.modifiers() & Qt.ControlModifier and event.key() == Qt.Key_C:
                self._copy_stats_selection()
                return True
        # Hover biểu đồ HSD: luôn hiển thị tooltip dù không trúng cột
        if hasattr(self, "hsd_chart_view"):
            hv = self.hsd_chart_view
            if obj in (hv, hv.viewport()) and event.type() == QEvent.MouseMove:
                if hasattr(self, "_show_hsd_hover_tooltip"):
                    self._show_hsd_hover_tooltip(event)
                return True
            if obj in (hv, hv.viewport()) and event.type() == QEvent.Leave:
                if hasattr(self, "hsd_tip"):
                    self.hsd_tip.hide()
                return True
        # Lọc thống kê: dblclick line edit -> refresh
        if hasattr(self, "_stats_lineedits") and obj in self._stats_lineedits:
            if event.type() == QEvent.MouseButtonDblClick:
                self._refresh_stats()
                return False
        # Forward wheel on filter area to table for smooth horizontal scroll
        if obj is self.filter_area and event.type() == QEvent.Wheel:
            delta = event.angleDelta()
            hbar = self.table.horizontalScrollBar()
            if delta.x() != 0:
                hbar.setValue(hbar.value() - delta.x())
                event.accept()
                return True
            if event.modifiers() & Qt.ShiftModifier:
                hbar.setValue(hbar.value() - delta.y())
                event.accept()
                return True
        template_combo = getattr(self, "template_combo", None)
        if template_combo and obj is template_combo.view():
            if event.type() == QEvent.MouseButtonPress and event.button() == Qt.RightButton:
                self._show_template_menu(event.pos())
                return True
            if event.type() == QEvent.ContextMenu:
                self._show_template_menu(event.pos())
                return True
        # Hover biểu đồ HSD: luôn hiển thị tooltip dù không trúng cột
        if hasattr(self, "hsd_chart_view") and obj in (self.hsd_chart_view, getattr(self.hsd_chart_view, "viewport", lambda: None)()) and event.type() == QEvent.MouseMove:
            self._show_hsd_hover_tooltip(event)
            return True
        return super().eventFilter(obj, event)

    def _show_hsd_hover_tooltip(self, event):
        """Hiển thị tooltip biểu đồ HSD khi rê chuột vào cột hoặc vùng trống."""
        if not hasattr(self, "hsd_chart_view"):
            return
        if not getattr(self, "_hsd_series", None):
            return
        chart = self.hsd_chart_view.chart()
        if not chart or not self._hsd_cat_labels:
            return
        try:
            pos_qpoint = event.position().toPoint()  # Qt6 khuyến nghị
        except Exception:
            pos_qpoint = event.pos()
        pos = pos_qpoint
        # chuyển sang giá trị trục (x gần index cột)
        val = chart.mapToValue(pos, self._hsd_series)
        if val is None:
            return
        idx = int(round(val.x()))
        if idx < 0 or idx >= len(self._hsd_cat_labels):
            return
        label = self._hsd_cat_labels[idx]
        date_key = self._hsd_dates[idx] if hasattr(self, "_hsd_dates") and idx < len(self._hsd_dates) else None
        rec = self._hsd_stats_by_date.get(date_key, None)
        if not rec:
            return
        total = rec.get("count", 0)
        lt = rec.get("count_lt", 0)
        ge = total - lt
        threshold = self.stats_tk_threshold or 250
        # Dòng 1: ngày + tổng; Dòng 2: phân ngưỡng gọn một dòng
        tk_sum = self._format_sum_value(rec.get("tk_sum")) if rec.get("tk_sum") else "0"
        lines = [f"{label} tổng: {total} (tkc: {tk_sum})", f"< {threshold}: {lt} | >= {threshold}: {ge}"]
        nms = rec.get("nms", {})
        if nms:
            lines.append("--- Theo nhà mạng ---")
            for nm, info in sorted(nms.items(), key=lambda x: -x[1]["count"]):
                tk_txt = self._format_sum_value(info["tk_sum"]) if info.get("tk_sum") else "0"
                lines.append(f"{nm}: {info['count']} (TKC: {tk_txt})")
        if hasattr(self, "hsd_tip"):
            self.hsd_tip.setText("\n".join(lines))
            self.hsd_tip.adjustSize()
            self.hsd_tip.move(self.hsd_chart_view.mapToGlobal(pos + QPoint(12, 12)))
            self.hsd_tip.show()

    # ===================== Row header context menu ===================== #
    def _show_row_header_menu(self, pos) -> None:
        vh = self.table.verticalHeader()
        row = vh.logicalIndexAt(pos)
        from PySide6.QtWidgets import QMenu

        menu = QMenu(self)
        act_add_above = menu.addAction("Thêm hàng trên")
        act_add_above.triggered.connect(lambda: self._insert_row(position="above", base_row=row if row >= 0 else None))
        act_add_below = menu.addAction("Thêm hàng dưới")
        act_add_below.triggered.connect(lambda: self._insert_row(position="below", base_row=row if row >= 0 else None))
        menu.addSeparator()
        act_history = menu.addAction("Lịch sử chỉnh sửa")
        act_history.setEnabled(row >= 0)
        act_history.triggered.connect(lambda: self._show_row_history(row))
        act_del_row = menu.addAction("Xóa hàng đã chọn")
        act_del_row.triggered.connect(self._delete_rows)
        act_del_empty = menu.addAction("Xóa dòng trống")
        act_del_empty.triggered.connect(self._delete_empty_rows)
        menu.exec(vh.mapToGlobal(pos))
        self._save_state()

    def _show_table_context_menu(self, pos) -> None:
        if not self.table.model():
            return
        # Bảo toàn ô vừa nhấn chuột phải để thao tác tô màu nền/kiểu chữ
        idx_under = self.table.indexAt(pos)
        sel_model = self.table.selectionModel()
        if idx_under.isValid() and sel_model and not sel_model.isSelected(idx_under):
            sel_model.select(idx_under, QItemSelectionModel.ClearAndSelect)
        menu = QMenu(self)
        sel_rows = self.table.selectionModel().selectedRows()
        act_del = menu.addAction("Xóa hàng đã chọn")
        act_del.setEnabled(bool(sel_rows))
        act_del.triggered.connect(self._delete_rows)
        act_copy = menu.addAction("Sao chép")
        act_copy.setEnabled(bool(self.table.selectionModel().selectedIndexes()))
        act_copy.triggered.connect(self._copy_selection_to_clipboard)
        paste_action = menu.addAction("Dán vào cột")
        paste_action.setEnabled(self._selection_info() is not None)
        paste_action.triggered.connect(self._paste_from_context_menu)
        # Style submenu
        style_menu = menu.addMenu("Kiểu chữ")
        act_bold = style_menu.addAction("In đậm")
        act_bold.triggered.connect(lambda: self._apply_style_to_selection(bold=True))
        act_italic = style_menu.addAction("Nghiêng")
        act_italic.triggered.connect(lambda: self._apply_style_to_selection(italic=True))
        act_under = style_menu.addAction("Gạch chân")
        act_under.triggered.connect(lambda: self._apply_style_to_selection(underline=True))
        act_clear_style = style_menu.addAction("Xóa kiểu")
        act_clear_style.triggered.connect(lambda: self._apply_style_to_selection(clear_font=True))

        color_menu = menu.addMenu("Màu chữ")
        swatches = [
            ("Mặc định", None),
            ("Đỏ", "#ef4444"),
            ("Xanh lá", "#22c55e"),
            ("Xanh dương", "#2563eb"),
            ("Xanh đậm", "#1e3a8a"),
            ("Vàng", "#facc15"),
            ("Cam", "#f97316"),
            ("Hồng", "#ec4899"),
            ("Tím", "#8b5cf6"),
            ("Trắng", "#ffffff"),
            ("Đen", "#111111"),
        ]

        def make_icon(hex_color: str | None) -> QIcon:
            if not hex_color:
                return QIcon()
            pm = QPixmap(14, 14)
            pm.fill(QColor(hex_color))
            return QIcon(pm)

        for name, col in swatches:
            act = color_menu.addAction(make_icon(col), name)
            act.triggered.connect(lambda checked=False, c=col: self._apply_style_to_selection(color=c))

        def pick_color():
            dlgc = QColorDialog(self)
            dlgc.setOption(QColorDialog.DontUseNativeDialog, True)
            for i, (_, col) in enumerate(swatches):
                if col:
                    dlgc.setCustomColor(i, QColor(col))
            if dlgc.exec():
                c = dlgc.currentColor()
                if c.isValid():
                    self._apply_style_to_selection(color=c.name())

        color_menu.addSeparator()
        color_menu.addAction("Bảng màu...").triggered.connect(pick_color)
        # Màu nền
        bg_menu = menu.addMenu("Màu nền")
        act_bg_clear = bg_menu.addAction("Mặc định")
        act_bg_clear.triggered.connect(lambda: self._apply_style_to_selection(bg=""))
        bg_menu.addSeparator()
        for name, col in swatches[1:]:
            act = bg_menu.addAction(make_icon(col), name)
            act.triggered.connect(lambda checked=False, c=col: self._apply_style_to_selection(bg=c))
        def pick_bg():
            dlgc = QColorDialog(self)
            dlgc.setOption(QColorDialog.DontUseNativeDialog, True)
            for i, (_, col) in enumerate(swatches):
                if col:
                    dlgc.setCustomColor(i, QColor(col))
            if dlgc.exec():
                c = dlgc.currentColor()
                if c.isValid():
                    self._apply_style_to_selection(bg=c.name())
        bg_menu.addSeparator()
        bg_menu.addAction("Bảng màu...").triggered.connect(pick_bg)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _show_row_history(self, view_row: int) -> None:
        idx = self._row_index_from_view(view_row)
        if idx is None or idx >= len(self.row_histories):
            QMessageBox.information(self, "Lịch sử chỉnh sửa", "Không có lịch sử cho hàng này.")
            return
        hist = self.row_histories[idx]
        if not hist:
            QMessageBox.information(self, "Lịch sử chỉnh sửa", "Không có lịch sử cho hàng này.")
            return
        content = "\n".join(hist)
        QMessageBox.information(self, "Lịch sử chỉnh sửa", content)


def main() -> None:
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


class QuickDateTimeDialog(QDialog):
    def __init__(self, parent, initial: str, include_time: bool):
        super().__init__(parent)
        self.include_time = include_time
        self.setWindowTitle("Chọn thời gian nhanh" if include_time else "Chọn ngày nhanh")
        self.setMinimumWidth(320)
        layout = QVBoxLayout(self)
        self.manual_input = QLineEdit(initial or "")
        placeholder = "HH:mm:ss dd/MM/yyyy" if include_time else "dd/MM/yyyy"
        self.manual_input.setPlaceholderText(placeholder)
        layout.addWidget(self.manual_input)

        quick_layout = QHBoxLayout()
        quick_items = [
            ("Hôm nay", 0),
            ("Ngày mai", 1),
            ("Hôm qua", -1),
        ]
        for label, offset in quick_items:
            btn = QPushButton(label)
            btn.clicked.connect(lambda checked=False, off=offset: self._apply_offset(off))
            quick_layout.addWidget(btn)
        layout.addLayout(quick_layout)

        self.calendar = QCalendarWidget()
        self.calendar.setGridVisible(True)
        self.calendar.clicked.connect(self._calendar_selected)
        layout.addWidget(self.calendar)

        if include_time:
            time_layout = QHBoxLayout()
            self.time_edit = QTimeEdit()
            self.time_edit.setDisplayFormat("HH:mm:ss")
            self.time_edit.timeChanged.connect(self._update_manual_entry)
            time_layout.addWidget(self.time_edit)
            for label in ["00:00", "06:00", "12:00", "18:00"]:
                btn = QPushButton(label)
                btn.clicked.connect(lambda checked=False, text=label: self._set_time(text))
                time_layout.addWidget(btn)
            layout.addLayout(time_layout)
        else:
            self.time_edit = None

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.calendar.selectionChanged.connect(self._update_manual_entry)
        self._initialize_widgets(initial or datetime.now().strftime("%H:%M:%S %d/%m/%Y" if include_time else "%d/%m/%Y"))

    def _initialize_widgets(self, initial: str) -> None:
        dt = self._parse_initial_datetime(initial)
        date = QDate(dt.year, dt.month, dt.day)
        self.calendar.setSelectedDate(date)
        if self.include_time and self.time_edit:
            self.time_edit.setTime(QTime(dt.hour, dt.minute, dt.second))
        self._update_manual_entry()

    def _parse_initial_datetime(self, text: str) -> datetime:
        parsed = parse_datetime_string(text, include_time=self.include_time)
        return parsed if parsed else datetime.now()

    def _apply_offset(self, offset: int) -> None:
        base_date = datetime.now().date() + timedelta(days=offset)
        hour = self.time_edit.time().hour() if self.time_edit else 0
        minute = self.time_edit.time().minute() if self.time_edit else 0
        second = self.time_edit.time().second() if self.time_edit else 0
        self.calendar.setSelectedDate(QDate(base_date.year, base_date.month, base_date.day))
        if self.time_edit:
            self.time_edit.setTime(QTime(hour, minute, second))
        self._update_manual_entry()

    def _set_time(self, text: str) -> None:
        try:
            parts = list(map(int, text.split(":")))
            hour, minute = parts[0], parts[1]
            second = parts[2] if len(parts) > 2 else 0
            if self.time_edit:
                self.time_edit.setTime(QTime(hour, minute, second))
            self._update_manual_entry()
        except ValueError:
            pass

    def _update_manual_entry(self) -> None:
        date = self.calendar.selectedDate()
        base = date.toString("dd/MM/yyyy")
        if self.include_time and self.time_edit:
            time = self.time_edit.time().toString("HH:mm")
            self.manual_input.setText(f"{time} {base}")
        else:
            self.manual_input.setText(base)

    def _calendar_selected(self, date: QDate) -> None:
        self.calendar.setSelectedDate(date)
        self._update_manual_entry()
        self.accept()

    def value(self) -> str:
        return self.manual_input.text().strip()


if __name__ == "__main__":
    main()
